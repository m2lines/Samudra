# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Audit and assemble matched global fixed-budget comparison from saved evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from samudra.experiments.observation_metrics import PROTOCOL, selection_score
ROOT=Path('/home/jder/.codex/worktrees/d-observation-pilot/Ocean_Emulator')
BASE=Path('/tmp/global-physical-comparison')
meta=json.loads((BASE/'data/compact/COMPLETE.json').read_text())
results=json.loads((BASE/'figures/results.json').read_text())
interior=json.loads((BASE/'initializer/results.json').read_text())
controls=json.load(open('/tmp/global-scratch-comparison-controls.json'))
refs=json.load(open('/tmp/global-scratch-reference-audit.json'))
ref_records=[v for k,v in refs.items() if k.endswith('selection-reference.json')]
assert len(ref_records)==3 and all(r==ref_records[0] for r in ref_records)
reference=ref_records[0]['reference']
keys=reference['spectral_keys']
assert len(keys)==27
control=controls['obs08000']['seasonal-climatology.json']['value']
assert all(r['seasonal-climatology.json']['value']==control for r in controls.values())
labels={'obs00050':'Early: 50 obs','obs00500':'Developing: 500 obs','obs02000':'Middle: 2,000 obs','obs08000':'Final: 8,000 obs','scratch08000':'Obs-only: 8,000 obs','scratch16000':'Obs-only: 16,000 obs'}
output={'score_definition':'0.5 mean of five integrated errors normalized by the identical held-out global training-seasonal-climatology errors + 0.5 mean spectral error_dex over 27 validation-qualified keys. Reporting normalization is held-out; selection and training curves use the original frozen validation denominators.', 'integrated_keys':PROTOCOL['integrated'],'spectral_keys':keys,'validation_reference_sha256':ref_records[0]['sha256'],'reporting_climatology':control,'models':{},'initializer_context':{},'annual_mean_bias':{}}
for stage,record in meta['checkpoints'].items():
 metrics=record['fixed_budget_evaluation']['metrics']
 assert record['fixed_budget_evaluation']['fixed_budget_lineage']==record['lineage']
 def reduce(value):
  return {'composite':selection_score(value,control,keys),'metrics':value['metrics'],'integrated_normalized':{k:value['metrics'][k]/control['metrics'][k] for k in PROTOCOL['integrated']},'spectral_dex':float(np.mean([value['spectra'][k]['error_dex'] for k in keys]))}
 output['models'][stage]={'label':labels[stage],'lineage':record['lineage'],'forecast':reduce(metrics),'persistence':reduce(controls[stage]['fixed-budget-inferred-persistence.json']['value']),'validation_normalized_test_score':selection_score(metrics,reference['control'],keys),'day30':{k:v['mean'] for k,v in record['day30'].items()}}
 output['initializer_context'][stage]={field:float(np.mean([v['context_agreement'][stage][key] for v in interior['origins'].values()])) for field,key in [('temperature_C','mean_temperature_rmse_10_1850_C'),('salinity_psu','mean_salinity_rmse_2_5_1850_psu')]}
 output['annual_mean_bias'][stage]={}
 for origin,a in record['annual'].items():
  if stage not in results['annual_heat_content_by_model']:continue
  bias={k:float(np.mean(np.array(a['means'][k]['forecast'])-np.array(a['means'][k]['observation']))) for k in ['sst','adt']}
  for band in ['ohc_0_700','ohc_700_2000']:bias[band+'_ZJ']=results['annual_heat_content_by_model'][stage][origin][band]['mean_bias_ZJ']['forecast']
  output['annual_mean_bias'][stage][origin]=bias
climo='Training December climatology'
output['initializer_context'][climo]={field:float(np.mean([v['context_agreement'][climo][key] for v in interior['origins'].values()])) for field,key in [('temperature_C','mean_temperature_rmse_10_1850_C'),('salinity_psu','mean_salinity_rmse_2_5_1850_psu')]}
for origin,record in interior['origins'].items():
 for stage in labels:
  for k in ['mean_temperature_rmse_10_1850_C','mean_salinity_rmse_2_5_1850_psu']:assert record['context_agreement'][stage][k]>record['context_agreement'][climo][k]
canonical=json.load(gzip.open(ROOT/'docs/experiments/observation-d/artifacts/2026-09-30-global-domain/comparison.json.gz'))['models']['global']['held_out']['endpoint']
for method in ['forecast','persistence']:
 assert output['models']['obs08000'][method]==canonical[method]
old=json.load(gzip.open(ROOT/'docs/experiments/observation-d/artifacts/2026-09-30-global-physical-focus/results.json.gz'))
checks=[]
def assert_subset(a,b):
 if isinstance(a,dict):
  for k,v in a.items():assert k in b;assert_subset(v,b[k])
 else:assert a==b
for stage in ['obs00050','obs00500','obs02000','obs08000']:
 assert_subset(old['checkpoints'][stage],results['checkpoints'][stage])
checks.append('All four previous checkpoint metrics, day30 reductions and annual means unchanged exactly')
for variable,regions in old['spectra'].items():
 for region,curves in regions.items():
  for stage,value in curves.items():assert value==results['spectra'][variable][region][stage]
checks.append('All previous model/OM4/coarse/native day30 spectra unchanged exactly')
for key in ['annual_mean_bias','annual_heat_content','ohc_representation_check']:
 assert old[key]==results[key]
checks.append('Original annual mean offsets, OHC totals and representation check unchanged exactly')
old_i=json.load(gzip.open(ROOT/'docs/experiments/observation-d/artifacts/2026-09-30-global-initializer/results.json.gz'))
for origin,record in old_i['origins'].items():
 for key in ['context_agreement','reference_anomaly_rms_by_depth']:
  if key=='context_agreement':
   for stage,value in record[key].items():assert value==interior['origins'][origin][key][stage]
  else:assert record[key]==interior['origins'][origin][key]
 for region,p in record['profiles'].items():
  for stage,value in p['means'].items():assert value==interior['origins'][origin]['profiles'][region]['means'][stage]
checks.append('Previous learned initializer profiles and context errors unchanged exactly')
output['verification']=checks+['Identical frozen validation reference in qualification, mixed and scratch','Identical held-out seasonal climatology for all six checkpoints','Mixed endpoint forecast and persistence reproduce canonical published global report exactly','Training December climatology beats every model separately for temperature and salinity in each example']
(BASE/'figures/primary-comparison.json').write_text(json.dumps(output,indent=2)+'\n')
for stage in ['obs08000','scratch08000','scratch16000']:
 r=output['models'][stage];print(stage,{k:r[k]['composite'] for k in ['forecast','persistence']},r['forecast']['metrics'],output['initializer_context'][stage]);print('annual',output['annual_mean_bias'][stage])
print('AUDIT_PASS',len(output['verification']))
