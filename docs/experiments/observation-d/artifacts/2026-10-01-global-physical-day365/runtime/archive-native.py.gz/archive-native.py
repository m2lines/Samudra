import hashlib,json,tarfile
from pathlib import Path
out=Path('/mnt/home/jrusak/data/obs_full_range/d-observation-pilot/global-physical-day365-20261001/native')
files={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in out.glob('*.npz')}
(out/'FILES.json').write_text(json.dumps(files,indent=2)+'\n')
archive=out.with_suffix('.tar')
with tarfile.open(archive,'w') as tar:tar.add(out,arcname='native')
receipt={'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(out.parent/'native-receipt.json').write_text(json.dumps(receipt)+'\n')
print('NATIVE_ARCHIVE_COMPLETE',receipt,flush=True)
