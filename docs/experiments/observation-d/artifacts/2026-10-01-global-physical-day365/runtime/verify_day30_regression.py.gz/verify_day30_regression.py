import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
root=Path('/home/jder/.codex/worktrees/d-observation-pilot/Ocean_Emulator');sys.path.insert(0,str(root/'scripts'))
from global_physical_spectra import regional_spectra
arrays=Path('/tmp/global-physical-comparison/data/compact');native_root=Path('/tmp/global-physical-focus/native')
meta=json.loads((arrays/'COMPLETE.json').read_text());grid=dict(np.load(arrays/'grid.npz'))
monthly={key:dict(np.load(arrays/(key+'-monthly.npz'))) for key in meta['checkpoints']}
products=['oisst','duacs'];months=[str(v) for v in pd.period_range('2015-01','2015-12',freq='M')]
native_grids={p:dict(np.load(native_root/(p+'-grid.npz'))) for p in products}
native={p:np.stack([np.load(native_root/(p+'-'+m+'.npz'))['native'] for m in months]) for p in products}
reference=monthly['obs08000']['reference']
print('Monthly shapes',reference.shape,next(iter(monthly.values()))['prediction'].shape,flush=True)
actual=regional_spectra({k:m['prediction'] for k,m in monthly.items()},reference,np.load(arrays/'om4-day30.npz')['surface'],grid['lat'],grid['lon'],grid['mask'],native,native_grids)
expected=json.loads(Path('/tmp/global-physical-comparison/figures/results.json').read_text())['spectra']
assert actual==expected
Path('/tmp/global-physical-day365/day30-regression.json').write_text(json.dumps({'verification':'All three variables, six regions and nine model/reference curves exactly reproduce every previous day30 spectrum; extracted shared transform only changes the configurable snapshot count','variables':list(actual),'regions':list(actual['SST'])},indent=2)+'\n')
print('DAY30_ALL_CURVES_EXACT_REGRESSION_PASS',flush=True)
