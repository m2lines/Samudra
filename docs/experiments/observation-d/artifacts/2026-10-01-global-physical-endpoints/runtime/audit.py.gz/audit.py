# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
import json
from pathlib import Path
import numpy as np
from PIL import Image
T=Path('/tmp/global-physical-endpoints')
KEEP=['obs08000','scratch08000','scratch16000']
DROP=['Early: 50 obs','Developing: 500 obs','Middle: 2,000 obs']
def crop(image,index,count):
    cols=min(3,count)
    x,y=45+410*(index%cols),55+225*(index//cols)
    return image[y:y+180,x:x+360]
def maps(old_root,new_root,old_records,new_records):
    count=0
    for name,rows in new_records.items():
        old=old_records[name]
        retained=[row for row in old if row['label'] not in DROP]
        assert rows==retained,name
        a=np.array(Image.open(old_root/name).convert('RGB'))
        b=np.array(Image.open(new_root/name).convert('RGB'))
        for i,row in enumerate(rows):
            j=next(j for j,previous in enumerate(old) if row['label']==previous['label'])
            np.testing.assert_array_equal(crop(a,j,len(old)),crop(b,i,len(rows)),err_msg=name+row['label'])
            count+=1
    return count
old=json.loads(Path('/tmp/global-physical-om4-maps/figures/results.json').read_text())
new=json.loads((T/'maps/results.json').read_text())
assert list(new['checkpoints'])==KEEP
assert new['checkpoints']=={k:old['checkpoints'][k] for k in KEEP}
assert new['reference_coverage']==old['reference_coverage']
assert new['om4_map_reference']==old['om4_map_reference']
assert len(new['maps'])==54
map_tiles=maps(Path('/tmp/global-physical-om4-maps/figures'),T/'maps',old['maps'],new['maps'])
a=json.loads(Path('/tmp/global-physical-comparison/initializer/results.json').read_text())
b=json.loads((T/'initializer/results.json').read_text())
assert a['sources']==b['sources']
initializer_tiles=0
for origin,records in b['origins'].items():
    original=a['origins'][origin]
    assert records['monthly_context']==original['monthly_context']
    assert records['reference_anomaly_rms_by_depth']==original['reference_anomaly_rms_by_depth']
    assert records['context_agreement']=={k:v for k,v in original['context_agreement'].items() if k not in ['obs00050','obs00500','obs02000']}
    for region,entry in records['profiles'].items():
        before=original['profiles'][region]
        assert entry['bounds']==before['bounds'] and entry['cells_by_depth']==before['cells_by_depth']
        assert entry['means']=={k:v for k,v in before['means'].items() if k not in ['obs00050','obs00500','obs02000']}
    initializer_tiles+=maps(Path('/tmp/global-physical-comparison/initializer'),T/'initializer',original['maps'],records['maps'])
assert len(list((T/'initializer').glob('*.png')))==21
out={'models':KEEP,'maps':54,'initializer_figures':21,'map_tiles_compared':map_tiles,'initializer_map_tiles_compared':initializer_tiles,'checks':['No early/developing/middle models in regenerated model panels, profiles or sections','All retained model, observation, climatology, proxy and OM4 map tiles are pixel-identical at 360 by 180 pixels','All retained ranges, color-limit counts, observation coverage and checkpoint metrics/lineage identical','All retained initializer regional profile means, supports, per-depth errors and anomaly summaries exactly reproduce prior results','Date-matched OM4 reference manifest identical','All day30/day365 final spectra and annual mean figures reused unchanged']}
(T/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('ENDPOINT_AUDIT_PASS',out,flush=True)
