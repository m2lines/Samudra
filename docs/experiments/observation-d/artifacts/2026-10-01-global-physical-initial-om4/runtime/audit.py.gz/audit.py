# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import gzip,hashlib,json
import numpy as np
import pandas as pd
from PIL import Image
R=Path('/home/jder/.codex/worktrees/d-observation-pilot/Ocean_Emulator')
T=Path('/tmp/global-physical-initial-om4')
OLD=R/'docs/experiments/observation-d/artifacts/2026-10-01-global-physical-endpoints'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
new=json.loads((T/'maps/results.json').read_text())
old=json.loads(gzip.decompress((OLD/'map-results.json.gz').read_bytes()))
m=json.loads((T/'om4/COMPLETE.json').read_text())
previous=json.loads(Path('/tmp/global-physical-om4-maps/om4/COMPLETE.json').read_text())
assert m['metadata_sha256']==previous['metadata_sha256']
assert m['grid_sha256']==previous['grid_sha256']
assert m['fields']==['thetao_9','so_0','uo_0','vo_0']
# Existing forecast references must be identical despite re-extraction.
for lead in [30,365]:
    a=dict(np.load(T/'om4'/f'om4-day{lead}.npz'))
    b=dict(np.load(Path('/tmp/global-physical-om4-maps/om4')/f'om4-day{lead}.npz'))
    assert a.keys()==b.keys()
    for key in a:np.testing.assert_array_equal(a[key],b[key])
initial=dict(np.load(T/'om4/om4-day0.npz'))
assert initial['values'].shape==(3,4,180,360)
assert initial['fields'].tolist()==['thetao_9','so_0','uo_0','vo_0']
assert all(m['field_attributes'][k]['units']=='m s-1' for k in ['uo_0','vo_0'])
initial_intervals=[i for i in m['alignment'] if i['lead_days']==0]
assert [i['covered_days'] for i in initial_intervals]==[5,5,4]
for i in initial_intervals:
    start=pd.Timestamp(i['origin'])-pd.Timedelta(days=5)
    end=pd.Timestamp(i['origin'])
    assert i['start']==str(start.date()) and i['end']==str(end.date())
    overlap=np.array([max(0,(min(pd.Timestamp(t)+pd.Timedelta(days=2.5),end)-max(pd.Timestamp(t)-pd.Timedelta(days=2.5),start)).total_seconds()/86400) for t in i['source_midpoints']])
    assert np.isclose(overlap.sum(),i['covered_days'])
    np.testing.assert_allclose(overlap/overlap.sum(),i['overlap_weights'])
    assert i['complete']==bool(np.isclose(overlap.sum(),5))
    assert bool(i['sampling_caveat'])==(not i['complete'])
assert new['checkpoints']==old['checkpoints']
assert new['reference_coverage']==old['reference_coverage']
changed=[];unchanged=[];tiles=0
for name,rows in old['maps'].items():
    after=new['maps'][name]
    update='-initial-channel4.' in name or '-initial-channel5.' in name
    if update:
        assert after[:-1]==rows
        assert after[-1]['label'].startswith('OM4')
        origin=name.split('-initial-')[0]
        if origin=='2021-01-01':
            assert '2020-12-26 to 2020-12-30' in after[-1]['label']
            assert '(4/5 days overlap)' in after[-1]['label']
        else:
            year=int(origin[:4])-1
            assert f'{year}-12-27 to {year}-12-31' in after[-1]['label']
        a=np.array(Image.open(OLD/name).convert('RGB'))
        b=np.array(Image.open(T/'maps'/name).convert('RGB'))
        for index in range(len(rows)):
            x,y=45+410*(index%3),55+225*(index//3)
            np.testing.assert_array_equal(a[y:y+180,x:x+360],b[y:y+180,x:x+360])
            tiles+=1
        changed.append(name)
    else:
        assert after==rows
        assert sha(OLD/name)==sha(T/'maps'/name)
        unchanged.append(name)
assert len(changed)==6 and len(unchanged)==48 and tiles==24
out={'updated_maps':changed,'unchanged_maps':unchanged,'retained_tiles_compared':tiles,'initialization_intervals':initial_intervals,'checks':['Six initializer U/V maps have one additional OM4 model-data sample','All 24 original model/DUACS tiles remain pixel-identical at 360 by 180 pixels','All 48 other field maps are byte-identical','Source dataset fingerprint, grid coordinates, velocity units and field names match','Existing day30/day365 OM4 reference arrays are identical','Initial references use the same final history window; December31,2020 is unavailable under midpoint plus/minus2.5day convention and explicitly labeled four-of-five-day overlap','Archive/member hashes and successful CPU completion verified','Checkpoint lineage, reported scores, spectra, annual means and training unchanged']}
(T/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('INITIAL_OM4_AUDIT_PASS',len(changed),'updated',len(unchanged),'unchanged',tiles,'original tiles retained')
