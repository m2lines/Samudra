# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
import gzip,hashlib,json
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path('/home/jder/.codex/worktrees/d-observation-pilot/Ocean_Emulator')
TMP=Path('/tmp/global-physical-om4-maps')
OLD=ROOT/'docs/experiments/observation-d/artifacts/2026-10-01-global-physical-comparison'
a=json.loads((TMP/'figures/results.json').read_text());b=json.load(gzip.open(OLD/'results.json.gz'))
changed=[];unchanged=[]
for name,old_rows in b['maps'].items():
 new_rows=a['maps'][name]
 needs_om4=any('-'+phase+'-' in name for phase in ['day30','day365']) and name[-5] in '1245'
 old_path=OLD/name;new_path=TMP/'figures'/name
 if needs_om4:
  assert new_rows[:-1]==old_rows
  assert new_rows[-1]['label'].startswith('OM4 model-data sample:')
  before=np.array(Image.open(old_path).convert('RGB'));after=np.array(Image.open(new_path).convert('RGB'))
  for i in range(len(old_rows)):
   left,top=45+410*(i%3),55+225*(i//3)
   np.testing.assert_array_equal(before[top:top+180,left:left+360],after[top:top+180,left:left+360])
  changed.append(name)
 else:
  assert new_rows==old_rows
  assert hashlib.sha256(old_path.read_bytes()).hexdigest()==hashlib.sha256(new_path.read_bytes()).hexdigest()
  unchanged.append(name)
assert len(changed)==24 and len(unchanged)==30
assert a['reference_coverage']==b['reference_coverage']
assert a['checkpoints']==b['checkpoints']
output={'updated_maps':changed,'untouched_maps':unchanged,'verification':['24 maps have one additional explicitly date-labeled OM4 model-data panel','Every pre-existing model/reference map tile is pixel-identical at one pixel per grid cell','All 30 unaffected maps (initialization and surface SST/SSH) are byte-identical','Every pre-existing color-limit/min/max statistic and observation coverage is unchanged','Fixed checkpoint and evaluation lineage is unchanged']}
(TMP/'map-audit.json').write_text(json.dumps(output,indent=2)+'\n')
print('MAP_AUDIT_PASS',len(changed),'updated',len(unchanged),'unchanged',flush=True)
