# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
import importlib.util, json
from pathlib import Path
import numpy as np
p=Path('/tmp/global-physical-curves-ema')
spec=importlib.util.spec_from_file_location('curves','scripts/plot_global_scratch_curves.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[{'global_step':x,'validation/obs_score':y} for x,y in [(0,1),(500,3),(1500,4)]]
np.testing.assert_allclose(m.smooth_scores(rows,500),[1,2,3.5],rtol=0,atol=0)
np.testing.assert_allclose(m.smooth_scores([{'global_step':x,'validation/obs_score':6} for x in [1,3,701,9600]],500),6,rtol=0,atol=1e-14)
for h in [0,-1,float('nan'),float('inf')]:
    try:m.smooth_scores(rows,h)
    except ValueError:pass
    else:raise AssertionError('Invalid half-life accepted')
for bad in [[],[rows[0],rows[0]],[rows[1],rows[0]],[{'global_step':1,'validation/obs_score':float('nan')}]]:
    try:m.smooth_scores(bad,500)
    except ValueError:pass
    else:raise AssertionError('Invalid history accepted')
a=json.loads((p/'input.json').read_text())['curves']
b=json.loads((p/'training-logs.json').read_text())
c=json.loads((p/'figures/validation-curve-results.json').read_text())
for k in a:
    for field in ['source_sha256','manifest_sha256','producer','complete']:
        assert a[k][field]==b[k][field],(k,field)
    assert [{f:v for f,v in r.items() if f!='elapsed_training_seconds'} for r in a[k]['validation']]==b[k]['validation']
    assert c['models'][k]['raw_validation']==a[k]['validation']
    np.testing.assert_allclose(c['models'][k]['ema_validation_scores'],m.smooth_scores(a[k]['validation'],500),rtol=0,atol=0)
    assert list(c['models'][k]['fixed_milestones'])==(['8000'] if k=='mixed' else ['8000','16000'])
    print(k,len(a[k]['validation']),'raw validation events exactly match current completed source logs')
(p/'audit.json').write_text(json.dumps({'half_life_updates':500,'checks':['Analytic irregular-spacing EMA case exactly reproduced','Constant sequence unchanged within floating-point rounding (absolute tolerance 1e-14)','Invalid half-life, empty/unordered/repeated-step and nonfinite-score inputs rejected','All 337 archived validation rows reproduce current source log records and identical source/manifest/producer/completion hashes; derived elapsed time field excluded from live event comparison','Output raw rows and EMA arrays reproduce verified input histories and smoothing exactly','Only the three report endpoints have checkpoint markers','No checkpoint selection or forecast-result change']},indent=2)+'\n')
print('EMA_AND_SOURCE_CHECKS_PASS')
