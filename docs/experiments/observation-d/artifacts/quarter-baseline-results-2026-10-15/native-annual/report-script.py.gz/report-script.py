#!/usr/bin/env python3
"""CPU-only native annual reporting from four immutable forecast exports."""
import csv
import json
import os
from pathlib import Path
import sys

import numpy as np

from samudra.constants import build_om4_layout
from samudra.experiments.annual_artifacts import annual_output_hashes
from samudra.experiments.observation_pilot import digest
from scripts.collect_presentation_annual import collect
from scripts.export_presentation_annual_maps import export
from scripts.plot_observation_rollout_maps import plot as plot_maps
from scripts.plot_presentation_annual import plot_comparison


def require(ok,message):
    if not ok: raise ValueError(message)


def weighted_profile(values, mask, latitude):
    """Physical Celsius mean/RMS on fixed per-depth model wet support."""
    values=np.asarray(values,dtype=np.float64)
    wet=np.asarray(mask,dtype=bool)
    require(values.shape==wet.shape, 'Profile grid differs')
    require(np.isfinite(values[wet]).all(), 'Nonfinite wet model temperature')
    weight=wet*np.cos(np.deg2rad(latitude))[None,:,None]
    total=weight.sum((1,2))
    require((total>0).all(), 'Empty profile depth support')
    filled=np.where(wet,values,0)
    return (filled*weight).sum((1,2))/total, np.sqrt((filled**2*weight).sum((1,2))/total)


def prepare_views(stage, output):
    task=json.loads((stage/'config.json').read_text())
    views=output/'annual-views'; views.mkdir()
    common=None
    models=[]
    for model in task['models']:
        source=Path(model['evaluation'])
        result_path=Path(str(source)+'-RESULT.json')
        require(digest(result_path)==model['result_sha256'], 'Evaluation result receipt differs')
        result=json.loads(result_path.read_text())
        require(result['passed'] is True, 'Annual mode incomplete')
        require(result['evaluation_producer']==task['producer'], 'Evaluation producer differs')
        for name,expected in result['outputs'].items():
            p=source/name
            require(p.stat().st_size==expected['bytes'] and digest(p)==expected['sha256'], 'Annual export changed: '+str(p))
        complete=json.loads((source/'COMPLETE.json').read_text())
        signature=complete['inputs']
        require(digest(source/'COMPLETE.json')==result['complete_sha256'], 'Completion receipt differs')
        require(sorted(complete['origins'])==task['origins'], 'Annual cohort differs')
        require('diagnostic_origin_subset' not in signature, 'Diagnostic subset forbidden')
        require(signature['checkpoint_sha256']==model['checkpoint_sha256'], 'Checkpoint differs')
        require(signature['sample_manifest_sha256']==task['sample_manifest_sha256'], 'Monthly observation archive differs')
        require(signature['include_persistence'] is True and signature['global_observations'] is True, 'Missing native global controls')
        if common is None: common=signature['data_manifests']
        else: require(common==signature['data_manifests'], 'Annual data cohort hashes differ')
        for rel,sha in signature['data_manifests'].items():
            require(digest(Path(task['annual_data'])/rel)==sha, 'Annual source manifest changed')
        models.append(model)
    config=dict(origins=task['origins'],observations=task['observations'],annual_data=task['annual_data'],
                iap_grid=str(Path(task['observations'])/'iap-grid.npz'),image=task['image'],models=models,
                reporting_scope='Native quarter model/surface grid and native half-degree IAP OHC; no cross-resolution comparison',
                producer=task['producer'])
    (views/'paths.json').write_text(json.dumps(config,indent=2)+'\n')
    for model in models:
        source=Path(model['evaluation']); folder=views/model['name']; folder.mkdir()
        for p in source.iterdir():
            (folder/p.name).symlink_to(p)
        complete=json.loads((folder/'COMPLETE.json').read_text())
        verified=dict(config_sha256=digest(views/'paths.json'),model=model,outputs=annual_output_hashes(folder,complete),
                      annual_mode_only=True,source_result_sha256=model['result_sha256'])
        (folder/'VERIFIED.json').write_text(json.dumps(verified,indent=2)+'\n')
    return task,views


def profiles(task, views, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with np.load(Path(task['observations'])/'grid.npz') as grid:
        names=grid['names'].tolist(); lat=grid['lat']; mask=grid['mask'].astype(bool)
    indices=[names.index(f'thetao_{i}') for i in range(19)]
    depths=build_om4_layout().depth_levels
    rows=[]
    for model in task['models']:
        for origin in task['origins']:
            with np.load(views/model['name']/(origin+'.npz')) as saved:
                initial=saved['initial'][-1,indices]
                states=saved['state_at_leads']
                leads=saved['leads_days'].tolist()
                for day,values in [(0,initial),(30,states[leads.index(30),indices]),(365,states[leads.index(365),indices])]:
                    mean,rms=weighted_profile(values,mask[indices],lat)
                    for depth,m,r in zip(depths,mean,rms,strict=True):
                        rows.append(dict(model=model['name'],origin=origin,lead_days=day,depth_m=depth,mean_celsius=float(m),rms_celsius=float(r)))
                del states
    with (output/'temperature-profiles.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    import pandas as pd
    frame=pd.DataFrame(rows)
    fig,axes=plt.subplots(1,3,figsize=(12,6),sharey=True)
    for name in [m['name'] for m in task['models']]:
        means=frame[frame.model==name].groupby(['lead_days','depth_m']).mean(numeric_only=True)['mean_celsius']
        for ax,day in zip(axes,(0,30,365),strict=True):
            ax.plot(means.loc[day].to_numpy(),depths,label=name)
            ax.set(title='Initialized state' if day==0 else f'Day {day}',xlabel='Wet-area mean temperature (°C)')
            ax.grid(alpha=.2)
    axes[0].set_ylabel('Model depth (m)');axes[0].invert_yaxis()
    handles,labels=axes[-1].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=2,fontsize=9)
    fig.suptitle('Native model temperature profiles · equal mean over three January starts\nPhysical state diagnostic; no full-depth observational truth is inferred')
    fig.tight_layout(rect=(0,.12,1,.90))
    fig.savefig(output/'temperature-profiles.png',dpi=160);fig.savefig(output/'temperature-profiles.pdf');plt.close(fig)
    (output/'temperature-profiles-provenance.json').write_text(json.dumps(dict(
        grid_sha256=digest(Path(task['observations'])/'grid.npz'),depths_m=depths,model_names=[m['name'] for m in task['models']],
        support='Per-depth fixed native model wet mask; cosine-latitude weights; exact same support across all four model/checkpoint outputs',
        temporal='Last inferred initial state and saved physical day30/day365 five-day means; equal average of per-origin profile means',
        interpretation='Model state diagnostic only; IAP observations are not upscaled or used as full-depth profile truth',
        temperature_units='degrees Celsius',script_sha256=digest(__file__)),indent=2)+'\n')


def main():
    stage=Path(__file__).resolve().parent;output=Path(sys.argv[1])
    from samudra.experiments.quarter_joint import verify_runtime
    verify_runtime(json.loads((stage/'config.json').read_text())['runtime_contract'])
    task,views=prepare_views(stage,output)
    result=output/'native-results'
    collect(views,result)
    import pandas as pd
    frame=pd.read_csv(result/'rmse-scores.csv')
    print(frame[frame.origin=='pooled'].to_csv(index=False),flush=True)
    groups={'native-selected':[m['name'] for m in task['models'] if m['policy']=='selected'],
            'native-fixed6000':[m['name'] for m in task['models'] if m['policy']=='fixed6000']}
    export(views,result/'results.json',output/'map-bundles',groups,own_persistence=True)
    plot_comparison(frame,[m['name'] for m in task['models']],result,
                    title='Native quarter baselines · same three origins · shared train-only climatology normalization',figsize=(12,6))
    profiles(task,views,result)
    for group in groups:
        plot_maps(output/'map-bundles'/(group+'-day365.npz'),result/'maps'/group,global_observations=True)
    hashes={str(p.relative_to(result)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in sorted(result.rglob('*')) if p.is_file()}
    (output/'REPORT_COMPLETE.json').write_text(json.dumps(dict(passed=True,producer=task['producer'],report_script_sha256=digest(__file__),
        config_sha256=digest(stage/'config.json'),annual_modes=task['models'],output_hashes=hashes),indent=2)+'\n')
    print(json.dumps(dict(event='native_report_complete',files=len(hashes))),flush=True)


if __name__=='__main__':main()
