#!/usr/bin/env python3
"""Bounded, read-only saved forecast/observation/OM4 surface extraction."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys
import time

import cftime
import numpy as np
import zarr


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def match_midpoint(times, start, end, midpoint):
    """Match nominal calendar dates, never convert Julian epoch to Gregorian epoch."""
    start, end, midpoint = [dt.datetime.fromisoformat(str(v)) for v in (start, end, midpoint)]
    require(end - start == dt.timedelta(days=5), 'Target is not a five-day bin')
    require(midpoint - start == dt.timedelta(days=2.5), 'Target midpoint differs')
    key = lambda d: (d.year, d.month, d.day, d.hour, d.minute, d.second)
    ids = [i for i, value in enumerate(times) if key(value) == key(midpoint)]
    require(len(ids) == 1, 'Missing or duplicate exact OM4 midpoint')
    i = ids[0]
    require(0 < i < len(times)-1, 'Cannot verify neighboring cadence')
    require(times[i]-times[i-1] == times[i+1]-times[i] == dt.timedelta(days=5), 'Non-five-day neighboring cadence')
    return i


def rectilinear_coordinates(lat, lon):
    lat, lon = np.asarray(lat), np.asarray(lon)
    if lat.ndim == lon.ndim == 2:
        require(lat.shape == lon.shape, 'Coordinate mesh shapes differ')
        require(np.array_equal(lat, np.broadcast_to(lat[:, :1], lat.shape)), 'Latitude mesh is not rectilinear')
        require(np.array_equal(lon, np.broadcast_to(lon[:1, :], lon.shape)), 'Longitude mesh is not rectilinear')
        lat, lon = lat[:, 0], lon[0, :]
    require(lat.ndim == lon.ndim == 1, 'Expected native rectilinear coordinates')
    return lat, lon


def main(stage, output):
    began = time.monotonic()
    config = json.loads((stage/'config.json').read_text())
    rawroot = Path(config['om4'])
    checks = {}
    def verify(path, expected=None):
        path = Path(path)
        actual = digest(path)
        if expected is not None:
            require(actual == expected, 'Hash differs: '+str(path))
        checks[str(path)] = actual
        return actual
    verify(Path(config['observations'])/'grid.npz', '8bbe0e235bc041176af70e374fe76ca1553ca5078cbe6d8384c7c9f5aca0755f')
    verify(rawroot/'COMPLETE.json', '9700cd5fdafdfdfa05fdfd355a5108770e8e99eaeb1642361389a3960a42ac42')
    verify(rawroot/'OM4.zarr/.zmetadata', '7e1701aea71dc682125da3c00febcfedc5590ba41ed23fa3d26bcfee574ee9d9')
    from samudra.experiments.quarter_joint import verify_runtime
    runtime = verify_runtime(Path(config['runtime_contract']))
    with np.load(Path(config['observations'])/'grid.npz') as grid:
        names = grid['names'].tolist()
        wet = grid['mask'][[names.index('thetao_0'), names.index('zos')]].astype(bool)
        lat, lon = grid['lat'], grid['lon']
    ds = zarr.open_consolidated(str(rawroot/'OM4.zarr'), mode='r')
    times = cftime.num2date(ds['time'][:], ds['time'].attrs['units'], ds['time'].attrs['calendar'])
    metadata=json.loads((rawroot/'OM4.zarr/.zmetadata').read_text())['metadata']
    require('time: mean' in metadata['.zattrs']['thetao']['cell_methods'], 'OM4 temperature is not an interval mean')
    require('time: mean' in metadata['.zattrs']['zos']['cell_methods'], 'OM4 zos is not an interval mean')
    require('interval-midpoint' in metadata['.zattrs']['m2lines/wfo_surgery_alignment'], 'Midpoint convention missing')
    for name in ['time', 'lat', 'lon', 'mask_0']:
        for path in sorted((rawroot/'OM4.zarr'/name).iterdir()):
            if path.is_file(): verify(path)
    om_lat, om_lon = rectilinear_coordinates(ds['lat'][:], ds['lon'][:])
    require(np.array_equal(om_lat, lat) and np.array_equal(om_lon, lon), 'Quarter OM4 and observation grids differ')
    om_wet = np.broadcast_to(ds['mask_0'][:].astype(bool), wet.shape).copy()
    origins=config['origins']; leads=[30,365]
    bins=[]; observed=[]; om4=[]
    for origin in origins:
        directory=Path(config['annual_data'])/'test'/origin
        manifest_path=directory/'COMPLETE.json'; verify(manifest_path)
        manifest=json.loads(manifest_path.read_text())
        require((manifest['history_bins'],manifest['forecast_bins'],manifest['bin_days'],len(manifest['records']))==(19,73,5,92), 'Annual cohort layout changed')
        origin_bins=[]; obs_fields=[]; om_fields=[]
        for lead in leads:
            record_index=manifest['history_bins'] + lead//manifest['bin_days'] - 1
            record=manifest['records'][record_index]; path=directory/record['file'];verify(path,record['sha256'])
            with np.load(path) as saved:
                start,end,midpoint=(str(saved[k]) for k in ['start','end','midpoint'])
                require(dt.datetime.fromisoformat(end)-dt.datetime.fromisoformat(origin)==dt.timedelta(days=lead), 'Actual target end does not match lead')
                idx=match_midpoint(times,start,end,midpoint)
                obs_fields.append(saved['surface'].copy())
            for variable,suffix in [('thetao','0.0.0'),('zos','0.0.0')]:
                chunk=f'{idx}.{suffix}' if variable=='thetao' else f'{idx}.0.0'
                verify(rawroot/'OM4.zarr'/variable/chunk)
            values=np.stack([ds['thetao'][idx,0,:,:],ds['zos'][idx,:,:]])
            require(np.isfinite(values[om_wet]).all(), 'Nonfinite wet OM4 surface')
            om_fields.append(values)
            origin_bins.append(dict(lead_days=lead,start=start,end=end,midpoint=midpoint,om4_index=idx,om4_time=str(times[idx]),weights=[1.0],record=record))
        observed.append(np.stack(obs_fields));om4.append(np.stack(om_fields));bins.append(origin_bins)
    observed=np.stack(observed);om4=np.stack(om4)
    common=dict(origins=np.array(origins),leads_days=np.array(leads),channels=np.array(['sst','ssh']),units=np.array(['degC','m']),lat=lat,lon=lon,target_bin_starts=np.array([[b['start'] for b in row] for row in bins]),target_bin_ends=np.array([[b['end'] for b in row] for row in bins]),target_bin_midpoints=np.array([[b['midpoint'] for b in row] for row in bins]))
    def write(name,fields,mask):
        require(fields.shape == (3,2,2,720,1440), 'Unexpected extracted field shape')
        require(not np.isinf(fields).any(), 'Infinite extracted field')
        np.savez_compressed(output/(name+'.npz'),fields=fields,wet=mask,**common)
    write('observations',observed,wet);write('om4',om4,om_wet)
    for model in config['models']:
        directory=Path(model['evaluation'])
        rp=Path(str(directory)+'-RESULT.json');verify(rp,model['result_sha256']);result=json.loads(rp.read_text())
        require(result['passed'] is True and result['evaluation_producer']==config['producer'], 'Evaluation receipt not passed/pinned')
        cp=directory/'COMPLETE.json';verify(cp,result['complete_sha256']);complete=json.loads(cp.read_text())
        require(sorted(complete['origins'])==origins and 'diagnostic_origin_subset' not in complete['inputs'], 'Not full annual cohort')
        require(complete['inputs']['checkpoint_sha256']==model['checkpoint_sha256'], 'Selected checkpoint differs')
        for rel,sha in complete['inputs']['data_manifests'].items(): verify(Path(config['annual_data'])/rel,sha)
        fields=[]
        for oi,origin in enumerate(origins):
            path=directory/(origin+'.npz');verify(path,result['outputs'][path.name]['sha256'])
            with np.load(path) as saved:
                surface=saved['surface']
                require(surface.shape[0]==73, 'Missing annual forecast bins')
                fields.append(surface[[5,72]])
                del surface
                require(np.array_equal(saved['reference'][[5,72],:2],observed[oi],equal_nan=True), 'Saved reference differs from exact annual source bins')
            print('extracted',model['name'],origin,flush=True)
        write(model['bundle'],np.stack(fields),wet)
    provenance=dict(passed=True,scope='CPU extraction only; no forecasts/weights/training',producer=config['producer'],config_sha256=digest(stage/'config.json'),origins=origins,leads_days=leads,bins=bins,inputs=checks,runtime=runtime,temporal_matching='Exact nominal calendar midpoint identity and neighboring five-day cadence; selected non-leap Jan26-Jan31 and Dec27-Jan1 bins. No interpolation/blending. Compact archive omits explicit time bounds; interval-mean/midpoint convention recorded in source metadata. Julian date components matched to Gregorian observational labels, consistent with training source calendar handling; not absolute Julian-to-Gregorian epoch conversion.',outputs={p.name:dict(sha256=digest(p),bytes=p.stat().st_size) for p in output.glob('*.npz')},elapsed_seconds=time.monotonic()-began)
    (output/'provenance.json').write_text(json.dumps(provenance,indent=2,default=str)+'\n')
    print('COMPLETE',provenance['elapsed_seconds'],flush=True)


if __name__=='__main__':
    main(Path(__file__).parent,Path(sys.argv[1]))
