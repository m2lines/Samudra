import datetime as dt
import importlib.util
from pathlib import Path
import cftime
import pytest

spec=importlib.util.spec_from_file_location('extract',Path(__file__).with_name('extract.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def test_exact_julian_date_components():
    t=[cftime.DatetimeJulian(2015,1,d,12) for d in [23,28]]+[cftime.DatetimeJulian(2015,2,2,12)]
    assert m.match_midpoint(t,'2015-01-26','2015-01-31','2015-01-28T12:00:00')==1


def test_no_nearest_or_interpolation_fallback():
    t=[cftime.DatetimeJulian(2015,1,d,12) for d in [18,23,28]]
    with pytest.raises(ValueError,match='exact OM4 midpoint'):
        m.match_midpoint(t,'2015-01-25','2015-01-30','2015-01-27T12:00:00')


def test_nonfive_day_target_rejected():
    with pytest.raises(ValueError,match='five-day bin'):
        m.match_midpoint([],'2015-01-26','2015-02-01','2015-01-28T12:00:00')


def test_six_day_boundary_rejected():
    t=[cftime.DatetimeJulian(2016,12,23,12),cftime.DatetimeJulian(2016,12,28,12),cftime.DatetimeJulian(2017,1,3,12)]
    with pytest.raises(ValueError,match='cadence'):
        m.match_midpoint(t,'2016-12-26','2016-12-31','2016-12-28T12:00:00')


def test_exact_mesh_collapse_and_nonrectilinear_rejection():
    import numpy as np
    lon,lat=np.meshgrid([0.125,0.375,0.625],[-1.25,1.25])
    actual_lat,actual_lon=m.rectilinear_coordinates(lat,lon)
    np.testing.assert_array_equal(actual_lat,[-1.25,1.25])
    np.testing.assert_array_equal(actual_lon,[0.125,0.375,0.625])
    lat[1,1]+=0.01
    with pytest.raises(ValueError,match='not rectilinear'):
        m.rectilinear_coordinates(lat,lon)
