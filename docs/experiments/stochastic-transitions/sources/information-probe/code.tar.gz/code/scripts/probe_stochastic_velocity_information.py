# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Initializer information probe: target-derived low-pass velocity is an oracle.

This is not a forecast protocol. It asks whether a fixed ConvNeXt initializer
can use explicitly supplied broad-current information under MSE versus CRPS.
No processor calls, future supervision, or new observations are introduced.
"""

import argparse
import copy
import csv
import gc
import json
import os
import subprocess
import threading
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

VARIANTS = {
    "standard-crps": (False, "fair-crps"),
    "oracle-crps": (True, "fair-crps"),
    "standard-mse": (False, "member-mse"),
    "oracle-mse": (True, "member-mse"),
}
VELOCITY = tuple(range(38))


def lowpass_velocity(target, mask, area, sigma=2.0):
    """Detached, mask/area-renormalized oracle; circular longitude, zero latitude.

    Input is normalized latest OM4 state. Smoothing normalized channels commutes
    with conversion to physical units because channel statistics are constants.
    Narrow land barriers can be crossed by this regular-grid Gaussian operator.
    """
    from samudra.experiments.stochastic_multiscale_loss import gaussian

    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError("Oracle Gaussian sigma must be positive")
    with torch.no_grad(), torch.autocast(device_type=target.device.type, enabled=False):
        truth = target[:, VELOCITY].detach().float()
        valid = mask[list(VELOCITY)].bool().unsqueeze(0) & torch.isfinite(truth)
        weight = valid * area
        safe = torch.where(valid, truth, 0)
        smoothed = gaussian(safe * weight, sigma) / gaussian(weight, sigma).clamp_min(
            1e-30
        )
        return torch.where(valid, smoothed, 0)


class InformationInitializer(nn.Module):
    """Preserve the original initializer, adding a zero-initialized side adapter."""

    def __init__(self, model, sigma=2.0, conditioning_channels=None):
        super().__init__()
        self.model = model
        self.sigma = sigma
        channels = (
            conditioning_channels
            or model.history * (2 * len(model.surface) + model.forcing_channels) + 5
        )
        # This initialization must not shift the existing model/noise RNG stream.
        with torch.random.fork_rng(devices=[]):
            self.oracle_adapter = nn.Conv2d(38, channels, 1, bias=False)
            nn.init.zeros_(self.oracle_adapter.weight)
        self.model.processor.requires_grad_(False)

    def forward(self, sample, area, *, oracle, members, generator):
        model = self.model
        surface = sample["surface"][:, : model.history]
        mask = sample["mask"]
        validity = mask[model.surface].bool().expand_as(surface)
        condition, _, _ = model.encode_native(
            surface,
            sample["atmosphere"][:, : model.history],
            sample["context"],
            mask,
            validity,
            return_anchors=False,
        )
        if oracle:
            extra = lowpass_velocity(sample["initial_target"], mask, area, self.sigma)
        else:
            # Do not access target values on the ordinary-input path.
            extra = condition.new_zeros(condition.shape[0], 38, *condition.shape[-2:])
        condition = condition + self.oracle_adapter(extra)
        condition = (
            condition.unsqueeze(0).expand(members, *condition.shape).flatten(0, 1)
        )
        state = model.initialize(condition, None, None, mask, generator)
        return state.reshape(
            members, surface.shape[0], 2, model.channels, *surface.shape[-2:]
        )[:, :, -1]


def initializer_loss(prediction, target, mask, area, objective):
    from samudra.experiments.stochastic_transition_objectives import average, score

    return 0.1 * average(
        *score(
            prediction,
            target,
            mask,
            area,
            1.0,
            deterministic=False,
            objective=objective,
        )
    )


def retain_parent_optimizer(wrapper, saved):
    """Original parameter ordering and Adam state are unchanged; add new group."""
    optimizer = torch.optim.AdamW(
        wrapper.model.parameters(),
        lr=1e-4,
        weight_decay=0.01,
        fused=next(wrapper.parameters()).device.type == "cuda",
    )
    optimizer.load_state_dict(copy.deepcopy(saved["optimizer"]))
    optimizer.add_param_group(
        dict(params=list(wrapper.oracle_adapter.parameters()), lr=1e-4)
    )
    for group in optimizer.param_groups:
        group["lr"] = 1e-4
    return optimizer


def trim_native(sample, history=19):
    """Clone only initializer tensors, releasing storage belonging to future data."""
    return dict(
        surface=sample["surface"][:, :history].clone(),
        initial_target=sample["initial_target"].clone(),
        atmosphere=sample["atmosphere"][:, :history].clone(),
        context=sample["contexts"][:, history - 1].clone(),
        mask=sample["mask"],
        first=sample["first"],
    )


def assert_same_tree(left, right):
    """Exact continuation proof; compare on CPU without dtype coercion."""
    if isinstance(left, torch.Tensor):
        torch.testing.assert_close(left.cpu(), right.cpu(), rtol=0, atol=0)
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            assert_same_tree(left[key], right[key])
    elif isinstance(left, (tuple, list)):
        assert len(left) == len(right)
        for a, b in zip(left, right, strict=True):
            assert_same_tree(a, b)
    else:
        assert left == right


def gpu_monitor(path, stop, measurements):
    identity = (
        str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-").lower()
    )
    with path.open("w") as f:
        while not stop.is_set():
            raw = subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=uuid,utilization.gpu,memory.used",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
                timeout=15,
            )
            rows = [
                r
                for r in csv.reader(raw.splitlines())
                if r[0].strip().removeprefix("GPU-").lower() == identity
            ]
            if len(rows) != 1:
                raise RuntimeError("Allocated GPU telemetry identity mismatch")
            row = dict(
                time=time.time(),
                utilization=float(rows[0][1]),
                memory_mib=float(rows[0][2]),
            )
            measurements.append(row)
            f.write(json.dumps(row) + "\n")
            f.flush()
            stop.wait(2)


def guarded_gpu_monitor(path, stop, failures, measurements):
    try:
        gpu_monitor(path, stop, measurements)
    except Exception as exc:
        failures.append(exc)


def check_monitor(failures):
    if failures:
        raise RuntimeError("GPU telemetry failed") from failures[0]


def active_utilization(telemetry, events):
    """Exclude startup and evaluation from GPU qualification."""
    active = [
        row["utilization"]
        for row in telemetry
        if any(
            event["started_unix"] <= row["time"] <= event["finished_unix"]
            for event in events
        )
    ]
    if len(active) < 3:
        raise RuntimeError("Fewer than three active-training GPU measurements")
    return dict(
        samples=len(active),
        mean_utilization=float(np.mean(active)),
        minimum_utilization=float(np.min(active)),
        maximum_utilization=float(np.max(active)),
    )


def heldout_cases(data, om4, months, output):
    import cftime
    import zarr

    from samudra.experiments.observation_pilot import atomic_json, digest

    store = zarr.open_consolidated(str(om4), mode="r")
    t = store["time"]
    labels = [
        d.strftime("%Y-%m-%dT%H:%M:%S")
        for d in cftime.num2date(
            t[:], t.attrs["units"], t.attrs.get("calendar", "standard")
        )
    ]
    names = data.grid["names"].tolist()
    mask = np.stack(
        [store[f"mask_{i}"][:] for i in range(19)] * 4 + [store["mask_0"][:]]
    ).astype(bool)
    np.testing.assert_array_equal(mask, data.grid["mask"])
    np.testing.assert_allclose(store["x"][:], data.grid["lon"], atol=1e-6, rtol=0)
    np.testing.assert_allclose(store["y"][:], data.grid["lat"], atol=1e-6, rtol=0)
    cases = []
    for month in months:
        path = data.root / "validation" / f"{month}.npz"
        if path not in data.paths("validation"):
            raise ValueError("Evaluation must use the fixed validation cohort")
        obs = data.load(path)
        wanted = (
            np.asarray(obs["raw"]["midpoints"][:19], dtype="datetime64[s]")
            .astype(str)
            .tolist()
        )
        if any(labels.count(x) != 1 for x in wanted):
            raise ValueError("No exact unique OM4 match for validation history")
        ids = [labels.index(x) for x in wanted]
        if not np.all(np.diff(ids) == 1) or wanted[-1] <= "2013-08-04":
            raise ValueError("Invalid held-out history cadence or date")
        surface = np.stack(
            [np.stack([store[n][i] for n in ["thetao_0", "zos"]]) for i in ids]
        ).astype("float32")
        gold = np.stack([store[n][ids[-1]] for n in names]).astype("float32")
        if (
            not np.isfinite(gold[mask]).all()
            or not np.isfinite(surface[:, mask[[38, 76]]]).all()
        ):
            raise ValueError("Nonfinite wet input/target")
        normal = np.where(
            mask,
            (gold - data.grid["mean"][:, None, None]) / data.grid["std"][:, None, None],
            0,
        )
        surface = np.where(
            mask[[38, 76]],
            (surface - data.grid["mean"][[38, 76], None, None])
            / data.grid["std"][[38, 76], None, None],
            0,
        )
        sample = dict(
            surface=data.tensor(surface)[None],
            initial_target=data.tensor(normal)[None],
            atmosphere=obs["atmosphere"][:, :19],
            context=obs["contexts"][:, 18],
            mask=data.mask,
        )
        cases.append((month, sample, data.tensor(np.where(mask, gold, 0))))
        atomic_json(
            dict(
                month=month,
                history_midpoints=wanted,
                history_indices=ids,
                sample_sha256=digest(path),
                om4_metadata_sha256=digest(om4 / ".zmetadata"),
                grid_sha256=digest(data.root / "grid.npz"),
                diagnostic_note="Oracle variants receive contemporaneous low-pass gold velocity. This is not forecasting.",
            ),
            output / f"input-{month}.json",
        )
    return cases


@torch.no_grad()
def evaluate(wrapper, data, cases, output, variant, step, weights, oracle):
    from diagnose_stochastic_velocity import detailed

    from samudra.experiments.observation_pilot import atomic_json

    wrapper.eval()
    selection = [0, 9, 18, 19, 28, 37]
    for month, sample, gold in cases:
        generator = torch.Generator(device="cuda").manual_seed(904003)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            normalized = wrapper(
                sample, data.area, oracle=oracle, members=8, generator=generator
            )[:, 0]
        draws = normalized.float() * data.std[0, 0] + data.mean[0, 0]
        if not torch.isfinite(draws).all():
            raise FloatingPointError("Nonfinite initializer evaluation")
        values, bins = detailed(draws, gold, data.mask, data.tensor(data.grid["lat"]))
        baseline = gold.clone()
        smooth = lowpass_velocity(
            sample["initial_target"], data.mask, data.area, wrapper.sigma
        )[0]
        baseline[:38] = smooth * data.std[0, 0, :38] + data.mean[0, 0, :38]
        oracle_metrics, oracle_bins = detailed(
            baseline.unsqueeze(0).expand(8, *baseline.shape),
            gold,
            data.mask,
            data.tensor(data.grid["lat"]),
        )
        stem = f"{variant}-{step:05d}-{weights}-{month}"
        atomic_json(
            dict(
                variant=variant,
                step=step,
                weights=weights,
                month=month,
                members=8,
                oracle_input=oracle,
                metrics={k: v.tolist() for k, v in values.items()},
                speed_bins=bins,
                oracle_velocity_baseline={
                    k: v[:38].tolist() for k, v in oracle_metrics.items()
                },
                oracle_speed_bins=oracle_bins,
            ),
            output / f"{stem}.json",
        )
        np.savez_compressed(
            output / f"{stem}-maps.npz",
            members=draws[:, selection].cpu().numpy(),
            gold=gold[selection].cpu().numpy(),
            oracle=baseline[selection].cpu().numpy(),
        )


def main():
    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_pilot import atomic_json, atomic_torch, digest
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.physical_state_prefetch import native_to_device
    from samudra.experiments.physical_state_train import update_ema
    from samudra.experiments.shared_era5 import SharedEra5
    from samudra.experiments.stochastic_transition_data import (
        CompactNativeLoader,
        verified_local_frames,
    )
    from samudra.experiments.stochastic_transition_train import build_model, restore_rng
    from samudra.experiments.task_schedule import sample_indices

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--paths", type=Path, required=True)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument(
        "--variants", nargs="+", choices=list(VARIANTS), default=list(VARIANTS)
    )
    p.add_argument("--updates", type=int, default=128, choices=[128])
    p.add_argument(
        "--qualification",
        action="store_true",
        help="Only 16 matched updates per selected arm; never marks science complete",
    )
    p.add_argument("--effective-batch", type=int, default=8)
    p.add_argument("--members", type=int, default=4)
    p.add_argument("--seed", type=int, default=1729)
    p.add_argument("--sigma", type=float, default=2.0)
    p.add_argument("--minimum-utilization", type=float, default=50.0)
    p.add_argument("--node-local-root", type=Path)
    p.add_argument("--node-local-receipt", type=Path)
    p.add_argument(
        "--om4-gold",
        type=Path,
        default=Path("/scratch/jr7309/data/om4_onedeg_v3/OM4.zarr"),
    )
    p.add_argument("--months", nargs="+", default=["2014-01", "2014-04", "2014-05"])
    args = p.parse_args()
    updates = 16 if args.qualification else args.updates
    completion_name = (
        "QUALIFICATION_COMPLETE.json" if args.qualification else "COMPLETE.json"
    )
    if args.effective_batch != 8 or args.members != 4:
        raise ValueError("Matched probe fixes effective batch8 and4members")
    if len(set(args.variants)) != len(args.variants):
        raise ValueError("Duplicate variants")
    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError("Use a fresh output directory")
    args.output.mkdir(parents=True, exist_ok=True)
    paths = json.loads(args.paths.read_text())
    if bool(args.node_local_root) != bool(args.node_local_receipt):
        raise ValueError("Supply both node-local root and receipt")
    if os.environ.get("SLURM_JOB_ID") and not args.node_local_receipt:
        raise ValueError("Slurm probe requires same-job node-local readback receipt")
    verified = ()
    if args.node_local_root:
        if (
            args.node_local_receipt.name
            != f"node-local-{os.environ.get('SLURM_JOB_ID')}.json"
        ):
            raise ValueError("Node-local receipt does not identify this job")
        paths["packed_om4"] = str(args.node_local_root / "packed_om4")
        paths["forcing_cache"] = str(args.node_local_root / "forcing_cache")
        verified = verified_local_frames(
            paths["packed_om4"], args.node_local_receipt, args.node_local_root
        )
    torch.set_num_threads(1)
    torch.cuda.set_device(0)
    data = Samples(
        Path(paths["samples"]), "cuda", surface_fill="zero", global_observations=True
    )
    cpu = Samples(
        Path(paths["samples"]), "cpu", surface_fill="zero", global_observations=True
    )
    expected_names = [
        f"{field}_{depth}"
        for field in ["uo", "vo", "thetao", "so"]
        for depth in range(19)
    ] + ["zos"]
    if data.grid["names"].tolist() != expected_names:
        raise ValueError("Unexpected full-state channel order")
    reader = ModelMonths(
        Path(paths["om4"]) / "OM4.zarr",
        "om4",
        data.grid,
        Path(paths["om4"]),
        packed=Path(paths["packed_om4"]),
    )
    if len(reader.windows) != 409:
        raise ValueError("Training cohort changed")
    forcing = SharedEra5(
        paths["forcing_cache"],
        reader,
        data,
        paths["forcing_proof_sha256"],
        full_readback=True,
    )
    loader = CompactNativeLoader(
        reader, forcing, cpu, verified_frames=verified, resident=False
    )
    streams = [
        sample_indices(
            len(reader.windows), args.seed + 100003, 1000 + step, args.effective_batch
        )
        for step in range(updates)
    ]
    selected = sorted({i for ids in streams for i in ids})
    tic = time.monotonic()
    cache = {i: trim_native(loader(i)) for i in selected}
    cache_seconds = time.monotonic() - tic
    del loader
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if (
        saved["step"] != 2000
        or saved["counts"] != {"om4": 1000, "observation": 1000}
        or saved["contract"]["arm"] != "B"
        or saved["contract"]["seed"] != args.seed
    ):
        raise ValueError("Expected original mixed B2k checkpoint")
    if saved["contract"]["grid"] != digest(Path(paths["samples"]) / "grid.npz"):
        raise ValueError("Normalization grid changed")
    atomic_json(
        dict(
            parent_sha256=digest(args.checkpoint),
            parent_contract=saved["contract"],
            variants=args.variants,
            updates=updates,
            qualification_only=args.qualification,
            effective_batch=8,
            members=4,
            seed=args.seed,
            learning_rate=1e-4,
            initializer_weight=0.1,
            retained_adam=True,
            reset_ema_to_raw=True,
            processor_frozen=True,
            oracle_sigma_grid_cells=args.sigma,
            oracle_channels=list(VELOCITY),
            oracle_adapter="zero-initialized38-to-existing-conditioning1x1,biasfalse,presentinallarms",
            actual_sample_indices=streams,
            train_cache_samples=len(cache),
            train_cache_seconds=cache_seconds,
            cpu_cache_bytes=sum(
                x[k].numel() * x[k].element_size()
                for x in cache.values()
                for k in ["surface", "initial_target", "atmosphere", "context"]
            ),
            script_sha256=digest(Path(__file__)),
            node_local_receipt=str(args.node_local_receipt),
            interpretation="Target-derived contemporaneous oracle, diagnostic only; not a forecast or usable observational input.",
        ),
        args.output / "protocol.json",
    )
    cases = heldout_cases(data, args.om4_gold, args.months, args.output)
    np.savez_compressed(
        args.output / "grid.npz",
        **{**data.grid, "selection": np.array([0, 9, 18, 19, 28, 37])},
    )
    for variant in args.variants:
        oracle, objective = VARIANTS[variant]
        dest = args.output / variant
        dest.mkdir()
        model = build_model(saved, data, use_ema=False)
        wrapper = InformationInitializer(model, sigma=args.sigma).to("cuda")
        optimizer = retain_parent_optimizer(wrapper, saved)
        restore_rng(saved["rank_rng"][0])
        ema = copy.deepcopy(wrapper).eval().requires_grad_(False)
        assert_same_tree(wrapper.model.state_dict(), saved["model"])
        assert_same_tree(optimizer.state_dict()["state"], saved["optimizer"]["state"])
        assert_same_tree(wrapper.state_dict(), ema.state_dict())
        assert wrapper.oracle_adapter.weight.count_nonzero().item() == 0
        atomic_json(
            dict(
                parent_raw_exact=True,
                parent_adam_state_exact=True,
                ema_reset_exact=True,
                adapter_zero=True,
                processor_frozen=True,
                parent_sha256=digest(args.checkpoint),
                objective=objective,
                oracle=oracle,
            ),
            dest / "initialization-proof.json",
        )
        stop = threading.Event()
        failures = []
        measurements = []
        telemetry = threading.Thread(
            target=guarded_gpu_monitor,
            args=(dest / "gpu.jsonl", stop, failures, measurements),
            daemon=True,
        )
        telemetry.start()
        events = []
        try:
            evaluate(wrapper, data, cases, dest, variant, 0, "raw", oracle)
            for step, indices in enumerate(streams):
                check_monitor(failures)
                started = time.time()
                wrapper.train()
                optimizer.zero_grad(set_to_none=True)
                total = torch.zeros((), device="cuda")
                wait = 0.0
                for offset, index in enumerate(indices):
                    before = time.monotonic()
                    sample = native_to_device(cache[index], "cuda")
                    wait += time.monotonic() - before
                    generator = torch.Generator(device="cuda").manual_seed(
                        args.seed + (2000 + step) * 1000003 + offset * 1009
                    )
                    with torch.autocast("cuda", dtype=torch.bfloat16):
                        pred = wrapper(
                            sample,
                            data.area,
                            oracle=oracle,
                            members=4,
                            generator=generator,
                        )
                        loss = (
                            initializer_loss(
                                pred,
                                sample["initial_target"],
                                sample["mask"],
                                data.area,
                                objective,
                            )
                            / 8
                        )
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Nonfinite probe loss")
                    loss.backward()
                    total += loss.detach()
                norm = torch.nn.utils.clip_grad_norm_(
                    wrapper.parameters(), 1.0, error_if_nonfinite=True
                )
                optimizer.step()
                update_ema(ema, wrapper, 100)
                torch.cuda.synchronize()
                event = dict(
                    step=step + 1,
                    loss=total.item(),
                    grad_norm=norm.item(),
                    seconds=time.time() - started,
                    data_wait_seconds=wait,
                    started_unix=started,
                    finished_unix=time.time(),
                    sample_indices=indices,
                )
                with (dest / "events.jsonl").open("a") as f:
                    f.write(json.dumps(event) + "\n")
                events.append(event)
                print(json.dumps(dict(variant=variant, **event)), flush=True)
                if step + 1 == 16:
                    check_monitor(failures)
                    utilization = active_utilization(list(measurements), events)
                    passed = utilization["mean_utilization"] > args.minimum_utilization
                    atomic_json(
                        dict(
                            updates=16,
                            passed=passed,
                            threshold=args.minimum_utilization,
                            **utilization,
                        ),
                        dest / "qualification.json",
                    )
                    if not passed:
                        raise RuntimeError(
                            "GPU utilization qualification failed; remaining updates withheld"
                        )
                if step + 1 in (64, updates):
                    atomic_torch(
                        dict(
                            parent_sha256=digest(args.checkpoint),
                            variant=variant,
                            step=step + 1,
                            model=wrapper.state_dict(),
                            ema=ema.state_dict(),
                            optimizer=optimizer.state_dict(),
                            oracle=oracle,
                            objective=objective,
                        ),
                        dest / f"step-{step + 1:05d}.pt",
                    )
                    for w, network in [("raw", wrapper), ("ema", ema)]:
                        evaluate(
                            network, data, cases, dest, variant, step + 1, w, oracle
                        )
        finally:
            stop.set()
            telemetry.join(timeout=20)
        check_monitor(failures)
        if telemetry.is_alive():
            raise RuntimeError("GPU telemetry failed to stop")
        atomic_json(
            dict(
                complete=True,
                updates=updates,
                qualification_only=args.qualification,
                om4_examples=updates * 8,
                observation_examples=0,
            ),
            dest / completion_name,
        )
        del wrapper, model, ema, optimizer
        gc.collect()
        torch.cuda.empty_cache()
    atomic_json(
        dict(
            complete=True,
            variants=args.variants,
            updates_per_arm=updates,
            qualification_only=args.qualification,
        ),
        args.output / completion_name,
    )


if __name__ == "__main__":
    main()
