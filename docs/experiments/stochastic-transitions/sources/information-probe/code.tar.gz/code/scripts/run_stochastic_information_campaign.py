# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Stage verified caches and run the four short initializer information probes."""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from stochastic_campaign_cache import stage_caches


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    paths = json.loads((args.root / "paths.json").read_text())
    stage_caches(args.root, paths)
    subprocess.run(
        [
            sys.executable,
            "/pilot-code/scripts/probe_stochastic_velocity_information.py",
            "--paths",
            str(args.root / "paths.json"),
            "--checkpoint",
            "/scratch/jr7309/stochastic-transitions-20261027/production/B/step-02000.pt",
            "--output",
            str(args.root / "results"),
            "--node-local-root",
            os.environ["ONEPASS_LOCAL_DATA"],
            "--node-local-receipt",
            str(args.root / f"node-local-{os.environ['SLURM_JOB_ID']}.json"),
        ],
        check=True,
    )


if __name__ == "__main__":
    main()
