# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Matched noise ablations, qualified on their first 24 production updates."""

import argparse
import json
import math
import os
import subprocess
import sys
import threading
from pathlib import Path

from qualify_stochastic_transitions import command, gpu_identity, monitor
from stochastic_campaign_cache import stage_caches

VARIANTS = {
    "B-control": ("iid", 0),
    "B-multiscale-noise": ("multiscale", 0),
    "B-noise-processing": ("iid", 3),
}


def run(args):
    paths = json.loads((args.root / "paths.json").read_text())
    stage_caches(args.root, paths)
    out = args.root / "production" / args.variant
    out.mkdir(parents=True, exist_ok=True)
    noise, blocks = VARIANTS[args.variant]
    base = command(paths, out, "B", 1) + [
        "--objective",
        "fair-crps",
        "--main-updates",
        "2000",
        "--cooldown-updates",
        "0",
        "--checkpoint-every",
        "500",
        "--seed",
        "1729",
        "--noise-mode",
        noise,
        "--noise-processing-blocks",
        str(blocks),
        "--hours",
        "14",
    ]
    if (out / "last.pt").exists():
        raise ValueError("Use a reviewed resume command for an existing run")
    identity = gpu_identity()
    stop = threading.Event()
    errors = []

    def telemetry():
        try:
            monitor(out / "gpu.jsonl", stop, identity)
        except Exception as error:
            errors.append(repr(error))

    worker = threading.Thread(target=telemetry, daemon=True)
    worker.start()
    try:
        subprocess.run(base + ["--max-new-updates", "24"], check=True)
        import torch

        saved = torch.load(out / "last.pt", map_location="cpu", weights_only=False)
        if saved["step"] != 24 or saved["counts"] != {"om4": 12, "observation": 12}:
            raise ValueError("Qualification exposure differs")
        for section in ("model", "ema"):
            if not all(
                torch.isfinite(value).all() for value in saved[section].values()
            ):
                raise ValueError("Nonfinite checkpoint")
        del saved
        rows = [
            json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()
        ]
        if [r["step"] for r in rows] != list(range(1, 25)):
            raise ValueError("Incomplete qualification log")
        if not all(
            math.isfinite(r["loss"]) and math.isfinite(r["grad_norm"]) for r in rows
        ):
            raise ValueError("Nonfinite optimization")
        warm = rows[4:]
        samples = [
            json.loads(line) for line in (out / "gpu.jsonl").read_text().splitlines()
        ]
        active = [
            s
            for s in samples
            if any(
                r["update_started_unix"] <= s["time"] <= r["update_finished_unix"]
                for r in warm
            )
        ]
        if errors or len(active) < 20:
            raise RuntimeError(f"Insufficient telemetry: {errors}")
        utilization = sum(r["utilization"] for r in active) / len(active)
        gate = dict(
            passed=utilization > 50,
            variant=args.variant,
            updates=24,
            mean_gpu_utilization_percent=utilization,
            mean_update_seconds=sum(r["seconds"] for r in warm) / len(warm),
            mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm)
            / len(warm),
            peak_memory_mib=max(r["memory_mib"] for r in active),
            source=os.environ["SAMUDRA_CODE_COMMIT"],
        )
        (out / "QUALIFIED.json").write_text(json.dumps(gate, indent=2) + "\n")
        print(json.dumps({"qualification": gate}), flush=True)
        if not gate["passed"]:
            raise RuntimeError("GPU utilization did not exceed approved 50% threshold")
        subprocess.run(base + ["--resume"], check=True)
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or errors:
        raise RuntimeError(f"Telemetry failed: {errors}")
    completion = json.loads((out / "COMPLETE.json").read_text())
    if completion["counts"] != {"om4": 1000, "observation": 1000}:
        raise ValueError("Production source exposure differs")
    entries = [
        dict(variant=args.variant, step=step, path=str(out / f"step-{step:05d}.pt"))
        for step in (500, 1000, 2000)
    ]
    manifest = out / "initializer-manifest.json"
    manifest.write_text(json.dumps(entries, indent=2) + "\n")
    for raw in (False, True):
        weights = "raw" if raw else "ema"
        subprocess.run(
            [
                sys.executable,
                "/pilot-code/scripts/diagnose_stochastic_velocity_wave2.py",
                "--manifest",
                str(manifest),
                "--output",
                str(out / f"initializer-{weights}"),
                "--data",
                paths["samples"],
            ]
            + (["--raw"] if raw else []),
            check=True,
        )
        subprocess.run(
            [
                sys.executable,
                "-m",
                "samudra.experiments.stochastic_transition_evaluate",
                "--data",
                paths["samples"],
                "--checkpoint",
                str(out / "step-02000.pt"),
                "--output",
                str(out / "evaluation" / f"step-02000-{weights}"),
            ]
            + (["--raw"] if raw else []),
            check=True,
        )
    (out / "EVALUATED.json").write_text(
        json.dumps(dict(complete=True, variant=args.variant)) + "\n"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    run(parser.parse_args())
