# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Per-process THP opt-out for large NumPy caches on fragmented cluster nodes.

Kernel PR_SET_THP_DISABLE is inherited by subprocesses across fork and exec.
This changes allocation policy only, never model math, dtype, or data.
"""

import ctypes
import json
import os
import runpy
import subprocess
import sys


def main():
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int] + [ctypes.c_ulong] * 4
    libc.prctl.restype = ctypes.c_int
    if libc.prctl(41, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "PR_SET_THP_DISABLE failed")
    state = libc.prctl(42, 0, 0, 0, 0)
    if state != 1:
        raise RuntimeError(f"THP disable verification returned {state}")
    print(json.dumps(dict(process_thp_disabled=True, pid=os.getpid())), flush=True)
    subprocess.run(
        [
            sys.executable,
            "-c",
            'import ctypes,os; state=ctypes.CDLL(None).prctl(42,0,0,0,0); assert state==1; print("THP child inheritance verified pid="+str(os.getpid()),flush=True)',
        ],
        check=True,
    )
    sys.argv = sys.argv[1:]
    sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
    runpy.run_path(sys.argv[0], run_name="__main__")


if __name__ == "__main__":
    main()
