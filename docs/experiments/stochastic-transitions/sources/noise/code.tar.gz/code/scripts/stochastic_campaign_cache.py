# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Copy and fully verify packed campaign caches on node-local disk."""

import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path


def stage_caches(root, paths):
    # Stage only caches: original source metadata/contract paths remain unchanged.
    # Both qualification and production execute this exact path; retain read-back proof.
    local = Path(os.environ["ONEPASS_NODE_TMP"])
    fstype = subprocess.check_output(
        ["stat", "-f", "-c", "%T", str(local)], text=True
    ).strip()
    if fstype in ("nfs", "nfs4", "lustre", "beegfs", "tmpfs"):
        raise RuntimeError(
            f"Node-local cache requires disk-backed local storage, got {fstype}"
        )
    needed = sum(
        p.stat().st_size
        for key in ("packed_om4", "forcing_cache")
        for p in Path(paths[key]).iterdir()
        if p.is_file()
    )
    if shutil.disk_usage(local).free < needed + 20 * 1024**3:
        raise RuntimeError("Insufficient node-local disk for verified training caches")
    started = time.time()
    cache_receipts = {}
    for key in ("packed_om4", "forcing_cache"):
        destination = local / key
        destination.mkdir()
        for source in Path(paths[key]).iterdir():
            if source.is_file():
                subprocess.run(
                    ["cp", "--", str(source), str(destination / source.name)],
                    check=True,
                    timeout=600,
                )
        proof_bytes = (destination / "COMPLETE.json").read_bytes()
        source_proof_bytes = (Path(paths[key]) / "COMPLETE.json").read_bytes()
        if proof_bytes != source_proof_bytes:
            raise ValueError(f"Node-local proof changed: {key}")
        proof_sha = hashlib.sha256(proof_bytes).hexdigest()
        if key == "forcing_cache" and proof_sha != paths["forcing_proof_sha256"]:
            raise ValueError("Forcing proof differs from pinned data configuration")
        proof = json.loads(proof_bytes)
        cache_receipts[key] = dict(
            source=paths[key], destination=str(destination), proof_sha256=proof_sha
        )
        if key == "forcing_cache":
            for name, expected in proof["files"].items():
                with (destination / name).open("rb") as stream:
                    actual = hashlib.file_digest(stream, "sha256").hexdigest()
                if actual != expected:
                    raise ValueError(f"Node-local forcing mismatch: {name}")
        else:
            import numpy as np

            frames = np.load(destination / "frames.npy", mmap_mode="r")
            if (
                list(frames.shape) != proof["shape"]
                or frames.dtype != np.float32
                or len(proof["frame_sha256"]) != len(frames)
            ):
                raise ValueError("Node-local packed shape changed")
            for index, expected in enumerate(proof["frame_sha256"]):
                if hashlib.sha256(frames[index].tobytes()).hexdigest() != expected:
                    raise ValueError(f"Node-local OM4 mismatch at frame {index}")
            del frames
    receipt = dict(
        local=str(local),
        bytes=needed,
        filesystem=fstype,
        seconds=time.time() - started,
        verified=True,
        caches=cache_receipts,
    )
    (root / f"node-local-{os.environ['SLURM_JOB_ID']}.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    print(json.dumps({"node_local_staging": receipt}), flush=True)
    os.environ["ONEPASS_LOCAL_DATA"] = str(local)
