# SPDX-FileCopyrightText: 2024 Allen Institute for Artificial Intelligence
# SPDX-FileCopyrightText: 2026 Samudra Authors
#
# SPDX-License-Identifier: Apache-2.0

"""
The code in this directory is directly inspired by the ACE project by AI2.

See the original repository at: https://github.com/ai2cm/ace/tree/39133c18524cda85965486ecdc8cb64aac06f4c3/fme/fme/ace/aggregator
"""

import torch

from samudra.aggregator.inference import InferenceEvaluatorAggregator
from samudra.aggregator.train import TrainAggregator
from samudra.aggregator.validate import ValidateAggregator
from samudra.aggregator.validate.map import MapAggregator
from samudra.aggregator.validate.reduced import MeanAggregator
from samudra.aggregator.validate.snapshot import SnapshotAggregator
from samudra.aggregator.validate.sub_aggregator import ValidateSubAggregator
from samudra.constants import DataLayout
from samudra.utils.data import BatchPreprocessor


class Aggregator:
    @staticmethod
    def get_train_aggregator(data_layout: DataLayout) -> TrainAggregator:
        return TrainAggregator(data_layout)

    @staticmethod
    def get_validation_aggregator(
        metadata: dict[str, dict[str, str]],
        input_steps: int,
        output_steps: int,
        area_weights: torch.Tensor,
        num_prognostic_channels: int,
        data_layout: DataLayout,
        preprocessor: BatchPreprocessor,
        *,
        include_image_aggregators: bool = True,
    ) -> ValidateAggregator:
        val_aggregators: dict[str, ValidateSubAggregator] = {
            "reduced": MeanAggregator(area_weights, output_steps - 1),
        }
        if include_image_aggregators:
            val_aggregators.update(
                {
                    "snapshot": SnapshotAggregator(metadata, input_steps),
                    "mean_map": MapAggregator(metadata, output_steps),
                }
            )

        return ValidateAggregator(
            val_aggregators,
            input_steps=input_steps,
            output_steps=output_steps,
            num_prognostic_channels=num_prognostic_channels,
            data_layout=data_layout,
            preprocessor=preprocessor,
        )

    @staticmethod
    def get_inline_inference_aggregator(
        n_timesteps: int,
        metadata: dict[str, dict[str, str]],
        input_steps: int,
        output_steps: int,
        area_weights: torch.Tensor,
        wet: torch.Tensor,
        num_prognostic_channels: int,
        data_layout: DataLayout,
        preprocessor: BatchPreprocessor,
        channel_mean_names: list[str] | None = None,
    ) -> InferenceEvaluatorAggregator:
        return InferenceEvaluatorAggregator(
            n_timesteps=n_timesteps,
            metadata=metadata,
            input_steps=input_steps,
            output_steps=output_steps,
            area_weights=area_weights,
            wet=wet,
            num_prognostic_channels=num_prognostic_channels,
            preprocessor=preprocessor,
            data_layout=data_layout,
            record_step_20=(n_timesteps > 20),
            log_global_mean_time_series=False,
            log_global_mean_norm_time_series=False,
            channel_mean_names=channel_mean_names,
        )

    @staticmethod
    def get_standalone_inference_aggregator(
        n_timesteps: int,
        metadata: dict[str, dict[str, str]],
        input_steps: int,
        output_steps: int,
        area_weights: torch.Tensor,
        wet: torch.Tensor,
        num_prognostic_channels: int,
        data_layout: DataLayout,
        preprocessor: BatchPreprocessor,
        channel_mean_names: list[str] | None = None,
    ) -> InferenceEvaluatorAggregator:
        return InferenceEvaluatorAggregator(
            n_timesteps=n_timesteps,
            metadata=metadata,
            input_steps=input_steps,
            output_steps=output_steps,
            area_weights=area_weights,
            wet=wet,
            num_prognostic_channels=num_prognostic_channels,
            preprocessor=preprocessor,
            data_layout=data_layout,
            record_step_20=(n_timesteps > 20),
            log_global_mean_time_series=True,
            log_global_mean_norm_time_series=True,
            channel_mean_names=channel_mean_names,
        )
