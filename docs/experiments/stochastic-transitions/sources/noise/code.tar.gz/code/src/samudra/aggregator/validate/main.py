# SPDX-FileCopyrightText: 2024 Allen Institute for Artificial Intelligence
# SPDX-FileCopyrightText: 2026 Samudra Authors
#
# SPDX-License-Identifier: Apache-2.0

import torch

from samudra.aggregator.train import TrainAggregator
from samudra.aggregator.validate.sub_aggregator import ValidateSubAggregator
from samudra.constants import DataLayout
from samudra.utils.data import BatchPreprocessor, get_aggregator_dicts
from samudra.utils.output import ValBatchOutput
from samudra.utils.wandb import Metrics, MetricsDict


class ValidateAggregator(TrainAggregator):
    """Aggregates Validation Statistics."""

    def __init__(
        self,
        aggregators: dict[str, ValidateSubAggregator],
        input_steps: int,
        output_steps: int,
        num_prognostic_channels: int,
        *,
        data_layout: DataLayout,
        preprocessor: BatchPreprocessor,
    ):
        super().__init__(data_layout)
        self._aggregators = aggregators
        self.input_steps = input_steps
        self.output_steps = output_steps
        self.num_prognostic_channels = num_prognostic_channels
        self.preprocessor = preprocessor

    # TODO(jder): we could remove this by moving from inheritance
    # to composition with the TrainAggregator functionality.
    def record_batch(self, batch):
        raise NotImplementedError(
            "Call record_validation_batch instead of record_batch"
        )

    @torch.no_grad()
    def record_validation_batch(self, batch: ValBatchOutput):
        super().record_batch(batch)  # Record losses

        # If there are no log aggregators, omit doing any extra work.
        if not self._aggregators:
            return

        # Translate the BatchGrid mask by removing repeated output-step channels.
        target_data = batch.target_data  # [B, C*output_steps, H, W]
        wet = batch.ctx.label_mask  # [C*output_steps, H, W]
        assert wet.shape == target_data.shape[1:], (
            "The wetmask must match the target data shape excluding batch."
        )
        assert wet.shape[0] % self.output_steps == 0, (
            "The wetmask channel count must be divisible by output_steps."
        )
        first_wetmask_chunk = wet.shape[0] // self.output_steps
        wet = wet[:first_wetmask_chunk]  # [C, H, W]

        if len(target_data) == 0:
            raise ValueError("No data in target_data")
        if len(batch.gen_data) == 0:
            raise ValueError("No data in gen_data")

        assert target_data.shape[1] == self.num_prognostic_channels
        target_data_dict, target_data_unnorm_dict = get_aggregator_dicts(
            target_data,
            preprocessor=self.preprocessor,
            data_layout=self.data_layout,
            wet=wet,
            long_rollout=False,
            input_type="prognostic",
            num_prognostic_channels=self.num_prognostic_channels,
            steps=self.output_steps,
        )

        gen_data_dict, gen_data_unnorm_dict = get_aggregator_dicts(
            batch.gen_data,
            preprocessor=self.preprocessor,
            data_layout=self.data_layout,
            wet=wet,
            long_rollout=False,
            input_type="prognostic",
            num_prognostic_channels=self.num_prognostic_channels,
            steps=self.output_steps,
        )
        input_data_dict, input_data_unnorm_dict = get_aggregator_dicts(
            batch.input_data,
            preprocessor=self.preprocessor,
            data_layout=self.data_layout,
            wet=wet,
            long_rollout=False,
            input_type="input",
            num_prognostic_channels=(
                len(self.data_layout.prognostic_var_names) * self.input_steps
            ),
            steps=self.input_steps,
        )

        for agg in self._aggregators.values():
            agg.record_batch(
                loss=batch.loss,
                target_data=target_data_unnorm_dict,
                gen_data=gen_data_unnorm_dict,
                input_data=input_data_unnorm_dict,
                target_data_norm=target_data_dict,
                gen_data_norm=gen_data_dict,
                input_data_norm=input_data_dict,
            )

    @torch.no_grad()
    def get_logs(self, label: str = "train") -> Metrics:
        logs: MetricsDict = dict(super().get_logs(label))
        for agg_label in self._aggregators:
            for k, v in self._aggregators[agg_label].get_logs(label=agg_label).items():
                logs[f"{label}/{k}"] = v

        return logs
