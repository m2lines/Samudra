# SPDX-FileCopyrightText: 2026 Samudra Authors
#
# SPDX-License-Identifier: Apache-2.0

import datetime
import logging
import time
from collections import OrderedDict

import torch

from samudra.aggregator import Aggregator
from samudra.backend import init_eval_backend
from samudra.config import EvalConfig, ObsMetricsConfig
from samudra.constants import BoundaryVarNames, Grid, PrognosticVarNames
from samudra.datasets import InferenceDataset
from samudra.metrics.run import open_predictions, run_observation_metrics
from samudra.stepper import run_rollout
from samudra.utils.data import BatchPreprocessor, get_inference_steps
from samudra.utils.device import using_gpu
from samudra.utils.distributed import is_main_process, set_seed
from samudra.utils.logging import get_model_summary, handle_logging, handle_warnings
from samudra.utils.wandb import WandBLogger

logger = logging.getLogger(__name__)


class Eval:
    """Evaluation pipeline for ocean emulator models.

    Runs long autoregressive rollouts and computes metrics against ground-truth
    ocean states.
    """

    def __init__(self, cfg: EvalConfig) -> None:
        cfg.prepare_output_dirs()

        self.device = init_eval_backend(cfg.backend)

        # Adjust workers and memory pinning based on device
        data_num_workers = cfg.data.loading.num_pytorch_workers()
        if not using_gpu():
            data_num_workers = 0  # Disable multi-processing on CPU
        elif cfg.disk_mode:
            data_num_workers = torch.cuda.device_count() * data_num_workers

        # Set seeds
        set_seed(cfg.experiment.rand_seed)

        logger.info("Loading data")
        self.data_bundle = cfg.data.build(
            cfg.experiment.resolved_data_root,
        )

        # Getting prognostic and boundary variables
        self.data_layout = self.data_bundle.data_layout
        self.prognostic_var_names: PrognosticVarNames = (
            self.data_layout.prognostic_var_names
        )
        self.boundary_var_names: BoundaryVarNames = self.data_layout.boundary_var_names
        self.levels = self.data_layout.num_prognostic_depth_levels

        str_prognostics = ", ".join([i for i in self.prognostic_var_names])
        str_boundaries = ", ".join([i for i in self.boundary_var_names])

        logger.info(f"Prognostic variables: {str_prognostics}")
        logger.info(f"Boundary variables: {str_boundaries}")
        logger.info(f"Levels: {self.levels}")

        self.N_bound = len(self.boundary_var_names)
        self.N_prog = len(self.prognostic_var_names)

        self.input_steps = cfg.data.input_steps
        self.output_steps = cfg.data.output_steps
        self.num_prog_in = self.input_steps * self.N_prog
        self.num_boundary_in = self.input_steps * self.N_bound
        self.num_in = self.num_prog_in + self.num_boundary_in
        self.num_out = self.output_steps * self.N_prog

        self.data_layout = self.data_layout.to(self.device)

        logger.info(f"Number of inputs (prognostic + boundary): {self.num_in}")
        logger.info(f"Number of outputs (prognostic): {self.num_out}")

        # Dataloaders
        if self.data_bundle.inference_source is None:
            raise ValueError(
                "Inference time is not configured for the first data source"
            )
        self.source = self.data_bundle.inference_source
        self.metadata = self.source.metadata
        self.wet = self.source.masks.prognostic_for_steps(self.output_steps)
        self.area_weights: Grid = self.source.spherical_area_weights
        self.area_weights = self.area_weights.to(self.device)

        self.preprocessor = BatchPreprocessor(
            self.source,
            prognostic_var_names=self.prognostic_var_names,
            boundary_var_names=self.boundary_var_names,
        )

        # Model
        self.model = cfg.model.build(
            prog_channels=self.num_prog_in,
            boundary_channels=self.num_boundary_in,
            out_channels=self.num_out,
            input_steps=self.input_steps,
            grid_sizes=[source.grid_size for source in self.data_bundle.train_sources],
        ).to(self.device)

        get_model_summary(self.model, None, cfg.debug)

        if cfg.ckpt_path is None:
            raise ValueError(
                "ckpt_path must be set; try --ckpt_path=path/to/checkpoint"
            )
        self.load_checkpoint(cfg.ckpt_path)

        self.network = self.model.__class__.__name__

        # Initialize WandB
        self.wandb_logger = WandBLogger.init_instance()
        self.wandb_logger.configure(
            cfg.experiment.wandb.mode == "online", is_main_process()
        )

        # Set up wandb run
        self.wandb_id, self.wandb_name = self.wandb_logger.setup_run(
            None, cfg, data_bundle=self.data_bundle, finetune=False
        )

        # Eval
        self.output_dir = cfg.experiment.output_dir
        self.debug = cfg.debug
        self.num_workers = data_num_workers
        self.num_model_steps_forward = cfg.num_model_steps_forward
        self.save_zarr = cfg.save_zarr
        self.model_path = cfg.ckpt_path
        self.normalize_before_mask = cfg.data.normalize_before_mask
        self.masked_fill_value = cfg.data.masked_fill_value
        self.observations = cfg.observations
        self.resolved_data_root = cfg.experiment.resolved_data_root
        self.experiment_name = cfg.experiment.name
        self.init_inference_store()

    def load_checkpoint(self, ckpt_path: str):
        checkpoint = torch.load(ckpt_path, map_location=torch.device(self.device))
        model_state_dict = checkpoint["model"]
        new_state_dict = OrderedDict()
        for k, v in model_state_dict.items():
            name = k.removeprefix("module.")
            new_state_dict[name] = v
        self.model.load_state_dict(new_state_dict)

    def init_inference_store(self):
        self.num_time_steps = get_inference_steps(
            self.source,
            input_steps=self.input_steps,
            output_steps=self.output_steps,
        )
        self.inference_dataset = InferenceDataset(
            source=self.source,
            prognostic_var_names=self.prognostic_var_names,
            boundary_var_names=self.boundary_var_names,
            input_steps=self.input_steps,
            output_steps=self.output_steps,
            normalize_before_mask=self.normalize_before_mask,
            masked_fill_value=self.masked_fill_value,
            long_rollout=True,
        )

    def run(self) -> None:
        start_time = time.perf_counter()
        inf_stats = self.standalone_inference()
        time_elapsed = time.perf_counter() - start_time

        log_stats = {
            **inf_stats,
            "eval_total_seconds": time_elapsed,
        }

        if is_main_process():
            self.wandb_logger.log(log_stats, step=None)

        # Logged after the rollout's own metrics, deliberately: the observation
        # phase reads the rollout back off disk and can fail on data problems
        # that have nothing to do with the model. When it does, it should raise
        # loudly without also costing us the rollout results already computed.
        try:
            if self.observations is not None and is_main_process():
                self.report_observation_metrics(self.observations)
        finally:
            # The observation phase reads ~65 GB back off remote storage, so it
            # can fail for reasons unrelated to the model. It should still
            # raise -- but not by skipping `finish()`, which would leave the run
            # marked crashed in W&B with the rollout's own metrics stranded
            # inside it.
            total_time = time.perf_counter() - start_time
            total_time_str = str(datetime.timedelta(seconds=int(total_time)))
            logger.info(f"Eval time (Including wandb logging) {total_time_str}")
            self.finish()

    def report_observation_metrics(self, obs_cfg: ObsMetricsConfig) -> None:
        """Score the finished rollout against observation products."""
        logger.info("Computing observation metrics")
        baselines = {}
        if "om4" in obs_cfg.baselines:
            # The ground-truth data the eval already staged. The metric table
            # is only interpretable next to it, so scoring it costs one extra
            # pass over data that is local anyway.
            baselines["om4"] = self.source.to_xarray_dataset()

        frame, scalars = run_observation_metrics(
            obs_cfg,
            predictions=open_predictions(self.output_dir),
            data_layout=self.data_layout,
            data_root=self.resolved_data_root,
            model_label=self.experiment_name,
            baselines=baselines,
            output_dir=self.output_dir,
        )
        self.wandb_logger.log(
            {**scalars, "obs/metrics_table": self.wandb_logger.Table(dataframe=frame)},
            step=None,
        )

    @torch.no_grad()
    def standalone_inference(self):
        self.model.eval()
        inf_aggregator = Aggregator.get_standalone_inference_aggregator(
            self.num_time_steps,
            self.metadata,
            self.input_steps,
            self.output_steps,
            self.area_weights,
            self.source.masks.prognostic.to(self.device),
            self.num_out,
            self.data_layout,
            self.preprocessor,
            self.prognostic_var_names,
        )

        run_rollout(
            model=self.model,
            dataset=self.inference_dataset,
            inf_aggregator=inf_aggregator,
            epoch=0,
            output_dir=self.output_dir,
            model_path=self.model_path,
            num_model_steps_forward=self.num_model_steps_forward,
            save_zarr=self.save_zarr,
            data_layout=self.data_layout,
            preprocessor=self.preprocessor,
        )
        logs = inf_aggregator.get_summary_logs()
        return {f"inference/{k}": v for k, v in logs.items()}

    def finish(self):
        self.wandb_logger.finish()


def main():
    cfg = EvalConfig.from_yaml_and_cli()
    cfg.prepare_output_dirs()  # we do this first so logging can use them

    handle_logging(cfg.debug, cfg.experiment.output_dir)
    handle_warnings()

    Evaluator = Eval(cfg)

    try:
        Evaluator.run()
    except Exception as e:
        # Log the exception with traceback
        logger.exception("Evaluation failed with an exception")
        raise e


if __name__ == "__main__":
    main()
