# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Global-batch synchronization for the custom physical diffusion objectives.

Objectives call forecast methods directly, so gradients are summed explicitly
once per update rather than wrapping only ``forward`` in DDP. Each local loss
is already divided by the global batch: NEVER divide gradients by world size.
"""

import hashlib
import os
from datetime import timedelta

import torch
import torch.distributed as dist


class DistributedRun:
    def __init__(self, device, *, initialize=True):
        self.world_size = int(os.environ.get("WORLD_SIZE", 1))
        self.rank = int(os.environ.get("RANK", 0))
        self.device = device
        self.objects = None
        if self.world_size > 1:
            if initialize:
                dist.init_process_group(
                    backend="nccl" if device.type == "cuda" else "gloo",
                    timeout=timedelta(hours=2),
                )
            self.objects = dist.new_group(backend="gloo", timeout=timedelta(hours=2))

    @property
    def primary(self):
        return self.rank == 0

    def owns(self, slot):
        return slot % self.world_size == self.rank

    def gather(self, value):
        if self.world_size == 1:
            return [value]
        values = [None] * self.world_size
        dist.all_gather_object(values, value, group=self.objects)
        return values

    def any(self, value):
        return any(self.gather(bool(value)))

    def barrier(self):
        if self.world_size > 1:
            dist.barrier()

    @torch.no_grad()
    def parameter_disagreement(self, model):
        maximum = torch.zeros((), device=self.device)
        if self.world_size > 1:
            for parameter in model.parameters():
                reference = parameter.detach().clone()
                dist.broadcast(reference, src=0)
                maximum.copy_(
                    torch.maximum(maximum, (parameter - reference).abs().max())
                )
            dist.all_reduce(maximum, op=dist.ReduceOp.MAX)
        return float(maximum)

    def sum_gradients(self, model):
        if self.world_size == 1:
            return
        parameters = list(model.parameters())
        used = torch.tensor(
            [p.grad is not None for p in parameters],
            device=self.device,
            dtype=torch.int32,
        )
        dist.all_reduce(used, op=dist.ReduceOp.MAX)
        # Bucket contiguous gradients to avoid one collective per small parameter.
        bucket: list[torch.nn.Parameter] = []
        size = 0

        def flush():
            if not bucket:
                return
            gradients = []
            for parameter in bucket:
                assert parameter.grad is not None
                gradients.append(parameter.grad)
            flat = torch.cat([gradient.reshape(-1) for gradient in gradients])
            dist.all_reduce(flat, op=dist.ReduceOp.SUM)
            offset = 0
            for parameter, gradient in zip(bucket, gradients, strict=True):
                n = parameter.numel()
                gradient.copy_(flat[offset : offset + n].view_as(parameter))
                offset += n
            bucket.clear()

        for parameter, active in zip(parameters, used.tolist(), strict=True):
            if not active:
                continue
            if parameter.grad is None:
                parameter.grad = torch.zeros_like(parameter)
            bucket.append(parameter)
            size += parameter.numel() * parameter.element_size()
            if size >= 32 * 1024**2:
                flush()
                size = 0
        flush()


def merge_replay(pool, additions):
    """Apply fresh-before-replay, slot-ordered entries identically on every rank."""
    for _, entries in sorted(additions, key=lambda item: item[0]):
        for depth, entry in entries:
            pool.entries[depth].append(entry)
            pool.entries[depth] = pool.entries[depth][-pool.per_lead :]


def replay_fingerprint(pools):
    """Canonical metadata, RNG and tensor digest for qualification checkpoints."""
    digest = hashlib.sha256()

    def visit(value):
        if isinstance(value, torch.Tensor):
            digest.update(str((value.dtype, tuple(value.shape))).encode())
            digest.update(value.detach().cpu().contiguous().numpy().tobytes())
        elif isinstance(value, dict):
            for key in sorted(value, key=str):
                visit(key)
                visit(value[key])
        elif isinstance(value, (list, tuple)):
            digest.update(str(len(value)).encode())
            for entry in value:
                visit(entry)
        else:
            digest.update(repr(value).encode())
        digest.update(b"\0")

    visit(pools)
    return digest.hexdigest()
