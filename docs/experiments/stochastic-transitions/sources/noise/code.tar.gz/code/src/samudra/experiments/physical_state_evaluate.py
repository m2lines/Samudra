# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Frozen observational validation and coherent physical diffusion rollouts.

Keep OM4 normalization, shared eight-channel ERA5 and checkpoint EMA. Forecasts
condition only on the initial surface history and prescribed atmospheric fields.
Annual test origins are reporting diagnostics, never checkpoint selection data.
"""

import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
from torch import nn

from samudra.experiments.diffusion_evaluation import evaluate_point_metrics
from samudra.experiments.diffusion_global_annual import AnnualMembers
from samudra.experiments.diffusion_global_evaluate import RecordingForecast
from samudra.experiments.observation_annual import evaluate_origins
from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.physical_state_train import counts, model_from_checkpoint
from samudra.experiments.stochastic_state_evaluate import export_trajectory_diagnostics

UNCERTAINTY = (
    "Coherent physical-state trajectories: independently sampled initializer and "
    "processor; each member feeds its own two previous physical states forward. "
    "No ensemble-mean feedback and no future surface observations."
)


class FullStateCapture(nn.Module):
    """Supplement legacy four-channel exports with all-depth mean/draw1 states."""

    stochastic = True

    def __init__(self, model, data, names, output, leads=(30, 365)):
        super().__init__()
        self.model, self.data, self.names, self.output = model, data, names, output
        self.completed = 0
        self.leads = leads

    def forecast(self, *args, **kwargs):
        with torch.autocast(
            "cuda",
            dtype=torch.bfloat16,
            enabled=bool(args) and args[0].device.type == "cuda",
        ):
            trajectories, initial = self.model.forecast(*args, **kwargs)
        if not torch.isfinite(trajectories).all() or not torch.isfinite(initial).all():
            raise ValueError("Nonfinite sampled physical trajectory")
        if trajectories.shape[1] != 1:
            raise ValueError("Evaluation capture requires one origin per call")
        leads = [day for day in self.leads if day // 5 <= trajectories.shape[2]]
        positions = [day // 5 - 1 for day in leads]
        # Select first; do not materialize a second physical-unit annual ensemble.
        chosen = trajectories[:, 0, positions].float()
        mean = self.data.grid["mean"][:, None, None]
        std = self.data.grid["std"][:, None, None]

        def physical(value):
            return value.float().cpu().numpy() * std + mean

        name = self.names[self.completed]
        np.savez_compressed(
            self.output / f"full-state-{name}.npz",
            initial_mean=physical(initial[:, 0].mean(0, dtype=torch.float32)),
            initial_draw1=physical(initial[0, 0]),
            initial_spread=initial[:, 0].float().std(0, correction=0).cpu().numpy()
            * std,
            mean=physical(chosen.mean(0)),
            draw1=physical(chosen[0]),
            spread=chosen.std(0, correction=0).cpu().numpy() * std,
            leads_days=leads,
            initial_bin_days=[-5, 0],
            channel_names=self.data.grid["names"],
            normalization_mean=self.data.grid["mean"],
            normalization_std=self.data.grid["std"],
            mask=self.data.grid["mask"],
            lat=self.data.grid["lat"],
            lon=self.data.grid["lon"],
            units="Physical units; land values must be masked with per-channel mask",
            initial_scope="Two five-day bins ending at origin; no instantaneous interior observation reference",
        )
        self.completed += 1
        return trajectories, initial


class PhysicalRecordingForecast(RecordingForecast):
    """Keep calibration/loss diagnostics FP32 under legacy evaluator autocast."""

    def forecast(self, *args, **kwargs):
        with torch.autocast("cuda", enabled=False):
            return super().forecast(*args, **kwargs)


def verify_inputs(saved, data, training_reference):
    """Verify training identities separately from the frozen metric reference."""
    contract = saved["contract"]
    if saved["counts"] != counts(saved["step"], contract):
        raise ValueError("Checkpoint task counts disagree with its training schedule")
    for key, path in (
        ("observation_manifest", data.root / "SHA256SUMS"),
        ("stats", data.root / "statistics.npz"),
        ("grid", data.root / "grid.npz"),
        ("reference", training_reference),
    ):
        if digest(path) != contract[key]:
            raise ValueError(f"Changed training input: {key}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "checkpoint", "training-reference", "reference", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--annual-data", type=Path)
    parser.add_argument(
        "--annual-split", choices=("validation", "test"), default="validation"
    )
    parser.add_argument("--origins", nargs="+")
    parser.add_argument("--validation-only", action="store_true")
    parser.add_argument("--skip-validation", action="store_true")
    parser.add_argument("--expected-step", type=int, default=1200)
    parser.add_argument("--members", type=int, default=8)
    parser.add_argument("--steps", type=int, default=8)
    parser.add_argument("--seed", type=int, default=4041729)
    parser.add_argument("--raw-weights", action="store_true")
    args = parser.parse_args()
    if args.members < 2 or args.steps < 2:
        raise ValueError("Need multiple members and at least two Heun noise levels")
    if args.validation_only and args.skip_validation:
        raise ValueError("Cannot skip both evaluation cohorts")
    if not args.validation_only and args.annual_data is None:
        raise ValueError("Annual evaluation requires --annual-data")
    args.output.mkdir(parents=True, exist_ok=True)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if saved["step"] != args.expected_step:
        raise ValueError("Checkpoint does not match requested update count")
    # Deliberately do NOT call use_observation_normalization: both training tasks
    # use OM4 physical statistics, including observation initialization.
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    verify_inputs(saved, data, args.training_reference)
    paths = data.paths("validation")
    if len(paths) != 9:
        raise ValueError("Frozen nine-origin validation cohort changed")
    origins = []
    if not args.validation_only:
        available = sorted(
            (args.annual_data / args.annual_split).glob("*/COMPLETE.json")
        )
        requested = args.origins or [p.parent.name for p in available]
        if len(set(requested)) != len(requested):
            raise ValueError("Duplicate requested annual origin")
        origins = [p for p in available if p.parent.name in requested]
        if len(origins) != len(requested) or not origins:
            raise ValueError("Requested annual origin manifests are missing")
    protocol = dict(
        checkpoint_sha256=digest(args.checkpoint),
        training_contract=saved["contract"],
        counts=saved["counts"],
        step=saved["step"],
        weights="raw" if args.raw_weights else "ema",
        evaluator=os.environ.get("SAMUDRA_CODE_COMMIT", "unversioned"),
        members=args.members,
        sampling_steps=args.steps,
        precision="BF16 denoiser autocast; FP32 physical outputs and metric arithmetic",
        seed=args.seed,
        metric_reference_sha256=digest(args.reference),
        training_reference_sha256=digest(args.training_reference),
        annual_split=args.annual_split,
        annual_manifests={p.parent.name: digest(p) for p in origins},
        validation_origins=[] if args.skip_validation else [p.stem for p in paths],
        uncertainty=UNCERTAINTY,
        normalization="Fixed OM4 physical statistics for both observation and OM4 tasks",
        forcing="Prescribed eight-channel ERA5 directly, without trained adapter; not an operational forcing forecast",
        domain="All finite wet latitudes; cosine-area weighting",
        selection="Fixed-budget checkpoint; annual test outputs for reporting only",
    )
    manifest = args.output / "input.json"
    if manifest.exists() and json.loads(manifest.read_text()) != protocol:
        raise ValueError("Existing evaluation has a different protocol")
    atomic_json(protocol, manifest)
    model = model_from_checkpoint(saved, data, use_ema=not args.raw_weights).eval()
    model.sampling_steps = args.steps
    if not args.skip_validation:
        directory = args.output / "validation"
        directory.mkdir(exist_ok=True)
        capture = FullStateCapture(model, data, [p.stem for p in paths], directory)
        recording = PhysicalRecordingForecast(capture, data, paths, directory).eval()
        with torch.no_grad():
            metrics, score = evaluate_point_metrics(
                recording,
                data,
                paths,
                json.loads(args.reference.read_text()),
                members=args.members,
                seed=args.seed,
            )
        atomic_json(
            dict(inputs=protocol, metrics=metrics, score=score),
            directory / "COMPLETE.json",
        )
    if origins:
        annual = args.output / "annual"
        annual.mkdir(exist_ok=True)
        capture = FullStateCapture(
            model, data, [p.parent.name for p in origins], annual
        )
        recording = AnnualMembers(
            capture, data, origins, annual, members=args.members, seed=args.seed
        ).eval()
        evaluate_origins(recording, data, origins, annual, protocol)
        for origin in origins:
            export_trajectory_diagnostics(annual, origin.parent.name, origin.parent)
            diagnostic = annual / f"trajectory-{origin.parent.name}.json"
            result = json.loads(diagnostic.read_text())
            result["uncertainty"] = UNCERTAINTY
            atomic_json(result, diagnostic)
    atomic_json(
        dict(
            inputs=protocol,
            files={
                str(p.relative_to(args.output)): digest(p)
                for p in sorted(args.output.rglob("*"))
                if p.is_file() and p != args.output / "COMPLETE.json"
            },
        ),
        args.output / "COMPLETE.json",
    )


if __name__ == "__main__":
    main()
