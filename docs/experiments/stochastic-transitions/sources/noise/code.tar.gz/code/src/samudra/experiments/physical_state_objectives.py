# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Full-state denoising on OM4; differentiable physical trajectories on OBS."""

import torch

from samudra.experiments.diffusion_spatial import completion_crps, forecast_crps
from samudra.experiments.joint_diffusion import denoising_loss
from samudra.experiments.missingness import corrupt_sample, structured_visibility


def observation_objective(model, data, original, generator, members=2, capture=None):
    return observation_batch_objective(
        model, data, [original], generator, members=members, capture=capture
    )


def observation_batch_objective(
    model, data, originals, generator, members=2, capture=None, seeds=None
):
    """Batch network work, then average separately normalized example losses.

    Monthly weights and missing target support remain example-specific. Group
    callers by temporal length; no padding changes the scientific objective.
    """
    if members < 2 or not originals:
        raise ValueError("Require examples and at least two sampled trajectories")
    if seeds is None:
        seeds = [generator.initial_seed() + i for i in range(len(originals))]
    samples = [
        corrupt_sample(s, seed) for s, seed in zip(originals, seeds, strict=True)
    ]
    if len({s["atmosphere"].shape[1] for s in samples}) != 1:
        raise ValueError("Microbatch temporal lengths differ")
    inputs = [
        torch.cat([s[key] for s in samples], 0)
        for key in ("surface", "atmosphere", "contexts", "validity")
    ]
    prediction, initial = model.forecast(
        inputs[0],
        inputs[1],
        inputs[2],
        data.mask,
        inputs[3],
        generator=generator,
        members=members,
    )
    if capture is not None:
        capture(prediction.detach(), initial.detach())
    losses = []
    for i, sample in enumerate(samples):
        losses.append(
            forecast_crps(data, prediction[:, i : i + 1], sample)
            + 0.1
            * completion_crps(
                data,
                initial[:, i : i + 1, :, model.surface],
                sample["completion_target"],
                sample["completion_valid"],
            )
        )
    return torch.stack(losses).mean()


def native_surface_visibility(model, fields, mask, seeds):
    """Deterministic per-example hiding, independent of global RNG and batching."""
    valid = (
        mask[model.surface].bool().expand(fields.shape[0], model.history, -1, -1, -1)
    )
    if len(seeds) != fields.shape[0]:
        raise ValueError("One surface mask seed is required per native example")
    visible = []
    for i, seed in enumerate(seeds):
        item = structured_visibility(valid[i : i + 1], seed)
        # Random interior bands rarely touch the extreme rows. Explicitly train
        # polar completion too, matching the observed Arctic coverage gap.
        generator = torch.Generator(device="cpu").manual_seed(int(seed) + 730001)
        if bool(torch.rand((), generator=generator) < 0.5):
            item[..., -2:, :] = False
        if bool(torch.rand((), generator=generator) < 0.5):
            item[..., :2, :] = False
        visible.append(item)
    return torch.cat(visible, 0)


def native_objective(model, data, batch, generator, *, mask_seeds=None):
    initial, transition = native_loss_components(
        model, data, batch, generator, mask_seeds=mask_seeds
    )
    return initial + transition


def native_loss_components(model, data, batch, generator, *, mask_seeds=None):
    """Equal initializer / mean teacher-forced transition denoising weights.

    All fields are already in the shared physical normalization. ModelMonths
    supplies exact contiguous five-day intervals; no monthly target is treated
    as an instantaneous state. Both tasks use the same eight ERA5 channels.
    """
    fields, mask = batch["fields"], batch["mask"]
    n = model.history
    if fields.shape[1] <= n or n < 2:
        raise ValueError("Need historical states and at least one future target")
    forcing = batch["atmosphere"]
    contexts = batch["contexts"]
    weights = mask * data.area
    if mask_seeds is None:
        initial = model.pretraining_loss(
            fields[:, :n, model.surface],
            forcing[:, :n],
            contexts[:, n - 1],
            fields[:, n - 2 : n],
            mask,
            weights,
            generator,
        )
    else:
        visible = native_surface_visibility(model, fields, mask, mask_seeds)
        conditioning, _, anchor = model.encode_native(
            fields[:, :n, model.surface],
            forcing[:, :n],
            contexts[:, n - 1],
            mask,
            validity=visible,
        )
        # Only conditioning and anchors are hidden. Full gold remains the target,
        # so hidden wet surface pixels now receive the denoising objective.
        initial = denoising_loss(
            model.initializer,
            conditioning,
            fields[:, n - 2 : n].flatten(1, 2),
            mask.repeat(2, 1, 1),
            weights.repeat(2, 1, 1),
            generator,
            known_mask=anchor,
            checkpoint_denoiser=model.training and model.checkpoint_denoiser,
        )
    transitions = [
        model.transition_loss(
            fields[:, step - 2 : step],
            forcing[:, step],
            contexts[:, step],
            fields[:, step],
            mask,
            weights,
            generator,
        )
        for step in range(n, fields.shape[1])
    ]
    return initial, torch.stack(transitions).mean()
