# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Held-out OM4 surface initialization and 30-day free physical-state rollout."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from samudra.experiments.monthly_model_data import ModelMonths, calendar_context
from samudra.experiments.observation_data import context_planes
from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.physical_state_evaluate import FullStateCapture, verify_inputs
from samudra.experiments.physical_state_train import model_from_checkpoint


def match_intervals(bounds, starts):
    """Require exact native five-day bins, never nearest-time or interpolated gold."""
    positions = {pd.Timestamp(str(a)): i for i, (a, _) in enumerate(bounds)}
    indices = []
    for start in starts:
        stamp = pd.Timestamp(str(start))
        if stamp not in positions:
            raise ValueError(f"OM4 has no exact matching interval at {stamp}")
        index = positions[stamp]
        if pd.Timestamp(str(bounds[index, 1])) != stamp + pd.Timedelta(days=5):
            raise ValueError("OM4 and ERA5 interval ends differ")
        indices.append(index)
    if not indices or np.any(np.diff(indices) != 1):
        raise ValueError("Requested OM4 intervals are not contiguous")
    if min(pd.Timestamp(str(s)) for s in starts) < pd.Timestamp("2014-01-01"):
        raise ValueError("Held-out example overlaps the pre-2014 period")
    return indices


def read_forcing(directory):
    """Load only ERA5 and timestamps, never surface/interior observation arrays."""
    manifest_path = directory / "COMPLETE.json"
    description = json.loads(manifest_path.read_text())
    if description["history_bins"] != 19 or description["bin_days"] != 5:
        raise ValueError("Unexpected annual forcing cadence")
    values, starts, midpoints, records = [], [], [], []
    for i, record in enumerate(description["records"][:25]):
        path = directory / record["file"]
        if (
            Path(record["file"]).name != record["file"]
            or digest(path) != record["sha256"]
        ):
            raise ValueError("Forcing payload identity changed")
        expected = pd.Timestamp(description["origin"]) + pd.Timedelta(days=5 * (i - 19))
        with np.load(path) as item:
            start, end, midpoint = (
                pd.Timestamp(str(item[k])) for k in ("start", "end", "midpoint")
            )
            if (start, end, midpoint) != (
                expected,
                expected + pd.Timedelta(days=5),
                expected + pd.Timedelta(days=2.5),
            ):
                raise ValueError(
                    "Forcing intervals differ from the declared five-day bins"
                )
            values.append(item["atmosphere"])
        starts.append(start)
        midpoints.append(midpoint)
        records.append(record)
    if len(values) != 25:
        raise ValueError("Need 19 history and six future forcing bins")
    return description, np.stack(values), starts, midpoints, records


def evaluate_obs_firststep(args, model, data, description, forcing, midpoints, records):
    """Same seed/initialization as the prior annual OBS pass, stopping at day five."""
    directory = args.output.parent / "obs-firststep" / "annual"
    directory.mkdir(parents=True, exist_ok=True)
    surface = []
    for record in records[:20]:
        with np.load(args.annual_origin / record["file"]) as item:
            surface.append(item["surface"])
    surface = np.stack(surface)
    history = surface[:19]
    validity = np.isfinite(history) & data.grid["mask"][[38, 76]]
    normalized = np.where(
        validity,
        (history - data.grid["mean"][[38, 76], None, None])
        / data.grid["std"][[38, 76], None, None],
        0,
    ).astype(np.float32)
    capture = FullStateCapture(
        model, data, [description["origin"]], directory, leads=(5,)
    ).eval()
    with torch.no_grad():
        capture.forecast(
            data.tensor(normalized)[None],
            data.tensor(forcing[:20])[None],
            data.tensor(
                context_planes(data.grid["lat"], data.grid["lon"], midpoints[:20])
            )[None],
            data.mask,
            data.tensor(validity)[None],
            members=args.members,
            generator=torch.Generator(device="cuda").manual_seed(args.seed),
        )
    np.savez_compressed(
        directory / f"{description['origin']}.npz", reference=surface[19:20]
    )
    np.savez_compressed(
        directory / f"maps-{description['origin']}.npz",
        initial_surface_reference=surface[18],
    )
    protocol = dict(
        source="OBS",
        origin=description["origin"],
        sampling_steps=args.steps,
        members=args.members,
        seed=args.seed,
        checkpoint_sha256=digest(args.checkpoint),
        weights="ema",
        step=1200,
        case_label="Observation surface initialization and first free five-day step",
        initial_surface="Valid observed SSH/SST copied as anchors; missing cells generated",
        forcing_records=records[:20],
    )
    atomic_json(
        dict(
            inputs=protocol,
            files={
                str(p.relative_to(directory.parent)): digest(p)
                for p in directory.iterdir()
                if p.is_file()
            },
        ),
        directory.parent / "COMPLETE.json",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "data",
        "om4",
        "annual-origin",
        "checkpoint",
        "training-reference",
        "output",
    ):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--members", type=int, default=8)
    parser.add_argument("--steps", type=int, default=8)
    parser.add_argument("--seed", type=int, default=4041729)
    args = parser.parse_args()
    if args.members < 2 or args.steps < 2:
        raise ValueError("Require multiple members and two or more noise levels")
    args.output.mkdir(parents=True, exist_ok=True)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if saved["step"] != 1200 or saved["counts"] != {"om4": 600, "observation": 600}:
        raise ValueError("Expected the final 600/600 pilot checkpoint")
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    verify_inputs(saved, data, args.training_reference)
    reader = ModelMonths(args.om4 / "OM4.zarr", "om4", data.grid, args.om4)
    description, atmosphere, starts, midpoints, records = read_forcing(
        args.annual_origin
    )
    indices = match_intervals(reader.bounds, starts)
    if any(
        indices[-1] >= start and indices[0] < stop
        for start, stop, _, _ in reader.windows
    ):
        raise ValueError("Selected held-out target overlaps a training window")
    interval = slice(indices[0], indices[-1] + 1)
    raw = np.stack([reader.store[name][interval] for name in reader.names], axis=1)
    if not np.isfinite(raw[:, reader.mask]).all():
        raise ValueError("OM4 gold is nonfinite on wet support")
    fields = np.where(
        reader.mask,
        (raw - data.grid["mean"][:, None, None]) / data.grid["std"][:, None, None],
        0,
    ).astype(np.float32)
    forcing = (
        atmosphere - data.stats["atmosphere_mean"][None, :, None, None]
    ) / data.stats["atmosphere_std"][None, :, None, None]
    if not np.isfinite(forcing).all() or forcing.shape[1] != 8:
        raise ValueError("Invalid shared ERA5 conditioning")
    protocol = dict(
        checkpoint_sha256=digest(args.checkpoint),
        step=1200,
        counts=saved["counts"],
        weights="ema",
        members=args.members,
        sampling_steps=args.steps,
        seed=args.seed,
        initial_surface="SSH and SST are exact copied input anchors, not reconstruction predictions",
        source="OM4",
        origin=description["origin"],
        case_label="Held-out OM4 surface-only initialization and free 30-day rollout",
        source_metadata_sha256=digest(args.om4 / "OM4.zarr/.zmetadata"),
        source_indices=indices,
        source_fields_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),
        forcing_manifest_sha256=digest(args.annual_origin / "COMPLETE.json"),
        forcing_records=records,
        bounds=[[str(reader.bounds[i, 0]), str(reader.bounds[i, 1])] for i in indices],
        training_last_target_end=max(
            str(reader.bounds[stop - 1, 1]) for _, stop, _, _ in reader.windows
        ),
        conditioning="Only OM4 SSH/SST history plus exact interval-matched eight-channel ERA5; no interior truth conditioning or future surface corrections",
        normalization="Same fixed OM4 physical statistics as both training tasks",
        precision="BF16 denoiser inference; FP32 physical outputs",
        evaluator=os.environ.get("SAMUDRA_CODE_COMMIT", "unversioned"),
    )
    atomic_json(protocol, args.output / "input.json")
    model = model_from_checkpoint(saved, data).eval()
    model.sampling_steps = args.steps
    capture = FullStateCapture(
        model, data, [description["origin"]], args.output, leads=(5, 30)
    ).eval()
    mask = data.tensor(reader.mask)
    with torch.no_grad():
        capture.forecast(
            data.tensor(fields[:19, [38, 76]])[None],
            data.tensor(forcing)[None],
            data.tensor(
                calendar_context(reader.lat, reader.lon, reader.midpoints[interval])
            )[None],
            mask,
            mask[[38, 76]][None, None].expand(1, 19, -1, -1, -1),
            members=args.members,
            generator=torch.Generator(device="cuda").manual_seed(args.seed),
        )
    path = args.output / f"full-state-{description['origin']}.npz"
    with np.load(path) as arrays:
        result = dict(arrays)
    result.update(
        gold_initial=raw[17:19],
        gold=raw[[19, 24]],
        mask=reader.mask,
        source="OM4",
        case_label=protocol["case_label"],
        bounds=np.array(protocol["bounds"]),
    )
    np.savez_compressed(path, **result)
    atomic_json(
        dict(
            inputs=protocol,
            files={
                p.name: digest(p)
                for p in args.output.iterdir()
                if p.is_file() and p.name != "COMPLETE.json"
            },
        ),
        args.output / "COMPLETE.json",
    )
    evaluate_obs_firststep(args, model, data, description, forcing, midpoints, records)
    print(
        json.dumps(dict(event="om4_evaluation_complete", origin=description["origin"])),
        flush=True,
    )


if __name__ == "__main__":
    main()
