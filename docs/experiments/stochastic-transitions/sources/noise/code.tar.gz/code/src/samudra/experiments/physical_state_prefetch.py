# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""One-update CPU lookahead for rank-local native denoising pretraining.

No CUDA work, RNG draws, precision changes or persistent dataset cache happen in
this worker. The trainer owns sampling, order, GPU transfers and replay policy.
"""

import copy
from concurrent.futures import ThreadPoolExecutor

import torch


def load_native_cpu(reader, forcing_cache, data, index):
    """Keep the established NumPy validation/normalization; skip unused OM4 fluxes."""
    cpu_data = copy.copy(data)
    cpu_data.device = torch.device("cpu")
    batch = reader.sample(index, "cpu", include_native_forcing=False)
    batch["atmosphere"] = forcing_cache.load(reader, index, cpu_data)
    if any(
        isinstance(value, torch.Tensor) and value.device.type != "cpu"
        for value in batch.values()
    ):
        raise ValueError("Native prefetch worker produced a non-CPU tensor")
    return batch


def native_to_device(batch, device):
    return {
        key: value.to(device) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


class NativePrefetch:
    """At most one next update, loaded serially by one CPU worker per rank."""

    def __init__(self, loader):
        self.loader = loader
        self.executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="native-prefetch"
        )
        self.future = None
        self.key = None

    def submit(self, step, indices):
        key = (int(step), tuple(int(index) for index in indices))
        if self.future is not None:
            raise RuntimeError("Native lookahead already holds one update")
        self.key = key
        self.future = self.executor.submit(
            lambda: [self.loader(index) for index in key[1]]
        )

    def take(self, step, indices):
        key = (int(step), tuple(int(index) for index in indices))
        if self.future is None:
            self.submit(step, indices)
        if key != self.key:
            raise ValueError(
                "Prefetched update differs from deterministic sample schedule"
            )
        result = self.future.result()  # Reader/checksum failures remain fatal.
        self.future, self.key = None, None
        return result

    def close(self):
        self.executor.shutdown(wait=True, cancel_futures=True)
        self.future, self.key = None, None
