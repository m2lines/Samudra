# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Fixed-noise held-out OM4 denoising diagnostics, separate from rollout scores."""

import hashlib
import json
from contextlib import nullcontext
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist


def array_digest(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def contract_digest(contract):
    return hashlib.sha256(
        json.dumps(contract, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


class FixedOM4Validation:
    """One held-out history and six gold-conditioned five-day transitions.

    This deliberately small fixed sample is a cheap learning-curve diagnostic,
    not an estimate of annual skill or a representative validation-set average.
    A dedicated generator resets every call, including the surface-mask seed.
    """

    def __init__(
        self,
        fields,
        atmosphere,
        contexts,
        mask,
        contract,
        seed=981724,
        *,
        mask_surface=True,
    ):
        if fields.ndim != 4 or fields.shape[0] != 25 or fields.shape[1] != 77:
            raise ValueError(
                "Fixed validation needs 19 history and six future full states"
            )
        if atmosphere.shape[:2] != (25, 8):
            raise ValueError("Fixed validation requires eight shared ERA5 fields")
        if not np.isfinite(fields[:, mask.astype(bool)]).all():
            raise ValueError("Nonfinite held-out wet fields")
        if not np.isfinite(atmosphere).all() or not np.isfinite(contexts).all():
            raise ValueError("Nonfinite held-out conditioning")
        self.arrays = dict(
            fields=fields, atmosphere=atmosphere, contexts=contexts, mask=mask
        )
        self.seed = seed
        self.mask_surface = mask_surface
        self.contract = dict(
            contract,
            schema="physical-om4-fixed-denoising-v1",
            seed=seed,
            mask_seed=seed if mask_surface else None,
            surface_masking="structured_visibility-plus-polar-v1"
            if mask_surface
            else "none",
            cohort_use="Repeated monitoring on the previously inspected 2015 January example; not an independent final test",
            examples=1,
            history_bins=19,
            teacher_forced_transitions=6,
            weighting="initializer plus mean of six teacher-forced transition losses",
            noise="fixed generator reset each evaluation; same surface masking as training",
            interpretation="Small fixed held-out denoising diagnostic; not annual rollout skill",
            arrays_sha256={k: array_digest(v) for k, v in self.arrays.items()},
        )
        self.fingerprint = contract_digest(self.contract)

    @classmethod
    def prepare(cls, om4, annual_origin, data, seed=981724, *, mask_surface=True):
        # Lazy import avoids the evaluator -> trainer -> validation import cycle.
        from samudra.experiments.monthly_model_data import ModelMonths, calendar_context
        from samudra.experiments.observation_pilot import digest
        from samudra.experiments.physical_state_om4_evaluate import (
            match_intervals,
            read_forcing,
        )

        om4, annual_origin = Path(om4), Path(annual_origin)
        reader = ModelMonths(om4 / "OM4.zarr", "om4", data.grid, om4)
        description, atmosphere, starts, _, records = read_forcing(annual_origin)
        indices = match_intervals(reader.bounds, starts)
        if any(
            indices[-1] >= start and indices[0] < stop
            for start, stop, _, _ in reader.windows
        ):
            raise ValueError("Held-out validation overlaps an OM4 training window")
        interval = slice(indices[0], indices[-1] + 1)
        raw = np.stack([reader.store[name][interval] for name in reader.names], axis=1)
        fields = np.where(
            reader.mask,
            (raw - data.grid["mean"][:, None, None]) / data.grid["std"][:, None, None],
            0,
        ).astype(np.float32)
        forcing = (
            (atmosphere - data.stats["atmosphere_mean"][None, :, None, None])
            / data.stats["atmosphere_std"][None, :, None, None]
        ).astype(np.float32)
        contexts = calendar_context(
            reader.lat, reader.lon, reader.midpoints[interval]
        ).astype(np.float32)
        contract = dict(
            source="OM4",
            origin=description["origin"],
            source_indices=indices,
            source_metadata_sha256=digest(om4 / "OM4.zarr/.zmetadata"),
            forcing_manifest_sha256=digest(annual_origin / "COMPLETE.json"),
            forcing_records=records,
            bounds=[
                [str(reader.bounds[i, 0]), str(reader.bounds[i, 1])] for i in indices
            ],
            training_last_target_end=max(
                str(reader.bounds[stop - 1, 1]) for _, stop, _, _ in reader.windows
            ),
            normalization_mean_sha256=array_digest(data.grid["mean"]),
            normalization_std_sha256=array_digest(data.grid["std"]),
            forcing_mean_sha256=array_digest(data.stats["atmosphere_mean"]),
            forcing_std_sha256=array_digest(data.stats["atmosphere_std"]),
        )
        return cls(
            fields,
            forcing,
            contexts,
            reader.mask,
            contract,
            seed,
            mask_surface=mask_surface,
        )

    def evaluate(self, model, data):
        """Return separately logged EMA losses without perturbing training RNG/mode."""
        from samudra.experiments.physical_state_objectives import native_loss_components

        if model.history != 19:
            raise ValueError("Held-out history differs from training model")
        device = next(model.parameters()).device
        batch = {
            key: torch.as_tensor(value, device=device)[None]
            if key != "mask"
            else torch.as_tensor(value, device=device)
            for key, value in self.arrays.items()
        }
        modes = {module: module.training for module in model.modules()}
        devices = (
            [device.index if device.index is not None else torch.cuda.current_device()]
            if device.type == "cuda"
            else []
        )
        autocast = (
            torch.autocast("cuda", dtype=torch.bfloat16)
            if device.type == "cuda"
            else nullcontext()
        )
        try:
            model.eval()
            with torch.random.fork_rng(devices=devices), torch.no_grad(), autocast:
                generator = torch.Generator(device=device).manual_seed(self.seed)
                initial, transition = native_loss_components(
                    model,
                    data,
                    batch,
                    generator,
                    mask_seeds=[self.seed] if self.mask_surface else None,
                )
                values = {
                    "initializer": float(initial),
                    "processor": float(transition),
                    "total": float(initial + transition),
                }
                if not all(np.isfinite(v) for v in values.values()):
                    raise ValueError("Nonfinite held-out denoising loss")
                return values
        finally:
            for module, mode in modes.items():
                module.training = mode


def evaluate_rank_zero(validator, ema, data, *, group=None):
    """All ranks call; rank zero evaluates and broadcasts success or failure.

    Collective errors are re-raised on every rank rather than leaving nonzero
    ranks waiting at a barrier. The caller should log only on rank zero.
    """
    distributed = dist.is_available() and dist.is_initialized()
    rank = dist.get_rank() if distributed else 0
    payload: list[dict | None] = [None]
    if rank == 0:
        try:
            if validator is None:
                raise ValueError("Rank zero requires the fixed validation sample")
            payload[0] = {"result": validator.evaluate(ema, data)}
        except Exception as error:
            payload[0] = {"error": f"{type(error).__name__}: {error}"}
    if distributed:
        dist.broadcast_object_list(payload, src=0, group=group)
    result = payload[0]
    assert result is not None
    if "error" in result:
        raise RuntimeError(f"Fixed OM4 validation failed: {result['error']}")
    return result["result"]
