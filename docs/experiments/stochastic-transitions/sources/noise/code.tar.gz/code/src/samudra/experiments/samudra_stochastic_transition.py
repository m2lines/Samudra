# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""One-pass deterministic/FiLM stochastic physical-state Samudra transitions."""

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from samudra.config import BlockConfig, UNetBackboneConfig
from samudra.models.modules.blocks import (
    BilinearUpsample,
    ConvNeXtBlock,
    CoreBlock,
    TransposedConvUpsample,
    ZonallyPeriodicBilinearUpsample,
)


def spatial_noise_operators(size, sigmas, *, periodic, device=None):
    """Separable Gaussian filters with exact unit expected variance for IID input.

    Rows are normalized by their L2 norm, not by a realized sample's variance.
    Longitude uses circular distance; latitude truncates at the physical edge.
    Thus even boundary pixels retain unit marginal variance without imposing
    reflection across a pole, subtracting a random spatial mean, or wrapping
    latitude. Sigma zero is the identity. Widths are in coarse-grid cells.
    """
    coordinates = torch.arange(size, device=device, dtype=torch.float32)
    distance = (coordinates[:, None] - coordinates[None, :]).abs()
    if periodic:
        distance = torch.minimum(distance, size - distance)
    matrices = []
    for sigma in sigmas:
        if sigma == 0:
            kernel = torch.eye(size, device=device)
        else:
            kernel = torch.exp(-0.5 * (distance / sigma).square())
            kernel = kernel * (distance <= 4 * sigma)
        matrices.append(kernel / kernel.square().sum(1, keepdim=True).sqrt())
    return torch.stack(matrices)


def multiscale_spatial_noise(field):
    """Four independent unit-variance channels at widths 0, 1, 2, 4 cells."""
    if field.shape[1] != 4:
        raise ValueError("Multiscale noise requires exactly four input channels")
    sigmas = (0, 1, 2, 4)
    latitude = spatial_noise_operators(
        field.shape[-2], sigmas, periodic=False, device=field.device
    )
    longitude = spatial_noise_operators(
        field.shape[-1], sigmas, periodic=True, device=field.device
    )
    with torch.autocast(device_type=field.device.type, enabled=False):
        return latitude @ field.float() @ longitude.transpose(-1, -2)


def noise_interpolation_scale(input_shape, output_shape, *, device=None):
    """Match each colored channel's interpolated variance to the IID control.

    Bilinear interpolation reduces white-noise variance more than correlated
    noise variance. For each axis, A is the interpolation matrix and K the
    coloring matrix: output variance is sum((AK)**2, axis=input). The separable
    ratio below removes that amplitude confound at every FiLM injection grid.
    """
    axes = []
    for source, target, periodic in zip(
        input_shape, output_shape, (False, True), strict=True
    ):
        interpolation = F.interpolate(
            torch.eye(source, device=device)[None],
            size=target,
            mode="linear",
            align_corners=False,
        )[0].T
        coloring = spatial_noise_operators(
            source, (0, 1, 2, 4), periodic=periodic, device=device
        )
        iid_variance = interpolation.square().sum(-1)
        colored_variance = (interpolation @ coloring).square().sum(-1)
        axes.append((iid_variance / colored_variance).sqrt())
    return (axes[0][:, :, None] * axes[1][:, None, :])[None]


class SpatialNoiseProcessor(nn.Module):
    """Learn spatial organization of coarse noise before existing FiLM heads.

    The physical-feature U-Net is unchanged. The zero-initialized output makes
    this branch an exact identity initially and preserves the control's draws.
    """

    def __init__(self, blocks=3, width=32):
        super().__init__()
        self.input = nn.Conv2d(4, width, 1)
        self.blocks = nn.Sequential(
            *[
                ConvNeXtBlock(
                    width, width, upscale_factor=2, norm="instance", pad="circular"
                )
                for _ in range(blocks)
            ]
        )
        self.output = nn.Conv2d(width, 4, 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, field):
        return field + self.output(self.blocks(self.input(field)))


class FeatureNoise(nn.Module):
    """Global and coarse spatial Gaussian draws modulate normalized features."""

    def __init__(
        self, channels, vector_channels=64, field_channels=4, noise_mode="iid"
    ):
        super().__init__()
        self.noise_mode = noise_mode
        # This is a derived cache rather than model state. In particular, EMA
        # copies registered buffers in place; a lazily shaped buffer would have
        # different sizes in a warmed training model and a cold EMA model.
        self._noise_ratio = None
        self._noise_ratio_shapes = None
        self.global_head = nn.Sequential(
            nn.Linear(vector_channels, 128), nn.SiLU(), nn.Linear(128, 2 * channels)
        )
        self.spatial_head = nn.Conv2d(field_channels, 2 * channels, 1)
        for head in (self.global_head[-1], self.spatial_head):
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)

    def forward(self, x, vector, field):
        modulation = self.global_head(vector.to(x.dtype))[:, :, None, None]
        spatial = F.interpolate(
            field.to(x.dtype),
            size=x.shape[-2:],
            mode="bilinear",
            align_corners=False,
        )
        if self.noise_mode == "multiscale":
            shapes = (field.shape[-2:], x.shape[-2:])
            if (
                self._noise_ratio_shapes != shapes
                or self._noise_ratio.device != field.device
            ):
                with (
                    torch.no_grad(),
                    torch.autocast(device_type=field.device.type, enabled=False),
                ):
                    self._noise_ratio = noise_interpolation_scale(
                        *shapes, device=field.device
                    )
                self._noise_ratio_shapes = shapes
            spatial = spatial * self._noise_ratio.to(spatial.dtype)
        modulation = modulation + self.spatial_head(spatial)
        gamma, beta = modulation.chunk(2, 1)
        return x * (1 + gamma) + beta


class OnePassSamudra(nn.Module):
    """Actual Samudra U-Net, with optional FiLM after middle/decoder norms.

    Noise is drawn outside this forward and passed explicitly through any
    activation checkpoint, so backward recomputation sees identical draws.
    """

    def __init__(
        self,
        inputs,
        outputs,
        widths,
        stochastic=False,
        noise_processing_blocks=0,
        noise_mode="iid",
    ):
        super().__init__()
        self.stochastic = stochastic
        self.checkpoint_blocks = False
        self.backbone = UNetBackboneConfig(
            ch_width=list(widths),
            dilation=[2**i for i in range(len(widths))],
            n_layers=[1] * len(widths),
            core_block=BlockConfig(upscale_factor=2, norm="instance"),
        ).build(inputs, pad="circular", checkpointing=None)
        self.output = nn.Conv2d(widths[0], outputs, 1)
        self.film = nn.ModuleDict()
        # Added FiLM parameters must not shift the common backbone RNG stream.
        with torch.random.fork_rng(devices=[]):
            if stochastic:
                blocks = 0
                for index, layer in enumerate(self.backbone.layers):
                    if isinstance(layer, CoreBlock):
                        if blocks >= self.backbone.num_steps:
                            assert isinstance(layer, ConvNeXtBlock)
                            self.film[str(index)] = nn.ModuleList(
                                [
                                    FeatureNoise(
                                        norm.num_features, noise_mode=noise_mode
                                    )
                                    for norm in layer.convblock
                                    if isinstance(norm, nn.InstanceNorm2d)
                                ]
                            )
                        blocks += 1
            self.noise_processor = (
                SpatialNoiseProcessor(noise_processing_blocks)
                if stochastic and noise_processing_blocks
                else nn.Identity()
            )

    @staticmethod
    def _block(layer, heads, x, vector, field):
        skip, index = layer.skip_module(x), 0
        for operation in layer.convblock:
            if isinstance(operation, nn.Conv2d) and operation.kernel_size[0] != 1:
                x = F.pad(x, (layer.N_pad, layer.N_pad, 0, 0), mode=layer.pad)
                x = F.pad(x, (0, 0, layer.N_pad, layer.N_pad))
            x = operation(x)
            if isinstance(operation, nn.InstanceNorm2d):
                x = heads[index](x, vector, field)
                index += 1
        return skip + x

    def forward(self, x, vector, field):
        field = self.noise_processor(field)
        skips = []
        up = 0
        for index, layer in enumerate(self.backbone.layers):
            if str(index) in self.film:
                heads = self.film[str(index)]

                # Bind modules now; late-bound closures would replay the wrong block.
                def run(value, z, spatial, layer=layer, heads=heads):
                    return self._block(layer, heads, value, z, spatial)

                x = (
                    checkpoint(run, x, vector, field, use_reentrant=False)
                    if self.training and self.checkpoint_blocks
                    else run(x, vector, field)
                )
            else:
                x = (
                    checkpoint(layer, x, use_reentrant=False)
                    if self.training and self.checkpoint_blocks
                    else layer(x)
                )
            if isinstance(layer, CoreBlock) and len(skips) < self.backbone.num_steps:
                skips.append(x)
            elif isinstance(
                layer,
                (
                    BilinearUpsample,
                    TransposedConvUpsample,
                    ZonallyPeriodicBilinearUpsample,
                ),
            ):
                target = skips[-1 - up]
                dh, dw = target.shape[-2] - x.shape[-2], target.shape[-1] - x.shape[-1]
                x = F.pad(x, (dw // 2, dw - dw // 2, dh // 2, dh - dh // 2)) + target
                up += 1
        return self.output(x).float()


class SamudraStochasticTransition(nn.Module):
    """A: deterministic; B: stochastic initializer; C: both stochastic.

    Persistent states have shape (batch, 2, channels, latitude, longitude).
    Both data sources use the same learned eight-to-three ERA5 adapter.
    """

    def __init__(
        self,
        initializer,
        *,
        arm="A",
        widths=(64, 128, 256),
        forcing_channels=3,
        noise_mode="iid",
        noise_processing_blocks=0,
    ):
        super().__init__()
        if arm not in ("A", "B", "C"):
            raise ValueError("Unknown stochastic transition arm")
        if noise_mode not in ("iid", "multiscale") or noise_processing_blocks not in (
            0,
            3,
        ):
            raise ValueError("Unknown noise ablation configuration")
        if arm == "A" and (noise_mode != "iid" or noise_processing_blocks):
            raise ValueError("Noise ablations require a stochastic architecture")
        if noise_mode != "iid" and noise_processing_blocks:
            raise ValueError("Noise structure and processing are separate ablations")
        self.noise_mode = noise_mode
        self.arm = arm
        self.channels, self.history = initializer.channels, initializer.history
        self.surface = list(initializer.surface)
        self.stochastic = arm != "A"
        self.forcing_channels = forcing_channels
        self.forcing_adapter = nn.Sequential(
            nn.Conv2d(8, 32, 1), nn.SiLU(), nn.Conv2d(32, forcing_channels, 1)
        )
        self.initializer = OnePassSamudra(
            self.history * (2 * len(self.surface) + forcing_channels) + 5,
            2 * self.channels,
            widths,
            arm in ("B", "C"),
            noise_processing_blocks,
            noise_mode,
        )
        self.processor = OnePassSamudra(
            2 * self.channels + forcing_channels + 5,
            self.channels,
            widths,
            arm == "C",
            noise_processing_blocks,
            noise_mode,
        )
        # Small residual head initially evolves each member near persistence.
        nn.init.normal_(self.processor.output.weight, std=1e-3)
        nn.init.zeros_(self.processor.output.bias)

    def enable_compile(self, mode="default"):
        self._compiled_initializer = torch.compile(self.initializer.forward, mode=mode)
        self._compiled_processor = torch.compile(self.processor.forward, mode=mode)

    def __getstate__(self):
        state = super().__getstate__()
        state.pop("_compiled_initializer", None)
        state.pop("_compiled_processor", None)
        return state

    def _noise(self, network, conditioning, generator):
        batch, _, height, width = conditioning.shape
        if network.stochastic:
            vector = torch.randn(
                batch, 64, device=conditioning.device, generator=generator
            )
            field = torch.randn(
                batch,
                4,
                max(1, height // 4),
                max(1, width // 4),
                device=conditioning.device,
                generator=generator,
            )
            if self.noise_mode == "multiscale":
                field = multiscale_spatial_noise(field)
        else:
            vector = conditioning.new_zeros(batch, 64)
            field = conditioning.new_zeros(batch, 4, 1, 1)
        return vector, field

    def encode_native(
        self,
        surface,
        past,
        context,
        mask,
        validity=None,
        task="om4",
        *,
        return_anchors=True,
    ):
        del task
        if surface.shape[1:3] != (self.history, len(self.surface)) or past.shape[
            1:3
        ] != (self.history, 8):
            raise ValueError("Incorrect surface or forcing history shape")
        if validity is None:
            validity = mask[self.surface].expand_as(surface)
        valid = validity.bool() & mask[self.surface].bool()
        surface = torch.where(valid, surface, torch.zeros_like(surface))
        batch, history, _, height, width = past.shape
        forcing = self.forcing_adapter(past.flatten(0, 1)).reshape(
            batch, history * self.forcing_channels, height, width
        )
        conditioning = torch.cat(
            (surface.flatten(1, 2), valid.flatten(1, 2).float(), context, forcing), 1
        )
        if not return_anchors:
            # Kept opt-in below for callers using the physical-model metadata API;
            # one-pass forecasts neither read nor apply these anchoring tensors.
            return conditioning, None, None
        known = surface.new_zeros(batch, 2, self.channels, height, width)
        anchor = torch.zeros_like(known, dtype=torch.bool)
        known[:, :, self.surface] = surface[:, -2:]
        anchor[:, :, self.surface] = valid[:, -2:]
        return conditioning, known.flatten(1, 2), anchor.flatten(1, 2)

    initializer_condition = encode_native

    def initialize(self, conditioning, known, anchor, mask, generator):
        noise = self._noise(self.initializer, conditioning, generator)
        function = (
            getattr(self, "_compiled_initializer", self.initializer)
            if self.training
            else self.initializer
        )
        output = function(conditioning, *noise)
        # Predict the complete initial state, including observed surface values.
        # The reconstruction objective supervises these rather than hard copying.
        del known, anchor
        output = output * mask.repeat(2, 1, 1)
        return output.reshape(output.shape[0], 2, self.channels, *output.shape[-2:])

    def advance(self, states, forcing, context, mask, generator):
        if forcing.shape[1] != 8:
            raise ValueError("Processor requires eight ERA5 inputs")
        conditioning = torch.cat(
            (states.flatten(1, 2), self.forcing_adapter(forcing), context), 1
        )
        noise = self._noise(self.processor, conditioning, generator)
        function = (
            getattr(self, "_compiled_processor", self.processor)
            if self.training
            else self.processor
        )
        following = (states[:, -1] + function(conditioning, *noise)) * mask
        return torch.stack((states[:, -1], following), 1)

    def forecast(
        self,
        surface,
        atmosphere,
        contexts,
        mask,
        validity,
        *,
        generator,
        members=1,
        decode_initial=True,
    ):
        if (
            members < 1
            or atmosphere.shape[1] <= self.history
            or contexts.shape[:2] != atmosphere.shape[:2]
        ):
            raise ValueError(
                "Aligned future forcing/context and positive ensemble size required"
            )
        batch = surface.shape[0]

        def repeat(value):
            if value is None:
                return None
            return value.unsqueeze(0).expand(members, *value.shape).flatten(0, 1)

        conditioning, known, anchor = self.encode_native(
            surface[:, : self.history],
            atmosphere[:, : self.history],
            contexts[:, self.history - 1],
            mask,
            validity[:, : self.history],
            return_anchors=False,
        )
        states = self.initialize(
            repeat(conditioning), repeat(known), repeat(anchor), mask, generator
        )
        initial = states.reshape(members, batch, *states.shape[1:])
        predictions = []
        for step in range(self.history, atmosphere.shape[1]):
            states = self.advance(
                states,
                repeat(atmosphere[:, step]),
                repeat(contexts[:, step]),
                mask,
                generator,
            )
            predictions.append(
                states[:, -1].reshape(members, batch, self.channels, *states.shape[-2:])
            )
        return torch.stack(predictions, 2), initial if decode_initial else None
