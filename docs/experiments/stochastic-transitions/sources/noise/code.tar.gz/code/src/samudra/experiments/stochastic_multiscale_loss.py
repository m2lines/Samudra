# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Masked regular-grid adaptation of multiscale CRPS (not graph-distance bands).

Float32 Gaussian residual bands use common gold-derived support and area-weighted
normalization. Checkpointed plane chunks bound retained smoothing activations.
"""

import math

import torch
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


def validate_scales(sigmas, weights):
    sigmas, weights = tuple(sigmas), tuple(weights)
    if not sigmas or any(not math.isfinite(s) or s <= 0 for s in sigmas):
        raise ValueError("Multiscale sigmas must be finite and positive")
    if any(a >= b for a, b in zip(sigmas, sigmas[1:])):
        raise ValueError("Multiscale sigmas must be strictly increasing")
    if len(weights) != len(sigmas) + 1 or any(
        not math.isfinite(w) or w <= 0 for w in weights
    ):
        raise ValueError("Require one positive finite weight per residual band")
    return sigmas, weights


def gaussian(values, sigma):
    """Separable convolution: periodic longitude, zero-exterior latitude."""
    radius = math.ceil(3 * sigma)
    x = torch.arange(-radius, radius + 1, device=values.device, dtype=torch.float32)
    kernel = torch.exp(-0.5 * (x / sigma).square())
    kernel = kernel / kernel.sum()
    shape = values.shape
    flat = values.reshape(-1, 1, *shape[-2:])
    # index_select also supports kernels wider than tiny test grids.
    longitude = torch.arange(-radius, shape[-1] + radius, device=values.device)
    flat = flat.index_select(-1, longitude.remainder(shape[-1]))
    flat = F.conv2d(flat, kernel.reshape(1, 1, 1, -1))
    flat = F.conv2d(F.pad(flat, (0, 0, radius, radius)), kernel.reshape(1, 1, -1, 1))
    return flat.reshape(shape)


def bands(values, weight, sigmas):
    """Yield coarsest-to-finest bands; caller supplies zeroed invalid values."""
    previous = None
    for sigma in reversed(sigmas):
        denominator = gaussian(weight, sigma)
        smooth = gaussian(values * weight, sigma) / denominator.clamp_min(1e-30)
        yield smooth if previous is None else smooth - previous
        previous = smooth
    yield values - previous


def multiscale_score(members, target, mask, area, scale, sigmas, weights):
    sigmas, weights = validate_scales(sigmas, weights)
    valid = mask.bool() & torch.isfinite(target)
    weight = (valid * area).float()
    with torch.autocast(device_type=members.device.type, enabled=False):
        values = torch.where(valid[None], members.float() / scale, 0)
        truth = torch.where(valid, target.float() / scale, 0)
        combined = torch.cat((values, truth[None]), dim=0)
        shape = target.shape[:-2]
        combined = combined.reshape(combined.shape[0], -1, *target.shape[-2:])
        weight = weight.expand_as(target).reshape(-1, *target.shape[-2:])
        count = members.shape[0]

        def chunk_score(z, w):
            total = torch.zeros_like(w)
            for band, coefficient in zip(bands(z, w, sigmas), weights):
                ensemble, gold = band[:-1], band[-1]
                point = (ensemble - gold).abs().mean(0)
                for first in range(count):
                    for second in range(first):
                        point = point - (ensemble[first] - ensemble[second]).abs() / (
                            count * (count - 1)
                        )
                total = total + coefficient * point
            return (total * w).sum((-2, -1)) / w.sum((-2, -1)).clamp_min(1e-12)

        results = []
        for offset in range(0, weight.shape[0], 8):
            z, w = combined[:, offset : offset + 8], weight[offset : offset + 8]
            results.append(
                checkpoint(chunk_score, z, w, use_reentrant=False)
                if z.requires_grad
                else chunk_score(z, w)
            )
        return torch.cat(results).reshape(shape), (weight.sum((-2, -1)) > 0).reshape(
            shape
        )
