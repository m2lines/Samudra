# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Compact native inputs for one-pass transitions; shared readers stay unchanged."""

import copy
import hashlib
import json
import resource
import threading
import time
from pathlib import Path

import numpy as np
import torch

from samudra.experiments.monthly_model_data import calendar_context


def verified_local_frames(packed_path, receipt_path, local_root):
    """Accept only the exact packed cache fully verified by this job's launcher."""
    packed = Path(packed_path).resolve()
    receipt = json.loads(Path(receipt_path).read_text())
    cache = receipt["caches"]["packed_om4"]
    if (
        receipt.get("verified") is not True
        or Path(receipt["local"]).resolve() != Path(local_root).resolve()
        or packed.parent != Path(local_root).resolve()
        or Path(cache["destination"]).resolve() != packed
        or cache["proof_sha256"]
        != hashlib.sha256((packed / "COMPLETE.json").read_bytes()).hexdigest()
    ):
        raise ValueError("Node-local packed verification receipt differs")
    proof = json.loads((packed / "COMPLETE.json").read_text())
    return set(range(len(proof["frame_sha256"])))


class CompactNativeLoader:
    """Read surface history, latest full state and full future states only.

    Full-frame checksum validation remains on first use unless the same-job
    launcher already read back every byte. Concurrent reads share a checksum
    lock so overlapping windows cannot redundantly hash identical frames.
    """

    def __init__(self, reader, forcing, data, *, verified_frames=(), resident=False):
        if reader.packed is None:
            raise ValueError("Compact campaign loader requires verified packed OM4")
        self.reader, self.forcing = reader, forcing
        self.data = copy.copy(data)
        self.data.device = torch.device("cpu")
        self.verified_frames = set(verified_frames)
        self.lock = threading.Lock()
        self.surface = [reader.names.index("thetao_0"), reader.names.index("zos")]

        self.normalized = None
        self.cache_info = {"enabled": resident}
        if resident:
            before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            started = time.monotonic()
            self.normalized = np.empty(reader.packed.shape, dtype=np.float32)
            check_seconds, normalize_seconds = 0.0, 0.0
            for offset in range(len(reader.packed)):
                tic = time.monotonic()
                self._verify([offset])
                check_seconds += time.monotonic() - tic
                tic = time.monotonic()
                self.normalized[offset] = self._normalize(
                    reader.packed[offset : offset + 1], slice(None)
                )[0]
                normalize_seconds += time.monotonic() - tic
            self.normalized.flags.writeable = False
            self.cache_info.update(
                bytes=self.normalized.nbytes,
                seconds=time.monotonic() - started,
                checksum_seconds=check_seconds,
                normalization_seconds=normalize_seconds,
                max_rss_before_kib=before,
                max_rss_after_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            )

    def _verify(self, positions):
        reader = self.reader
        with self.lock:
            for offset in positions:
                if offset not in self.verified_frames:
                    if (
                        hashlib.sha256(reader.packed[offset].tobytes()).hexdigest()
                        != reader.packed_hashes[offset]
                    ):
                        raise ValueError("Packed frame checksum changed")
                    self.verified_frames.add(offset)

    def _normalize(self, values, channels):
        reader = self.reader
        mask = reader.mask[channels]
        if not np.isfinite(values[:, mask]).all():
            raise ValueError("Nonfinite model target on declared wet support")
        return np.where(
            mask,
            (values - reader.grid["mean"][channels, None, None])
            / reader.grid["std"][channels, None, None],
            0,
        ).astype(np.float32)

    def __call__(self, index):
        reader = self.reader
        start, stop, weights, duration = reader.windows[index % len(reader.windows)]
        positions = [reader.packed_indices[i] for i in range(start - 19, stop)]
        phases = {}
        tic = time.monotonic()
        if self.normalized is None:
            self._verify(positions)
        phases["checksum_seconds"] = time.monotonic() - tic
        tic = time.monotonic()
        source = reader.packed if self.normalized is None else self.normalized
        # Select channels before stacking to avoid copying unused history.
        history = np.stack([source[p][self.surface] for p in positions[:18]])
        full = np.asarray(source[positions[18:]])
        phases["gather_seconds"] = time.monotonic() - tic
        tic = time.monotonic()
        if self.normalized is None:
            history = self._normalize(history, self.surface)
            full = self._normalize(full, slice(None))
        phases["normalization_seconds"] = time.monotonic() - tic
        tic = time.monotonic()
        atmosphere = self.forcing.load(reader, index, self.data)
        phases["forcing_seconds"] = time.monotonic() - tic
        surface = np.concatenate((history, full[:, self.surface]))
        return dict(
            surface=torch.from_numpy(surface)[None],
            targets=torch.from_numpy(full[1:])[None],
            initial_target=torch.from_numpy(full[0])[None],
            contexts=torch.as_tensor(
                calendar_context(
                    reader.lat, reader.lon, reader.midpoints[start - 19 : stop]
                )
            )[None],
            mask=torch.as_tensor(reader.mask),
            weights=torch.as_tensor(np.asarray(weights, dtype=np.float32)),
            duration=duration,
            first=str(reader.bounds[start, 0]),
            atmosphere=atmosphere,
            native_prepare_phases=phases,
        )
