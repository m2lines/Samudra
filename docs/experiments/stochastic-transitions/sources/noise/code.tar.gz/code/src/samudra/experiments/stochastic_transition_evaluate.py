# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""One-pass trajectories scored with the pinned OE five-component RMSE protocol."""

import argparse
from pathlib import Path

import numpy as np
import torch

from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.stochastic_transition_metrics import PROTOCOL, score


@torch.no_grad()
def evaluate(model, data, paths, members=8, output=None, climatology=False):
    """Monthly means are exact calendar-weighted means of member trajectories."""
    predictions, references, ohc, reference_ohc, climates = [], [], [], [], []
    model.eval()
    for number, path in enumerate(paths):
        sample = data.load(path)
        climate = data.climatology_prediction(sample)
        climates.append(data.physical(climate)[0, :, [38, 76]][:6].cpu().numpy())
        if climatology:
            native = climate
        else:
            generator = torch.Generator(device=data.device).manual_seed(904001 + number)
            with torch.autocast(
                "cuda",
                dtype=torch.bfloat16,
                enabled=str(data.device).startswith("cuda"),
            ):
                draws, initial = model.forecast(
                    sample["surface"],
                    sample["atmosphere"],
                    sample["contexts"],
                    data.mask,
                    sample["validity"],
                    generator=generator,
                    members=members,
                )
            if not torch.isfinite(draws).all() or not torch.isfinite(initial).all():
                raise ValueError("Nonfinite member on evaluation")
            native = draws.float().mean(0)
            if output is not None:
                channels = [38, 76, 47, 66]
                np.savez_compressed(
                    output / f"members-{path.stem}.npz",
                    day30=draws[:, 0, 5, channels].float().cpu().numpy(),
                    initial=initial[:, 0, -1, channels].float().cpu().numpy(),
                    monthly=(
                        draws[:, 0]
                        .index_select(2, torch.tensor(channels, device=draws.device))
                        .float()
                        * sample["month_weights"][None, :, None, None, None]
                    )
                    .sum(1)
                    .cpu()
                    .numpy(),
                    channel_names=data.grid["names"][channels],
                    units="normalized; use included mean/std",
                    mean=data.grid["mean"][channels],
                    std=data.grid["std"][channels],
                    mask=data.grid["mask"][channels],
                    day30_reference=sample["raw"]["surface"][24],
                )
            del draws, initial
        surface = data.physical(native)[0, :, [38, 76]].cpu().numpy()
        monthly = (native * sample["month_weights"][None, :, None, None, None]).sum(1)
        monthly_ohc = data.ohc(monthly)[0]
        predictions.append(surface[:6])
        references.append(
            np.concatenate(
                [sample["raw"]["surface"][19:25], sample["raw"]["velocity"][19:25]], 1
            )
        )
        ohc.append(monthly_ohc)
        reference_ohc.append(
            np.where(np.isfinite(monthly_ohc), sample["raw"]["ohc"], np.nan)
        )
    result = score(
        np.stack(predictions),
        np.stack(references),
        np.stack(ohc),
        np.stack(reference_ohc),
        data.grid["lat"],
        data.grid["lon"],
        data.grid["mask"][0],
        strict_velocity_support=True,
        global_observations=True,
        compute_spectra=False,
        climatology_surface=np.stack(climates),
    )
    result.update(
        origins=[p.stem for p in paths],
        members=members,
        readout="five-day surface ensemble mean; calendar-weighted trajectory monthly OHC",
    )
    return result


def normalized_components(result, control):
    """The pinned five equal-weight RMSE ratios require positive controls."""
    ratios = {}
    for key in PROTOCOL["integrated"]:
        numerator, denominator = result["metrics"][key], control["metrics"][key]
        if (
            not np.isfinite(numerator)
            or not np.isfinite(denominator)
            or denominator <= 0
        ):
            raise ValueError(f"Invalid fixed normalization component: {key}")
        ratios[key] = numerator / denominator
    return ratios


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("data", "checkpoint", "output"):
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument("--members", type=int, default=8)
    parser.add_argument("--limit-origins", type=int)
    parser.add_argument("--raw", action="store_true")
    args = parser.parse_args()
    from samudra.experiments.stochastic_transition_train import build_model

    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    model = build_model(saved, data, use_ema=not args.raw).eval()
    paths = data.paths("validation")
    if len(paths) != 9:
        raise ValueError("Expected frozen nine-origin validation")
    if args.limit_origins is not None:
        if args.limit_origins < 2:
            raise ValueError(
                "At least two origins are required for nonzero EKE controls"
            )
        paths = paths[: args.limit_origins]
    args.output.mkdir(parents=True, exist_ok=True)
    result = evaluate(model, data, paths, args.members, args.output)
    control = evaluate(model, data, paths, args.members, climatology=True)
    ratios = normalized_components(result, control)
    atomic_json(
        dict(
            metrics=result,
            climatology=control,
            ratios=ratios,
            score=float(np.mean(list(ratios.values()))),
            checkpoint_sha256=digest(args.checkpoint),
            weights="raw" if args.raw else "ema",
            step=saved["step"],
            qualification=bool(args.limit_origins),
        ),
        args.output / "COMPLETE.json",
    )


if __name__ == "__main__":
    main()
