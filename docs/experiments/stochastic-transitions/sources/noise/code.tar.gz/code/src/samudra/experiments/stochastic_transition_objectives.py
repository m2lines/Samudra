# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""One-pass physical trajectories: MSE control and member CRPS comparisons.

Both sources score calendar means of autoregressive samples. This differs from
OE latent-diffusion's direct monthly denoising target, intentionally and explicitly.
No spatial-gradient penalties or observation targets outside their masks are used.
"""

import math

import torch


def score(
    members,
    target,
    mask,
    area,
    scale,
    *,
    deterministic,
    objective=None,
    ensemble_mean_mse_weight=0.0,
    multiscale_sigmas=(1, 2, 4, 8),
    multiscale_weights=(1, 1, 1, 1, 1),
):
    """Return per-channel scores and support, preserving all nonspatial axes."""
    if members.shape[1:] != target.shape:
        raise ValueError("Member and target shapes must match")
    count = members.shape[0]
    if deterministic and count != 1:
        raise ValueError("The deterministic objective uses one member")
    objective = objective or ("member-mse" if deterministic else "fair-crps")
    if objective not in ("mae", "member-mse", "fair-crps", "multiscale-fair-crps"):
        raise ValueError("Unknown initializer/trajectory objective")
    if not math.isfinite(ensemble_mean_mse_weight) or ensemble_mean_mse_weight < 0:
        raise ValueError("Ensemble mean MSE weight must be finite and nonnegative")
    if ensemble_mean_mse_weight and objective != "fair-crps":
        raise ValueError("Ensemble mean MSE auxiliary requires fair CRPS")
    if objective == "fair-crps" and count < 2:
        raise ValueError("Fair CRPS requires at least two members")
    if objective == "multiscale-fair-crps":
        from .stochastic_multiscale_loss import multiscale_score

        return multiscale_score(
            members, target, mask, area, scale, multiscale_sigmas, multiscale_weights
        )
    valid = mask.bool() & torch.isfinite(target)
    weight = valid * area
    denominator = weight.sum((-2, -1))
    # Keep all support and finite checks on device. Invalid scored predictions
    # propagate into the aggregate loss, whose trainer boundary fails loudly.
    values = torch.where(valid[None], members.float(), 0)
    truth = torch.where(valid, target, 0)
    if objective == "member-mse":
        # Averages member squared errors, not squared ensemble-mean error.
        pointwise = (
            ((values[0] - truth) / scale).square()
            if count == 1
            else ((values - truth) / scale).square().mean(0)
        )
    elif objective == "mae":
        pointwise = ((values - truth).abs() / scale).mean(0)
    else:
        # Same fair estimator and pair-subtraction order as fair_crps, without
        # its per-component device-to-host finite/support checks.
        pointwise = ((values - truth).abs() / scale).mean(0)
        for first in range(count):
            for second in range(first):
                pointwise = pointwise - (values[first] - values[second]).abs() / (
                    scale * count * (count - 1)
                )
    if ensemble_mean_mse_weight:
        pointwise = (
            pointwise
            + ensemble_mean_mse_weight * ((values.mean(0) - truth) / scale).square()
        )
    reduced = (pointwise * weight).sum((-2, -1)) / denominator.clamp_min(1e-12)
    return reduced, denominator > 0


def objective_arguments(model):
    """Old models/checkpoints retain their architecture-specific loss default."""
    return dict(
        deterministic=model.arm == "A",
        objective=getattr(model, "objective", None),
        multiscale_sigmas=getattr(model, "multiscale_sigmas", (1, 2, 4, 8)),
        multiscale_weights=getattr(model, "multiscale_weights", (1, 1, 1, 1, 1)),
        ensemble_mean_mse_weight=getattr(model, "ensemble_mean_mse_weight", 0.0),
    )


def average(values, support):
    """Static-shape reduction; empty required support fails the aggregate gate.

    Boolean indexing discovers its output size on the host on CUDA. A masked
    sum avoids that synchronization. Required empty groups produce NaN rather
    than silently disappearing; only absent initializer observations are optional.
    """
    denominator = support.sum()
    return torch.where(support, values, 0).sum() / denominator


def initializer_only_objective(model, data, samples, generator, *, members, native):
    """Latest initial state only, with exactly forecast's conditioning/RNG layout.

    Native targets supervise all 77 fields; OBS supervises only valid SST/SSH.
    Neither future forcing nor future or monthly targets participate.
    """
    if native:
        compact = "initial_target" in samples[0]
        surface = torch.cat(
            [
                s["surface"]
                if compact
                else s["fields"][:, : model.history, model.surface]
                for s in samples
            ]
        )
        targets = torch.cat(
            [
                s["initial_target"] if compact else s["fields"][:, model.history - 1]
                for s in samples
            ]
        )
        mask = samples[0]["mask"]
        validity = mask[model.surface].bool().expand_as(surface)
    else:
        surface = torch.cat([s["surface"] for s in samples])
        validity = torch.cat([s["validity"] for s in samples])
        mask = data.mask
        targets = surface[:, model.history - 1]
    atmosphere = torch.cat([s["atmosphere"][:, : model.history] for s in samples])
    context = torch.cat([s["contexts"][:, model.history - 1] for s in samples])
    conditioning, known, anchor = model.encode_native(
        surface[:, : model.history],
        atmosphere,
        context,
        mask,
        validity[:, : model.history],
        return_anchors=False,
    )

    def repeat(value):
        return (
            None
            if value is None
            else value.unsqueeze(0).expand(members, *value.shape).flatten(0, 1)
        )

    state = model.initialize(
        repeat(conditioning), repeat(known), repeat(anchor), mask, generator
    )
    initial = state.reshape(members, surface.shape[0], *state.shape[1:])[:, :, -1]
    losses = []
    for index in range(len(samples)):
        pred = (
            initial[:, index : index + 1]
            if native
            else initial[:, index : index + 1, model.surface]
        )
        valid = (
            mask if native else validity[index : index + 1, model.history - 1].bool()
        )
        values, support = score(
            pred,
            targets[index : index + 1],
            valid,
            data.area,
            1.0,
            **objective_arguments(model),
        )
        if native:
            reconstruction = average(values, support)
        else:
            count = support.sum()
            count = torch.where(valid.any(), count, count.clamp_min(1))
            reconstruction = torch.where(support, values, 0).sum() / count
        losses.append(reconstruction)
    reconstruction = torch.stack(losses).mean()
    if native:
        same = torch.stack([(mask == s["mask"]).all() for s in samples]).all()
        reconstruction = torch.where(same, reconstruction, float("nan"))
    zero = reconstruction.new_zeros(())
    return 0.1 * reconstruction, torch.stack((zero, zero, reconstruction.detach()))


def observation_batch_objective(model, data, samples, generator, *, members, seeds):
    """Match latest OBS component weights; score each example before averaging."""
    if getattr(model, "training_mode", "joint") == "initializer-only":
        return initializer_only_objective(
            model, data, samples, generator, members=members, native=False
        )
    del seeds  # Surface-only initialization has no artificial hiding.
    originals = samples
    inputs = [
        torch.cat([s[k] for s in originals])
        for k in ("surface", "atmosphere", "contexts", "validity")
    ]
    predictions, initial = model.forecast(
        *inputs[:3], data.mask, inputs[3], generator=generator, members=members
    )
    losses, records = [], []
    for i, sample in enumerate(originals):
        physical = predictions[:, i : i + 1].float() * data.std + data.mean
        monthly = (
            physical * sample["month_weights"][None, None, :, None, None, None]
        ).sum(2)
        values, valid = score(
            monthly[:, :, data.ts_indices],
            sample["interior"],
            data.ts_mask,
            data.area,
            data.std[:, 0, data.ts_indices],
            **objective_arguments(model),
        )
        interior = (
            sum(
                average(values[:, group], valid[:, group])
                for group in (slice(0, 14), slice(14, 28))
            )
            / 2
        )
        values, valid = score(
            physical[:, :, :, model.surface],
            sample["raw_surface"],
            data.mask[model.surface],
            data.area,
            data.std[:, :, model.surface],
            **objective_arguments(model),
        )
        surface = sum(average(values[:, :, c], valid[:, :, c]) for c in range(2)) / 2
        target, mask = (
            sample["surface"][:, model.history - 1],
            sample["validity"][:, model.history - 1].bool(),
        )
        values, valid = score(
            initial[:, i : i + 1, -1, model.surface],
            target,
            mask,
            data.area,
            1.0,
            **objective_arguments(model),
        )
        # Previously only the validity mask controlled whether this component
        # was optional. Nonfinite targets on nonempty validity must still fail.
        required = mask.any()
        denominator = valid.sum()
        denominator = torch.where(required, denominator, denominator.clamp_min(1))
        reconstruction = torch.where(valid, values, 0).sum() / denominator
        components = torch.stack((interior, surface, reconstruction))
        losses.append((components * components.new_tensor([0.5, 0.5, 0.1])).sum())
        records.append(components.detach())
    return torch.stack(losses).mean(), torch.stack(records).mean(0)


def native_batch_objective(model, data, samples, generator, *, members, seeds):
    """Full-field month/native/init supervision on own autoregressive OM4 states."""
    if getattr(model, "training_mode", "joint") == "initializer-only":
        return initializer_only_objective(
            model, data, samples, generator, members=members, native=True
        )
    compact = "targets" in samples[0]
    if compact:
        surface = torch.cat([s["surface"] for s in samples])
        targets = torch.cat([s["targets"] for s in samples])
        initial_targets = torch.cat([s["initial_target"] for s in samples])
    else:
        # Legacy representation retained for exact-equivalence regression tests.
        fields = torch.cat([s["fields"] for s in samples])
        surface = fields[:, :, model.surface]
        targets = fields[:, model.history :]
        initial_targets = fields[:, model.history - 1]
    mask = samples[0]["mask"]
    same_support = torch.stack([(mask == s["mask"]).all() for s in samples]).all()
    del seeds
    visible = mask[model.surface].bool().expand_as(surface)
    predictions, initial = model.forecast(
        surface,
        torch.cat([s["atmosphere"] for s in samples]),
        torch.cat([s["contexts"] for s in samples]),
        mask,
        visible,
        generator=generator,
        members=members,
    )
    losses, records = [], []
    for i, sample in enumerate(samples):
        target = targets[i : i + 1]
        prediction = predictions[:, i : i + 1]
        weights = sample["weights"]
        month_prediction = (prediction * weights[None, None, :, None, None, None]).sum(
            2
        )
        month_target = (target * weights[None, :, None, None, None]).sum(1)
        monthly = average(
            *score(
                month_prediction,
                month_target,
                mask,
                data.area,
                1.0,
                **objective_arguments(model),
            )
        )
        native = average(
            *score(
                prediction, target, mask, data.area, 1.0, **objective_arguments(model)
            )
        )
        from .stochastic_velocity_intervention import (
            reconstruction as native_reconstruction,
        )

        reconstruction = native_reconstruction(
            model,
            initial[:, i : i + 1, -1],
            initial_targets[i : i + 1],
            mask,
            data.area,
        )
        components = torch.stack((monthly, native, reconstruction))
        losses.append((components * components.new_tensor([0.5, 0.5, 0.1])).sum())
        records.append(components.detach())
    # Preserve wet-support validation without one host synchronization per
    # sample. The trainer rejects this NaN at its aggregate finite-loss gate.
    loss = torch.where(same_support, torch.stack(losses).mean(), float("nan"))
    return loss, torch.stack(records).mean(0)
