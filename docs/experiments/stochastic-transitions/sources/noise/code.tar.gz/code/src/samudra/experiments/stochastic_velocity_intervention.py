# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Explicit velocity-only OM4 initializer interventions and continuation lineage."""

import copy

import torch


def corrected_mean_mse(prediction, target, mask, area, *, debias=False):
    """Per-channel sampled-mean error, optionally unbiased for squared mean error."""
    from .stochastic_transition_objectives import score

    if debias and prediction.shape[0] < 2:
        raise ValueError("Unbiased mean MSE requires at least two members")
    mse, support = score(
        prediction.mean(0, keepdim=True),
        target,
        mask,
        area,
        1.0,
        deterministic=False,
        objective="member-mse",
    )
    valid = mask.bool() & torch.isfinite(target)
    weights = valid * area
    values = torch.where(valid[None], prediction.float(), 0)
    correction = ((values.var(0, unbiased=True) / len(values)) * weights).sum(
        (-2, -1)
    ) / weights.sum((-2, -1)).clamp_min(1e-12)
    return (mse - correction if debias else mse), support, mse, correction


def reconstruction(model, prediction, target, mask, area):
    from .stochastic_transition_objectives import average, objective_arguments, score

    values, support = score(
        prediction, target, mask, area, 1.0, **objective_arguments(model)
    )
    result = average(values, support)
    multiplier = getattr(model, "velocity_init_crps_multiplier", 1.0)
    auxiliary = getattr(model, "velocity_init_mean_mse_weight", 0.0)
    if multiplier == 1.0 and auxiliary == 0.0:
        return result
    selected = torch.zeros(values.shape[-1], dtype=torch.bool, device=values.device)
    selected[model.velocity_indices] = True
    if multiplier != 1.0:
        result = (
            result
            + (multiplier - 1.0)
            * torch.where(support & selected, values, 0).sum()
            / support.sum()
        )
    if auxiliary:
        mse, valid, uncorrected, correction = corrected_mean_mse(
            prediction,
            target,
            mask,
            area,
            debias=getattr(model, "velocity_init_mean_mse_debias", False),
        )

        def selected_mean(x):
            return torch.where(valid & selected, x, 0).sum() / valid.sum()

        model.velocity_diagnostics = (
            0.1
            * auxiliary
            * torch.stack(
                [
                    selected_mean(uncorrected),
                    selected_mean(correction),
                    selected_mean(mse),
                ]
            )
        ).detach()
        result = (
            result
            + auxiliary * torch.where(valid & selected, mse, 0).sum() / valid.sum()
        )
    return result


def validate_fork(saved, requested):
    from .stochastic_transition_train import canonical_contract

    if saved["step"] != 2000 or saved["counts"] != {"om4": 1000, "observation": 1000}:
        raise ValueError("Velocity continuation requires the mixed 2k parent")
    parent = canonical_contract(saved["contract"])
    target = canonical_contract(requested)
    allowed = {
        "main_updates",
        "cooldown_updates",
        "producer",
        "fork_lineage",
        "velocity_init_mean_mse_weight",
        "velocity_init_crps_multiplier",
        "velocity_init_mean_mse_debias",
    }
    differing = {
        k
        for k in parent.keys() | target.keys()
        if k not in allowed and parent.get(k) != target.get(k)
    }
    if differing:
        raise ValueError(
            f"Fork changes unapproved contract fields: {sorted(differing)}"
        )
    if (
        target["arm"] != "B"
        or target["objective"] != "fair-crps"
        or target["main_updates"] != 2512
        or target["cooldown_updates"] != 0
    ):
        raise ValueError(
            "Velocity fork must use B fair CRPS with 512 additional mixed updates"
        )


def restore_fork(saved, model, ema, optimizer):
    """Keep Adam and raw parameters; reset EMA identically in every arm."""
    model.load_state_dict(saved["model"], strict=True)
    ema.load_state_dict(saved["model"], strict=True)
    optimizer.load_state_dict(copy.deepcopy(saved["optimizer"]))
