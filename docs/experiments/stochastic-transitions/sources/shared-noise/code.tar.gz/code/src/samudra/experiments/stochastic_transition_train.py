# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Matched one-pass stochastic transition comparison, without replay or pretraining."""

import argparse
import copy
import json
import math
import os
import random
import resource
import signal
import time
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from samudra.experiments.observation_pilot import atomic_json, atomic_torch, digest
from samudra.experiments.physical_state_train import update_ema
from samudra.experiments.task_schedule import sample_indices


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "om4", "packed-om4", "shared-era5", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--shared-era5-proof-sha256", required=True)
    p.add_argument("--reference", type=Path)
    p.add_argument("--fork-checkpoint", type=Path)
    p.add_argument("--velocity-init-mean-mse-weight", type=float, default=0.0)
    p.add_argument("--velocity-init-mean-mse-debias", action="store_true")
    p.add_argument("--velocity-init-crps-multiplier", type=float, default=1.0)
    p.add_argument("--arm", choices=list("ABC"), required=True)
    p.add_argument(
        "--objective",
        choices=("mae", "member-mse", "fair-crps", "multiscale-fair-crps"),
    )
    p.add_argument("--ensemble-mean-mse-weight", type=float, default=0.0)
    p.add_argument(
        "--training-mode", choices=("joint", "initializer-only"), default="joint"
    )
    p.add_argument("--multiscale-sigmas", default="1,2,4,8")
    p.add_argument("--multiscale-weights", default="1,1,1,1,1")
    p.add_argument("--main-updates", type=int, default=4000)
    p.add_argument("--cooldown-updates", type=int, default=1000)
    p.add_argument("--effective-batch", type=int, default=8)
    p.add_argument("--microbatch", type=int, default=1)
    p.add_argument("--members", type=int, default=4)
    p.add_argument("--widths", type=int, nargs="+", default=[64, 128, 256])
    p.add_argument("--initializer-widths", type=int, nargs="+")
    p.add_argument("--initializer-blocks", type=int, default=1)
    p.add_argument("--noise-mode", choices=("iid", "multiscale"), default="iid")
    p.add_argument("--noise-processing-blocks", type=int, choices=(0, 3), default=0)
    p.add_argument(
        "--noise-architecture",
        default="legacy",
        choices=(
            "legacy",
            "joint_coarse",
            "joint_multires",
            "gan_fullgrid",
            "shared_input",
        ),
    )
    p.add_argument("--conditional-gan", action="store_true")
    p.add_argument("--gan-critic-updates", type=int, default=5)
    p.add_argument("--seed", type=int, default=1729)
    p.add_argument("--checkpoint-every", type=int, default=500)
    p.add_argument("--max-new-updates", type=int)
    p.add_argument("--hours", type=float, default=46)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--fused-adam", action="store_true")
    p.add_argument("--resident-native-cache", action="store_true")
    p.add_argument("--compile", action="store_true")
    p.add_argument("--activation-checkpointing", action="store_true")
    p.add_argument("--check-rank-sync", action="store_true")
    p.add_argument("--prefetch-workers", type=int, default=4)
    p.add_argument("--prefetch-updates", type=int, default=4)
    p.add_argument("--obs-cache-size", type=int, default=64)
    p.add_argument("--wandb-project", default="observational-transfer")
    p.add_argument("--wandb-entity", default="ocean_emulators")
    return p


def counts(step, contract):
    main = min(step, contract["main_updates"])
    return dict(om4=main // 2, observation=(main + 1) // 2 + step - main)


def phase(step, contract):
    main, cool = contract["main_updates"], contract["cooldown_updates"]
    if not 0 <= step < main + cool:
        raise ValueError("Update outside contract")
    if step < main:
        return "observation" if step % 2 == 0 else "om4", 1e-4
    return "observation", 1e-4 + (1e-6 - 1e-4) * (step - main + 1) / cool


def canonical_contract(contract):
    """Upgrade only missing loss metadata from pre-ablation checkpoints."""
    result = dict(contract)
    result.setdefault(
        "objective", "member-mse" if contract["arm"] == "A" else "fair-crps"
    )
    result.setdefault("ensemble_mean_mse_weight", 0.0)
    return result


def contracts_match(saved, requested):
    return canonical_contract(saved) == canonical_contract(requested)


def configuration(args):
    if args.main_updates <= 0 or args.main_updates % 2 or args.cooldown_updates < 0:
        raise ValueError("Require positive even main length and nonnegative cooldown")
    if (
        min(
            args.effective_batch,
            args.microbatch,
            args.checkpoint_every,
            args.prefetch_workers,
            args.prefetch_updates,
            args.obs_cache_size,
        )
        < 1
        or args.members < 2
    ):
        raise ValueError("Invalid batch/checkpoint/worker/member count")
    if args.hours <= 0 or (
        args.max_new_updates is not None and args.max_new_updates < 1
    ):
        raise ValueError("Invalid runtime limit")
    objective = getattr(args, "objective", None) or (
        "member-mse" if args.arm == "A" else "fair-crps"
    )
    auxiliary = getattr(args, "ensemble_mean_mse_weight", 0.0)
    if objective not in ("mae", "member-mse", "fair-crps", "multiscale-fair-crps"):
        raise ValueError("Unknown objective")
    if not math.isfinite(auxiliary) or auxiliary < 0:
        raise ValueError("Auxiliary MSE weight must be finite and nonnegative")
    if auxiliary and objective != "fair-crps":
        raise ValueError("Auxiliary ensemble mean MSE requires fair CRPS")
    if objective == "fair-crps" and args.arm == "A":
        raise ValueError(
            "Fair CRPS requires a stochastic architecture with multiple members"
        )
    mode = getattr(args, "training_mode", "joint")
    if mode not in ("joint", "initializer-only"):
        raise ValueError("Unknown training mode")
    velocity_aux = getattr(args, "velocity_init_mean_mse_weight", 0.0)
    velocity_multiplier = getattr(args, "velocity_init_crps_multiplier", 1.0)
    if (
        not math.isfinite(velocity_aux)
        or velocity_aux < 0
        or not math.isfinite(velocity_multiplier)
        or velocity_multiplier <= 0
    ):
        raise ValueError("Invalid velocity initializer weights")
    velocity_options = {}
    if velocity_aux != 0 or velocity_multiplier != 1:
        if objective != "fair-crps" or mode != "joint":
            raise ValueError("Velocity intervention requires joint fair CRPS")
        velocity_options = dict(
            velocity_init_mean_mse_weight=velocity_aux,
            velocity_init_crps_multiplier=velocity_multiplier,
        )
    if getattr(args, "velocity_init_mean_mse_debias", False):
        if velocity_aux <= 0 or args.arm == "A":
            raise ValueError(
                "Corrected mean MSE requires stochastic positive auxiliary"
            )
        velocity_options["velocity_init_mean_mse_debias"] = True
    training = (
        {} if mode == "joint" else dict(training_mode=mode, processor_trainable=False)
    )
    multiscale = {}
    if objective == "multiscale-fair-crps":
        from .stochastic_multiscale_loss import validate_scales

        sigmas, weights = validate_scales(
            [float(x) for x in args.multiscale_sigmas.split(",")],
            [float(x) for x in args.multiscale_weights.split(",")],
        )
        multiscale = dict(
            multiscale_sigmas=list(sigmas),
            multiscale_weights=list(weights),
            multiscale_operator="gaussian-grid-cells-truncate3-area-mask-circular-lon-zero-lat-v1",
        )
    loss = {
        "member-mse": "MSE" if args.arm == "A" else "member-MSE",
        "mae": "MAE",
        "fair-crps": "fair-CRPS",
        "multiscale-fair-crps": "multiscale-fair-CRPS",
    }[objective]
    if auxiliary:
        loss += "+ensemble-mean-MSE"
    noise = {}
    noise_mode = getattr(args, "noise_mode", "iid")
    noise_blocks = getattr(args, "noise_processing_blocks", 0)
    if noise_mode not in ("iid", "multiscale") or noise_blocks not in (0, 3):
        raise ValueError("Unknown noise ablation configuration")
    if args.arm == "A" and (noise_mode != "iid" or noise_blocks):
        raise ValueError("Noise ablations require a stochastic architecture")
    if noise_mode != "iid" and noise_blocks:
        raise ValueError("Noise structure and processing are separate ablations")
    if noise_mode != "iid":
        noise.update(
            noise_mode=noise_mode,
            noise_sigmas=[0, 1, 2, 4],
            noise_operator="separable-gaussian-truncate4-circular-lon-truncated-lat-row-l2-v1",
            noise_injection_variance="match-iid-bilinear-expectation-per-pixel-v1",
        )
    if noise_blocks:
        noise.update(noise_processing_blocks=noise_blocks, noise_processing_width=32)
    architecture = getattr(args, "noise_architecture", "legacy")
    if architecture not in (
        "legacy",
        "joint_coarse",
        "joint_multires",
        "gan_fullgrid",
        "shared_input",
    ):
        raise ValueError("Unknown noise architecture")
    if architecture != "legacy":
        if args.arm == "A" or noise_mode != "iid" or noise_blocks:
            raise ValueError(
                "Joint noise requires stochastic IID without preprocessing"
            )
        noise["noise_architecture"] = architecture
    capacity = {}
    initializer_widths = getattr(args, "initializer_widths", None)
    initializer_blocks = getattr(args, "initializer_blocks", 1)
    if initializer_blocks < 1:
        raise ValueError("Initializer block count must be positive")
    if initializer_widths is not None:
        if not initializer_widths or min(initializer_widths) < 1:
            raise ValueError("Initializer widths must be positive")
        if list(initializer_widths) != list(args.widths):
            capacity["initializer_widths"] = list(initializer_widths)
    if initializer_blocks != 1:
        capacity["initializer_blocks"] = initializer_blocks
    gan = {}
    if getattr(args, "conditional_gan", False):
        if architecture != "gan_fullgrid" or args.arm != "B" or mode != "joint":
            raise ValueError("Conditional GAN requires joint B gan_fullgrid")
        if objective != "fair-crps" or auxiliary or velocity_options:
            raise ValueError("Conditional GAN requires otherwise unchanged fair CRPS")
        critic_updates = getattr(args, "gan_critic_updates", 5)
        if critic_updates < 1:
            raise ValueError("Critic update count must be positive")
        gan = dict(
            conditional_gan=True,
            gan_critic_updates=critic_updates,
            gan_initializer_weight=0.1,
            gan_gp_weight=10.0,
            gan_drift_weight=0.001,
            gan_critic_widths=[32, 64, 128],
            gan_critic_lr=1e-4,
            gan_critic_adam_betas=[0.5, 0.9],
            gan_target="latest OM4 initial state, all 77 normalized fields",
            gan_generator_pairs="disjoint adjacent member pairs, averaged",
            gan_critic_sampling_seed=args.seed + 700007,
            gan_conditioning="detached generator conditioning; no critic-condition gradient to ERA5 adapter",
            gan_observation_loss="unchanged fair CRPS; no observed velocity GAN target",
        )
        if args.members % 2:
            raise ValueError("Conditional GAN requires an even generator member count")
    return dict(
        **capacity,
        **gan,
        **noise,
        **multiscale,
        **velocity_options,
        **training,
        version=1,
        objective=objective,
        ensemble_mean_mse_weight=auxiliary,
        architecture="samudra-stochastic-transition",
        arm=args.arm,
        widths=args.widths,
        history=19,
        physical_history_slots=2,
        state_channels=77,
        forcing_channels=8,
        forcing_adapter=[8, 32, 3],
        main_updates=args.main_updates,
        cooldown_updates=args.cooldown_updates,
        effective_batch=args.effective_batch,
        training_members=1 if args.arm == "A" else args.members,
        seed=args.seed,
        learning_rate=1e-4,
        minimum_lr=1e-6,
        ema_half_life=100,
        ema_reset_at_cooldown=True,
        retain_adam=True,
        gradient_clip=1.0,
        observation_weights=[0.5, 0.5, 0.1],
        om4_weights=[0.5, 0.5, 0.1],
        loss=loss,
        spatial_gradient_loss=False,
        replay=False,
        initialization_task="surface",
        artificial_hiding=False,
        initial_reconstruction="latest state, available surface for OBS; all fields for OM4",
        monthly_readout="calendar-weighted member trajectories, not direct denoising",
        native_readout="all native leads averaged, not random single-lead subsampling",
        normalization="fixed OM4 grid mean/std, frozen OBS ERA5 statistics",
        global_observations=True,
        precision="bf16 autocast with fp32 parameters/loss",
        activation_checkpointing=args.activation_checkpointing,
    )


def build_model(saved, data, *, use_ema=True):
    """Evaluation entrypoint; saved=None is intentionally unsupported."""
    model = make_model(data.grid["names"].tolist(), data.device, saved["contract"])
    model.load_state_dict(saved["ema"] if use_ema else saved["model"], strict=True)
    return model


def make_model(names, device, contract):
    from samudra.experiments.samudra_stochastic_transition import (
        SamudraStochasticTransition,
    )

    metadata = SimpleNamespace(
        channels=len(names),
        history=19,
        surface=[names.index("thetao_0"), names.index("zos")],
    )
    model = SamudraStochasticTransition(
        metadata,
        arm=contract["arm"],
        widths=tuple(contract["widths"]),
        forcing_channels=3,
        noise_mode=contract.get("noise_mode", "iid"),
        noise_processing_blocks=contract.get("noise_processing_blocks", 0),
        noise_architecture=contract.get("noise_architecture", "legacy"),
        initializer_widths=contract.get("initializer_widths"),
        initializer_blocks=contract.get("initializer_blocks", 1),
    ).to(device)
    loss_contract = canonical_contract(contract)
    model.training_mode = loss_contract.get("training_mode", "joint")
    if model.training_mode == "initializer-only":
        model.processor.requires_grad_(False)
    model.velocity_init_mean_mse_debias = loss_contract.get(
        "velocity_init_mean_mse_debias", False
    )
    model.velocity_init_mean_mse_weight = loss_contract.get(
        "velocity_init_mean_mse_weight", 0.0
    )
    model.velocity_init_crps_multiplier = loss_contract.get(
        "velocity_init_crps_multiplier", 1.0
    )
    model.velocity_indices = [
        i for i, n in enumerate(names) if n.startswith(("uo_", "vo_"))
    ]
    model.objective = loss_contract["objective"]
    model.multiscale_sigmas = loss_contract.get("multiscale_sigmas", (1, 2, 4, 8))
    model.multiscale_weights = loss_contract.get("multiscale_weights", (1, 1, 1, 1, 1))
    model.ensemble_mean_mse_weight = loss_contract["ensemble_mean_mse_weight"]
    return model


def rng_state():
    return dict(
        cpu=torch.get_rng_state(),
        cuda=torch.cuda.get_rng_state(),
        numpy=np.random.get_state(),
        python=random.getstate(),
    )


def restore_rng(state):
    torch.set_rng_state(state["cpu"])
    torch.cuda.set_rng_state(state["cuda"])
    np.random.set_state(state["numpy"])
    random.setstate(state["python"])


class UpdatePrefetch:
    """Bounded CPU-only lookahead; sampling order belongs to the trainer.

    Depth includes the current update. While GPU computation runs there are at
    most depth-1 prepared/queued updates ahead. No global RNG is consumed here.
    """

    def __init__(self, selection, loader, *, start, stop, depth=4, workers=4):
        if depth < 1 or workers < 1 or start < 0 or stop < start:
            raise ValueError("Invalid prefetch bounds")
        self.selection, self.loader = selection, loader
        self.expected, self.stop, self.depth = start, stop, depth
        self.executor = ThreadPoolExecutor(
            max_workers=workers, thread_name_prefix="onepass-data"
        )
        self.pending = {}

    def _load(self, source, index):
        started = time.monotonic()
        result = self.loader(source, index)
        if any(
            isinstance(v, torch.Tensor) and v.device.type != "cpu"
            for v in result.values()
        ):
            raise ValueError("Prefetch loader produced CUDA tensors")
        return result, time.monotonic() - started

    def take(self, step):
        if step != self.expected or step >= self.stop:
            raise ValueError(
                "Prefetch consumption must follow the declared update sequence"
            )
        for future_step in range(step, min(self.stop, step + self.depth)):
            if future_step in self.pending:
                continue
            source, slots = self.selection(future_step)
            self.pending[future_step] = (
                slots,
                [self.executor.submit(self._load, source, index) for _, index in slots],
            )
        slots, futures = self.pending.pop(step)
        loaded = [future.result() for future in futures]
        self.expected += 1
        return (
            slots,
            [item for item, _ in loaded],
            sum(seconds for _, seconds in loaded),
        )

    def close(self):
        self.executor.shutdown(wait=True, cancel_futures=True)
        self.pending.clear()


def main():
    args = parser().parse_args()
    contract = configuration(args)
    if not torch.cuda.is_available():
        raise RuntimeError("Training requires CUDA")
    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.physical_state_batching import compatible_groups
    from samudra.experiments.physical_state_distributed import DistributedRun
    from samudra.experiments.physical_state_prefetch import native_to_device
    from samudra.experiments.shared_era5 import SharedEra5
    from samudra.experiments.stochastic_transition_objectives import (
        native_batch_objective,
        observation_batch_objective,
    )

    torch.set_num_threads(1)
    device = torch.device("cuda", int(os.environ.get("LOCAL_RANK", 0)))
    torch.cuda.set_device(device)
    runtime = DistributedRun(device)
    if contract.get("conditional_gan") and runtime.world_size != 1:
        raise ValueError("Conditional GAN pilot is qualified for one GPU only")
    if args.resident_native_cache and runtime.world_size != 1:
        raise ValueError(
            "Resident cache memory budget is qualified for one process only"
        )
    if args.effective_batch % runtime.world_size:
        raise ValueError("World size must divide global batch")
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    data = Samples(args.data, device, surface_fill="zero", global_observations=True)
    cpu_data = Samples(
        args.data, torch.device("cpu"), surface_fill="zero", global_observations=True
    )
    cpu_data.__dict__["read_sample"] = lru_cache(maxsize=args.obs_cache_size)(
        cpu_data.read_sample.__wrapped__
    )
    paths = data.paths("train")
    if (len(paths), len(data.paths("validation")), len(data.paths("test"))) != (
        243,
        9,
        96,
    ):
        raise ValueError("Observation cohort changed")
    reader = ModelMonths(
        args.om4 / "OM4.zarr", "om4", data.grid, args.om4, packed=args.packed_om4
    )
    if len(reader.windows) != 409:
        raise ValueError("OM4 window count changed")
    forcing = SharedEra5(
        args.shared_era5,
        reader,
        data,
        args.shared_era5_proof_sha256,
        full_readback=True,
    )
    from samudra.experiments.stochastic_transition_data import (
        CompactNativeLoader,
        verified_local_frames,
    )

    verified_frames = ()
    if os.environ.get("ONEPASS_LOCAL_DATA") and os.environ.get("SLURM_JOB_ID"):
        receipt_name = f"node-local-{os.environ['SLURM_JOB_ID']}.json"
        receipts = [p / receipt_name for p in (args.output, *args.output.parents)]
        receipt = next((p for p in receipts if p.is_file()), None)
        if receipt is None:
            raise ValueError(
                "Node-local data advertised without same-job verification receipt"
            )
        verified_frames = verified_local_frames(
            args.packed_om4, receipt, os.environ["ONEPASS_LOCAL_DATA"]
        )
    native_loader = CompactNativeLoader(
        reader,
        forcing,
        data,
        verified_frames=verified_frames,
        resident=args.resident_native_cache,
    )
    contract.update(
        grid=digest(args.data / "grid.npz"),
        statistics=digest(args.data / "statistics.npz"),
        observation_manifest=digest(args.data / "SHA256SUMS"),
        om4_metadata=digest(args.om4 / "OM4.zarr/.zmetadata"),
        packed_proof=digest(args.packed_om4 / "COMPLETE.json"),
        shared_era5_proof=args.shared_era5_proof_sha256,
        reference=digest(args.reference) if args.reference else None,
        producer=os.environ.get("SAMUDRA_CODE_COMMIT", "unrecorded"),
    )
    fork_saved = None
    if args.fork_checkpoint:
        from .stochastic_velocity_intervention import validate_fork

        fork_saved = torch.load(
            args.fork_checkpoint, map_location="cpu", weights_only=False
        )
        contract["fork_lineage"] = dict(
            path=str(args.fork_checkpoint),
            sha256=digest(args.fork_checkpoint),
            step=fork_saved["step"],
            counts=fork_saved["counts"],
            parent_contract=fork_saved["contract"],
            retain_adam=True,
            reset_ema_to_raw=True,
        )
        validate_fork(fork_saved, contract)
    args.output.mkdir(parents=True, exist_ok=True)
    protocol = args.output / "protocol.json"
    if protocol.exists() and not contracts_match(
        json.loads(protocol.read_text()), contract
    ):
        raise ValueError("Output protocol differs")
    if runtime.primary:
        atomic_json(contract, protocol)
        atomic_json(
            dict(
                world_size=runtime.world_size,
                microbatch=args.microbatch,
                compiled=args.compile,
                fused_adam=args.fused_adam,
                prefetch_workers=args.prefetch_workers,
                prefetch_updates=args.prefetch_updates,
                obs_cache_size=args.obs_cache_size,
                resident_native_cache=native_loader.cache_info,
            ),
            args.output / "execution.json",
        )
    model = make_model(data.grid["names"].tolist(), device, contract)
    ema = copy.deepcopy(model).eval().requires_grad_(False)
    if args.activation_checkpointing:
        model.initializer.checkpoint_blocks = True
        model.processor.checkpoint_blocks = True
    if args.compile:
        model.enable_compile()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=1e-4, weight_decay=0.01, fused=args.fused_adam
    )
    gan = None
    if contract.get("conditional_gan"):
        from .stochastic_gan_training import ConditionalGanTraining

        gan = ConditionalGanTraining(
            model,
            seed=args.seed,
            learning_rate=contract["gan_critic_lr"],
            widths=tuple(contract["gan_critic_widths"]),
        )
    last = args.output / "last.pt"
    if last.exists() != args.resume:
        raise ValueError("Existing checkpoint requires --resume and vice versa")
    completed, run_id = 0, None
    if args.resume:
        saved = torch.load(last, map_location="cpu", weights_only=False)
        if (
            not contracts_match(saved["contract"], contract)
            or len(saved["rank_rng"]) != runtime.world_size
        ):
            raise ValueError("Resume contract/world-size differs")
        model.load_state_dict(saved["model"], strict=True)
        ema.load_state_dict(saved["ema"], strict=True)
        optimizer.load_state_dict(saved["optimizer"])
        completed, run_id = saved["step"], saved["wandb_id"]
        if saved["counts"] != counts(completed, contract):
            raise ValueError("Checkpoint exposure differs")
        if gan is not None:
            gan.load_state_dict(saved["gan"])
            expected = saved["counts"]["om4"] * contract["gan_critic_updates"]
            if (
                gan.updates != expected
                or gan.examples != expected * args.effective_batch
            ):
                raise ValueError("Checkpoint discriminator exposure differs")
        restore_rng(saved["rank_rng"][runtime.rank])
        del saved
    if fork_saved is not None and not args.resume:
        from .stochastic_velocity_intervention import restore_fork

        restore_fork(fork_saved, model, ema, optimizer)
        completed = fork_saved["step"]
        if len(fork_saved["rank_rng"]) != runtime.world_size:
            raise ValueError("Fork world size differs")
        restore_rng(fork_saved["rank_rng"][runtime.rank])
    del fork_saved
    run = None
    if runtime.primary and not args.smoke:
        import wandb

        run = wandb.init(
            project=args.wandb_project,
            entity=args.wandb_entity,
            name=f"onepass-{args.arm}",
            config=contract,
            dir=str(args.output),
            id=run_id,
            resume="must" if run_id else None,
        )
        run_id = run.id
        atomic_json(dict(id=run.id, url=run.url), args.output / "wandb.json")
    run_id = runtime.gather(run_id)[0]
    total = args.main_updates + args.cooldown_updates
    stop = False

    def stopping(*_):
        nonlocal stop
        stop = True

    for sig in (signal.SIGTERM, signal.SIGUSR1):
        signal.signal(sig, stopping)

    def save(snapshot=False):
        states = runtime.gather(rng_state())
        disagreement = (
            runtime.parameter_disagreement(model) if args.check_rank_sync else None
        )
        if disagreement is not None and disagreement != 0:
            raise RuntimeError("Ranks diverged")
        if runtime.primary:
            payload = dict(
                contract=contract,
                model=model.state_dict(),
                ema=ema.state_dict(),
                optimizer=optimizer.state_dict(),
                step=completed,
                counts=counts(completed, contract),
                rank_rng=states,
                wandb_id=run_id,
            )
            if gan is not None:
                payload["gan"] = gan.state_dict()
            atomic_torch(payload, last)
            if snapshot:
                atomic_torch(payload, args.output / f"step-{completed:05d}.pt")
            atomic_json(
                dict(
                    step=completed,
                    counts=counts(completed, contract),
                    complete=completed == total,
                    rank_disagreement=disagreement,
                ),
                args.output / "state.json",
            )
        runtime.barrier()

    if not args.resume:
        save(True)
    initial_step = completed
    wall_start = time.monotonic()

    def slots(step):
        source, _ = phase(step, contract)
        exposure = counts(step, contract)[source]
        indices = sample_indices(
            len(paths) if source == "observation" else len(reader.windows),
            args.seed + (0 if source == "observation" else 100003),
            exposure,
            args.effective_batch,
        )
        return source, [
            (i, index) for i, index in enumerate(indices) if runtime.owns(i)
        ]

    def load(source, index):
        return (
            cpu_data.load(paths[index])
            if source == "observation"
            else native_loader(index)
        )

    execution_stop = (
        min(total, completed + args.max_new_updates)
        if args.max_new_updates is not None
        else total
    )
    prefetch = UpdatePrefetch(
        slots,
        load,
        start=completed,
        stop=execution_stop,
        depth=args.prefetch_updates,
        workers=args.prefetch_workers,
    )
    critic_prefetch = None
    if gan is not None:

        def critic_slots(update):
            indices = sample_indices(
                len(reader.windows),
                contract["gan_critic_sampling_seed"],
                update,
                args.effective_batch,
            )
            return "om4", list(enumerate(indices))

        critic_prefetch = UpdatePrefetch(
            critic_slots,
            load,
            start=gan.updates,
            stop=counts(execution_stop, contract)["om4"]
            * contract["gan_critic_updates"],
            depth=args.prefetch_updates,
            workers=args.prefetch_workers,
        )
    try:
        while completed < total:
            if runtime.any(
                stop
                or time.monotonic() - wall_start > args.hours * 3600
                or (
                    args.max_new_updates is not None
                    and completed - initial_step >= args.max_new_updates
                )
            ):
                break
            step_started = time.time()
            tic = time.monotonic()
            source, lr = phase(completed, contract)
            if completed == args.main_updates:
                ema.load_state_dict(model.state_dict())
            selection, cpu_samples, prepare_seconds = prefetch.take(completed)
            data_wait = time.monotonic() - tic
            samples = [native_to_device(s, device) for s in cpu_samples]
            model.train()
            critic_records = []
            critic_data_wait = 0.0
            if gan is not None and source == "om4":
                for _ in range(contract["gan_critic_updates"]):
                    wait_started = time.monotonic()
                    _, critic_cpu_samples, _ = critic_prefetch.take(gan.updates)
                    critic_data_wait += time.monotonic() - wait_started
                    critic_samples = [
                        native_to_device(s, device) for s in critic_cpu_samples
                    ]
                    critic_records.append(
                        gan.update(model, critic_samples, microbatch=args.microbatch)
                    )
                    del critic_samples, critic_cpu_samples
            optimizer.zero_grad(set_to_none=True)
            for group in optimizer.param_groups:
                group["lr"] = lr
            velocity_stats = torch.zeros(3, device=device)
            components = torch.zeros(3, device=device)
            loss_total = torch.zeros((), device=device)
            for group in compatible_groups(samples, args.microbatch):
                seed = args.seed + completed * 1000003 + selection[group[0]][0] * 1009
                generator = torch.Generator(device=device).manual_seed(seed)
                inputs = [samples[i] for i in group]
                seeds = [
                    args.seed + completed * 1000003 + selection[i][0] * 1009
                    for i in group
                ]
                function = (
                    observation_batch_objective
                    if source == "observation"
                    else native_batch_objective
                )
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    extra = (
                        {"initializer_critic": gan.critic}
                        if gan is not None and source == "om4"
                        else {}
                    )
                    loss, parts = function(
                        model,
                        data,
                        inputs,
                        generator,
                        members=contract["training_members"],
                        seeds=seeds,
                        **extra,
                    )
                scale = len(group) / args.effective_batch
                if not torch.isfinite(loss):
                    raise FloatingPointError("Nonfinite loss")
                (loss * scale).backward()
                loss_total += loss.detach() * scale
                components += parts * scale
                if source == "om4" and hasattr(model, "velocity_diagnostics"):
                    velocity_stats += model.velocity_diagnostics * scale
            runtime.sum_gradients(model)
            grad = torch.nn.utils.clip_grad_norm_(
                model.parameters(), 1.0, error_if_nonfinite=True
            )
            optimizer.step()
            update_ema(ema, model, 100)
            torch.cuda.synchronize(device)
            elapsed = time.monotonic() - tic
            usage = resource.getrusage(resource.RUSAGE_SELF)
            rows = runtime.gather(
                dict(
                    loss=float(loss_total),
                    components=components.cpu().tolist(),
                    seconds=elapsed,
                    data_wait_seconds=data_wait,
                    data_prepare_worker_seconds=prepare_seconds,
                    native_prepare_phases={
                        key: sum(
                            s.get("native_prepare_phases", {}).get(key, 0.0)
                            for s in cpu_samples
                        )
                        for key in (
                            "checksum_seconds",
                            "gather_seconds",
                            "normalization_seconds",
                            "forcing_seconds",
                        )
                    },
                    max_rss_kib=usage.ru_maxrss,
                    major_faults=usage.ru_majflt,
                    minor_faults=usage.ru_minflt,
                    peak_allocated_bytes=torch.cuda.max_memory_allocated(device),
                )
            )
            completed += 1
            event = dict(
                step=completed,
                source=source,
                lr=lr,
                loss=sum(r["loss"] for r in rows),
                components=np.sum([r["components"] for r in rows], axis=0).tolist(),
                grad_norm=float(grad),
                seconds=max(r["seconds"] for r in rows),
                data_wait_seconds=max(r["data_wait_seconds"] for r in rows),
                data_prepare_worker_seconds=sum(
                    r["data_prepare_worker_seconds"] for r in rows
                ),
                native_prepare_phases={
                    key: sum(r["native_prepare_phases"][key] for r in rows)
                    for key in rows[0]["native_prepare_phases"]
                },
                max_rank_rss_kib=max(r["max_rss_kib"] for r in rows),
                major_faults=sum(r["major_faults"] for r in rows),
                minor_faults=sum(r["minor_faults"] for r in rows),
                queued_updates=len(prefetch.pending),
                peak_allocated_bytes=max(r["peak_allocated_bytes"] for r in rows),
                velocity_auxiliary_terms=velocity_stats.cpu().tolist(),
                update_started_unix=step_started,
                update_finished_unix=time.time(),
                counts=counts(completed, contract),
            )
            if gan is not None:
                event.update(
                    gan_critic_updates=gan.updates,
                    gan_critic_examples=gan.examples,
                    gan_critic_data_wait_seconds=critic_data_wait,
                    gan_critic_seconds=sum(r["seconds"] for r in critic_records),
                    gan_critic_records=critic_records,
                    gan_initializer_unweighted=(
                        float(components[2]) if source == "om4" else None
                    ),
                )
            if runtime.primary:
                with (args.output / "events.jsonl").open("a") as stream:
                    stream.write(json.dumps(event) + "\n")
                print(json.dumps(event), flush=True)
                if run:
                    run.log(event, step=completed)
            # Release current CPU/GPU example containers before filling the next queue slot.
            del cpu_samples, samples, inputs
            if (
                completed - contract.get("fork_lineage", {}).get("step", 0)
            ) % args.checkpoint_every == 0 or completed in (
                args.main_updates,
                total,
            ):
                save(True)
        save(completed == total)
        if completed == total and runtime.primary:
            atomic_json(
                dict(
                    step=completed,
                    counts=counts(completed, contract),
                    complete=True,
                    **(
                        dict(
                            gan_critic_updates=gan.updates,
                            gan_critic_examples=gan.examples,
                        )
                        if gan is not None
                        else {}
                    ),
                ),
                args.output / "COMPLETE.json",
            )
    finally:
        prefetch.close()
        if critic_prefetch is not None:
            critic_prefetch.close()
        if run:
            run.finish()


if __name__ == "__main__":
    main()
