# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Assemble immutable dense OM4/ERA5 caches, retaining parent frames exactly."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def frame_digest(values):
    return hashlib.sha256(values.tobytes()).hexdigest()


def assemble(parent_root, missing_root, audit_path, output, packed_sha, forcing_sha):
    parent_root, missing_root, output = map(Path, (parent_root, missing_root, output))
    packed_root, forcing_root = (
        parent_root / "packed-om4",
        parent_root / "forcing-cache",
    )
    if (
        digest(packed_root / "COMPLETE.json") != packed_sha
        or digest(forcing_root / "COMPLETE.json") != forcing_sha
    ):
        raise ValueError("Parent cache proof changed")
    packed, forcing, missing, audit = (
        load_json(packed_root / "COMPLETE.json"),
        load_json(forcing_root / "COMPLETE.json"),
        load_json(missing_root / "COMPLETE.json"),
        load_json(audit_path),
    )
    required = audit["required_frame_indices"]
    old_indices, new_indices = packed["indices"], missing["indices"]
    if (
        required != sorted(set(required))
        or old_indices != sorted(set(old_indices))
        or new_indices != sorted(set(new_indices))
        or set(old_indices) & set(new_indices)
        or sorted(old_indices + new_indices) != required
        or missing["schema"] != "stochastic-dense-missing-v1"
        or missing["all_frames_readback_exact"] is not True
        or missing["source_metadata_sha256"] != packed["source_metadata_sha256"]
        or missing["parent_grid_sha256"] != packed["grid_sha256"]
    ):
        raise ValueError("Missing-frame extension contract differs")
    for root, proof in ((forcing_root, forcing), (missing_root, missing)):
        for name, expected in proof["files"].items():
            if digest(root / name) != expected:
                raise ValueError(f"Input payload checksum differs: {root / name}")
    if (
        np.load(forcing_root / "indices.npy").tolist() != old_indices
        or np.load(missing_root / "indices.npy").tolist() != new_indices
    ):
        raise ValueError("Forcing/missing indices differ from physical frames")
    old_frames = np.load(packed_root / "frames.npy", mmap_mode="r")
    old_forcing = np.load(forcing_root / "values.npy", mmap_mode="r")
    add_frames = np.load(missing_root / "frames.npy", mmap_mode="r")
    add_forcing = np.load(missing_root / "values.npy", mmap_mode="r")
    for values, count in (
        (old_frames, len(old_indices)),
        (old_forcing, len(old_indices)),
        (add_frames, len(new_indices)),
        (add_forcing, len(new_indices)),
    ):
        if values.dtype != np.float32 or values.shape[0] != count:
            raise ValueError("Cache shape/dtype differs")
    if (
        list(old_frames.shape) != packed["shape"]
        or add_frames.shape[1:] != old_frames.shape[1:]
        or add_forcing.shape[1:] != old_forcing.shape[1:]
    ):
        raise ValueError("Physical/forcing grids differ")
    if (
        len(packed["frame_sha256"]) != len(old_indices)
        or len(forcing["bounds"]) != len(old_indices)
        or len(missing["bounds"]) != len(new_indices)
    ):
        raise ValueError("Frame audit lengths differ")
    output.mkdir(parents=True, exist_ok=False)
    new_packed, new_era5 = output / "packed-om4", output / "forcing-cache"
    new_packed.mkdir()
    new_era5.mkdir()
    frames = np.lib.format.open_memmap(
        new_packed / "frames.npy",
        mode="w+",
        dtype="float32",
        shape=(len(required), *old_frames.shape[1:]),
    )
    atmosphere = np.lib.format.open_memmap(
        new_era5 / "values.npy",
        mode="w+",
        dtype="float32",
        shape=(len(required), *old_forcing.shape[1:]),
    )
    old_map = {index: position for position, index in enumerate(old_indices)}
    add_map = {index: position for position, index in enumerate(new_indices)}
    bounds, hashes = [], []
    for position, index in enumerate(required):
        prior = index in old_map
        source_position = old_map[index] if prior else add_map[index]
        physical_source = old_frames if prior else add_frames
        forcing_source = old_forcing if prior else add_forcing
        physical_hash = (packed if prior else missing)["frame_sha256"][source_position]
        if frame_digest(physical_source[source_position]) != physical_hash:
            raise ValueError(f"Physical source frame checksum differs at {index}")
        if (
            not prior
            and frame_digest(forcing_source[source_position])
            != missing["forcing_frame_sha256"][source_position]
        ):
            raise ValueError(f"Added forcing frame checksum differs at {index}")
        frames[position] = physical_source[source_position]
        atmosphere[position] = forcing_source[source_position]
        hashes.append(physical_hash)
        bounds.append((forcing if prior else missing)["bounds"][source_position])
        if position % 100 == 0:
            print(
                json.dumps(
                    dict(stage="assemble", position=position, total=len(required))
                ),
                flush=True,
            )
    frames.flush()
    atmosphere.flush()
    del frames, atmosphere
    frames = np.load(new_packed / "frames.npy", mmap_mode="r")
    atmosphere = np.load(new_era5 / "values.npy", mmap_mode="r")
    for position, index in enumerate(required):
        prior = index in old_map
        source_position = old_map[index] if prior else add_map[index]
        physical_source = old_frames if prior else add_frames
        forcing_source = old_forcing if prior else add_forcing
        if (
            frames[position].tobytes() != physical_source[source_position].tobytes()
            or atmosphere[position].tobytes()
            != forcing_source[source_position].tobytes()
        ):
            raise ValueError(f"Assembled frame readback differs at {index}")
        if position % 100 == 0:
            print(
                json.dumps(
                    dict(stage="readback", position=position, total=len(required))
                ),
                flush=True,
            )
    np.save(new_era5 / "indices.npy", np.asarray(required, dtype=np.int64))
    cohort = {
        key: audit[key]
        for key in (
            "windows_sha256",
            "required_source_intervals_sha256",
            "window_count",
            "required_frame_count",
        )
    }
    extension = dict(
        schema="stochastic-dense-cache-extension-v1",
        old_frame_count=len(old_indices),
        added_frame_indices=new_indices,
        source_metadata_sha256=packed["source_metadata_sha256"],
        cohort=cohort,
    )
    producer = "stochastic-dense-assembly-" + digest(__file__)
    packed_proof = dict(
        packed,
        producer=producer,
        indices=required,
        shape=list(frames.shape),
        frame_sha256=hashes,
        bytes=(new_packed / "frames.npy").stat().st_size,
        extension=dict(
            extension, parent_cache=str(packed_root), parent_proof_sha256=packed_sha
        ),
    )
    sources = dict(forcing["sources"])
    for path, checksum in missing["sources"].items():
        if path in sources and sources[path] != checksum:
            raise ValueError("ERA5 daily source digest changed")
        sources[path] = checksum
    forcing_proof = dict(
        forcing,
        producer=producer,
        windows=audit["window_count"],
        intervals=len(required),
        bounds=bounds,
        sources=sources,
        files={name: digest(new_era5 / name) for name in ("values.npy", "indices.npy")},
        extension=dict(
            extension, parent_cache=str(forcing_root), parent_proof_sha256=forcing_sha
        ),
    )
    # Recompute overlap count rather than inheriting the old cohort's count.
    forcing_proof["overlap_intervals"] = sum(
        int(bound[0][:4]) >= 1993 for bound in bounds
    )
    write_json(new_packed / "COMPLETE.json", packed_proof)
    write_json(new_era5 / "COMPLETE.json", forcing_proof)
    summary = dict(
        producer=producer,
        parent_cache=str(parent_root),
        missing_cache=str(missing_root),
        missing_proof_sha256=digest(missing_root / "COMPLETE.json"),
        audit_sha256=digest(audit_path),
        cohort=cohort,
        parent_frames_byte_identical=True,
        all_frames_readback_exact=True,
        retained_frames=len(old_indices),
        added_frames=len(new_indices),
        total_frames=len(required),
        packed_proof_sha256=digest(new_packed / "COMPLETE.json"),
        forcing_proof_sha256=digest(new_era5 / "COMPLETE.json"),
    )
    write_json(output / "ASSEMBLED.json", summary)
    print(json.dumps(summary), flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("parent-root", "missing-root", "audit", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--packed-parent-sha256", required=True)
    parser.add_argument("--forcing-parent-sha256", required=True)
    args = parser.parse_args()
    assemble(
        args.parent_root,
        args.missing_root,
        args.audit,
        args.output,
        args.packed_parent_sha256,
        args.forcing_parent_sha256,
    )


if __name__ == "__main__":
    main()
