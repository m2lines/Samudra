# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Export only missing dense-cohort frames from original OM4 and daily ERA5."""

import argparse
import hashlib
import io
import json
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from samudra.experiments.monthly_model_data import ModelMonths
from samudra.experiments.observation_data import strict_mean


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--original-root", type=Path, required=True)
    args = parser.parse_args()
    root, original = args.root, args.original_root
    config = json.loads((original / "paths-interval-audit.json").read_text())
    audit = json.loads((root / "receipt.json").read_text())
    parent = json.loads((root / "packed-parent.json").read_text())
    indices = audit["missing_packed"]
    if indices != audit["missing_era5"] or len(indices) != 110:
        raise ValueError("Unexpected audited missing cohort")
    samples, source = Path(config["samples"]), Path(config["om4"])
    grid = dict(np.load(samples / "grid.npz"))
    if digest(source / "OM4.zarr/.zmetadata") != parent["source_metadata_sha256"]:
        raise ValueError("Original OM4 metadata differs from packed parent")
    reader = ModelMonths(source / "OM4.zarr", "om4", grid, source)
    if len(reader.windows) != audit["original_window_count"]:
        raise ValueError("Original monthly cohort changed")
    early = original / "era5"
    gate = json.loads((early / "QUALIFIED.json").read_text())
    early_hashes = {}
    for year in range(1975, 1993):
        proof = json.loads((early / f"daily/era5/{year}/COMPLETE.json").read_text())
        if proof["contract"] != gate["contract"]:
            raise ValueError("Historical ERA5 contract changed")
        early_hashes.update(proof["files"])
    source_hashes = {}

    @lru_cache(maxsize=32)
    def day(stamp):
        base = early / "daily" if stamp.year < 1993 else Path(config["daily"])
        path = base / "era5" / str(stamp.year) / (stamp.strftime("%Y-%m-%d") + ".npz")
        raw = path.read_bytes()
        checksum = hashlib.sha256(raw).hexdigest()
        if stamp.year < 1993 and checksum != early_hashes[path.name]:
            raise ValueError("Historical ERA5 payload changed")
        source_hashes[str(path)] = checksum
        with np.load(io.BytesIO(raw)) as saved:
            values = saved["values"]
            if pd.Timestamp(str(saved["time"])) != stamp:
                raise ValueError("Daily timestamp changed")
        if values.shape != (8, 180, 360) or not np.isfinite(values).all():
            raise ValueError("Invalid daily ERA5 payload")
        return values

    def physical(index):
        values = np.stack([reader.store[name][index] for name in reader.names]).astype(
            np.float32
        )
        if not np.isfinite(values[reader.mask]).all():
            raise ValueError("Nonfinite wet OM4 source")
        return values

    # Source identity check against a previously packed complete physical frame.
    anchor_index = parent["indices"][0]
    if (
        hashlib.sha256(physical(anchor_index).tobytes()).hexdigest()
        != parent["frame_sha256"][0]
    ):
        raise ValueError(
            "Original OM4 physical bytes differ from retained packed parent"
        )
    out = root / "missing"
    out.mkdir(exist_ok=False)
    physical_values = np.lib.format.open_memmap(
        out / "frames.npy",
        mode="w+",
        dtype="float32",
        shape=(len(indices), 77, 180, 360),
    )
    forcing_values = np.lib.format.open_memmap(
        out / "values.npy",
        mode="w+",
        dtype="float32",
        shape=(len(indices), 8, 180, 360),
    )
    bounds, physical_hashes, forcing_hashes = [], [], []
    for position, index in enumerate(indices):
        start, stop = [pd.Timestamp(str(x)) for x in reader.bounds[index]]
        if stop - start != pd.Timedelta(days=5):
            raise ValueError("Invalid source interval")
        physical_values[position] = physical(index)
        forcing_values[position] = strict_mean(
            np.stack([day(t) for t in pd.date_range(start, periods=5)])
        )
        physical_hashes.append(
            hashlib.sha256(physical_values[position].tobytes()).hexdigest()
        )
        forcing_hashes.append(
            hashlib.sha256(forcing_values[position].tobytes()).hexdigest()
        )
        bounds.append([start.isoformat(), stop.isoformat()])
        print(
            json.dumps(dict(position=position + 1, total=len(indices), index=index)),
            flush=True,
        )
    physical_values.flush()
    forcing_values.flush()
    del physical_values, forcing_values
    # Recompute every missing payload independently from source after disk write.
    physical_values = np.load(out / "frames.npy", mmap_mode="r")
    forcing_values = np.load(out / "values.npy", mmap_mode="r")
    for position, index in enumerate(indices):
        expected_physical = physical(index)
        expected_forcing = strict_mean(
            np.stack([day(t) for t in pd.date_range(bounds[position][0], periods=5)])
        )
        if (
            physical_values[position].tobytes() != expected_physical.tobytes()
            or forcing_values[position].tobytes() != expected_forcing.tobytes()
        ):
            raise ValueError("Missing source frame failed independent readback")
    np.save(out / "indices.npy", np.asarray(indices, dtype=np.int64))
    proof = dict(
        schema="stochastic-dense-missing-v1",
        indices=indices,
        bounds=bounds,
        sources=source_hashes,
        frame_sha256=physical_hashes,
        forcing_frame_sha256=forcing_hashes,
        source_metadata_sha256=parent["source_metadata_sha256"],
        source=str(source / "OM4.zarr"),
        parent_grid_sha256=digest(samples / "grid.npz"),
        original_builder_sha256=digest(
            original / "code/3952d46bc/scripts/prepare_shared_era5_intervals.py"
        ),
        builder_sha256=digest(__file__),
        all_frames_readback_exact=True,
        files={
            name: digest(out / name)
            for name in ("frames.npy", "values.npy", "indices.npy")
        },
    )
    (out / "COMPLETE.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps(dict(complete=True, missing_frames=len(indices))), flush=True)


if __name__ == "__main__":
    main()
