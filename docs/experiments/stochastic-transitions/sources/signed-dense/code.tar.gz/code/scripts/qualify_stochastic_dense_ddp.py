# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Qualify unchanged global batches under dense-cohort one/four-GPU execution."""

import argparse
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from run_stochastic_signed import training_command
from stochastic_campaign_cache import stage_caches


def command(paths, output, variant, world_size, *, resume=False, updates=2):
    base = training_command(paths, output, variant)
    base.remove("--resident-native-cache")
    base += [
        "--forcing-mode",
        "direct",
        "--om4-window-mode",
        "native-30day",
        "--checkpoint-every",
        "100",
        "--check-rank-sync",
        "--max-new-updates",
        str(updates),
    ]
    if resume:
        base += ["--resume"]
    if world_size > 1:
        base = [
            sys.executable,
            "-m",
            "torch.distributed.run",
            "--standalone",
            f"--nproc_per_node={world_size}",
            *base[1:],
        ]
    return base


def compare_checkpoints(reference_path, actual_path, *, exact=False, compare_rng=False):
    import numpy as np
    import torch

    reference = torch.load(reference_path, map_location="cpu", weights_only=False)
    actual = torch.load(actual_path, map_location="cpu", weights_only=False)
    for name in ("step", "counts", "contract"):
        if reference[name] != actual[name]:
            raise ValueError(f"Checkpoint {name} differs")
    maxima = {}

    def visit(a, b, path):
        if isinstance(a, torch.Tensor):
            if (
                not isinstance(b, torch.Tensor)
                or a.shape != b.shape
                or a.dtype != b.dtype
            ):
                raise ValueError(f"Tensor structure differs at {path}")
            if not torch.isfinite(a).all() or not torch.isfinite(b).all():
                raise ValueError(f"Nonfinite tensor at {path}")
            if exact or not a.is_floating_point():
                torch.testing.assert_close(a, b, rtol=0, atol=0, msg=path)
            else:
                torch.testing.assert_close(a, b, rtol=1e-4, atol=1e-6, msg=path)
            if a.numel():
                maxima[path.split(".")[0]] = max(
                    maxima.get(path.split(".")[0], 0),
                    float((a.double() - b.double()).abs().max()),
                )
        elif isinstance(a, np.ndarray):
            np.testing.assert_array_equal(a, b, err_msg=path)
        elif isinstance(a, dict):
            if a.keys() != b.keys():
                raise ValueError(f"Dictionary keys differ at {path}")
            for key in a:
                visit(a[key], b[key], f"{path}.{key}")
        elif isinstance(a, (tuple, list)):
            if len(a) != len(b):
                raise ValueError(f"Sequence lengths differ at {path}")
            for i, (x, y) in enumerate(zip(a, b, strict=True)):
                visit(x, y, f"{path}.{i}")
        elif a != b:
            raise ValueError(f"Value differs at {path}")

    for section in ("model", "ema", "optimizer"):
        visit(reference[section], actual[section], section)
    if compare_rng:
        visit(reference["rank_rng"], actual["rank_rng"], "rank_rng")
    return dict(
        compared_rng=compare_rng,
        reference=str(reference_path),
        actual=str(actual_path),
        step=actual["step"],
        exact=exact,
        maximum_absolute_difference=maxima,
    )


def compare_events(reference_path, actual_path):
    import numpy as np

    left = [json.loads(line) for line in reference_path.read_text().splitlines()][:2]
    right = [json.loads(line) for line in actual_path.read_text().splitlines()]
    if len(left) != 2 or len(right) != 2:
        raise ValueError("Need exactly the same next OBS and OM4 updates")
    for a, b in zip(left, right, strict=True):
        if any(a[k] != b[k] for k in ("step", "source", "counts", "lr")):
            raise ValueError("Update identities differ")
        keys = ["loss", "components", "grad_norm"] + [
            k
            for k in a
            if k.startswith(("velocity_init_signed_crps/", "velocity_init_variogram/"))
        ]
        for key in keys:
            np.testing.assert_allclose(
                a[key], b[key], rtol=1e-4, atol=1e-6, err_msg=key
            )
    return dict(passed=True, updates=[r["step"] for r in left])


def start_telemetry(path):
    hardware = json.loads(
        subprocess.check_output(
            [
                sys.executable,
                "-c",
                "import json,torch; print(json.dumps([dict(uuid=str(torch.cuda.get_device_properties(i).uuid),name=torch.cuda.get_device_properties(i).name,memory=torch.cuda.get_device_properties(i).total_memory) for i in range(torch.cuda.device_count())]))",
            ],
            text=True,
        )
    )
    path.with_suffix(".hardware.json").write_text(json.dumps(hardware, indent=2) + "\n")
    identities = {item["uuid"].removeprefix("GPU-").lower() for item in hardware}
    stop, failures = threading.Event(), []

    def worker():
        try:
            with path.open("w") as stream:
                while not stop.is_set():
                    try:
                        output = subprocess.check_output(
                            [
                                "nvidia-smi",
                                "--query-gpu=uuid,utilization.gpu,memory.used",
                                "--format=csv,noheader,nounits",
                            ],
                            text=True,
                            timeout=15,
                        )
                        rows = [line.split(",") for line in output.splitlines()]
                        samples = [
                            dict(
                                time=time.time(),
                                uuid=row[0].strip(),
                                utilization=float(row[1]),
                                memory_mib=float(row[2]),
                            )
                            for row in rows
                            if row[0].strip().removeprefix("GPU-").lower() in identities
                        ]
                        if len(samples) != len(identities):
                            raise RuntimeError(
                                "Allocated GPU telemetry identities differ"
                            )
                    except (
                        subprocess.TimeoutExpired,
                        subprocess.CalledProcessError,
                    ) as error:
                        samples = [dict(time=time.time(), telemetry_error=repr(error))]
                    for sample in samples:
                        stream.write(json.dumps(sample) + "\n")
                    stream.flush()
                    stop.wait(1)
        except Exception as error:
            failures.append(repr(error))

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    return stop, thread, failures


_RUN_TIMINGS = []


def run_training(arguments, **kwargs):
    started = time.time()
    result = subprocess.run(arguments, **kwargs)
    finished = time.time()
    output = Path(arguments[arguments.index("--output") + 1])
    rows = [
        json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()
    ]
    current = [row for row in rows if row["update_started_unix"] >= started]
    if not current:
        raise ValueError("Training call produced no measured updates")
    _RUN_TIMINGS.append(
        dict(
            output=str(output),
            started_unix=started,
            finished_unix=finished,
            first_step=current[0]["step"],
            last_step=current[-1]["step"],
            startup_seconds=current[0]["update_started_unix"] - started,
            update_span_seconds=current[-1]["update_finished_unix"]
            - current[0]["update_started_unix"],
            checkpoint_and_shutdown_seconds=finished
            - current[-1]["update_finished_unix"],
            elapsed_seconds=finished - started,
        )
    )
    return result


def run(args):
    paths = json.loads((args.root / "paths.json").read_text())
    staging_started = time.monotonic()
    stage_caches(args.root, paths)
    staging_seconds = time.monotonic() - staging_started
    out = args.root / args.variant
    out.mkdir(parents=True, exist_ok=True)
    if args.stage == "reference":
        destination = out / "reference1"
        if destination.exists():
            raise ValueError("Refuse to overwrite qualification reference")
        run_training(
            command(paths, destination, args.variant, 1, updates=2),
            check=True,
        )
        os.link(destination / "last.pt", destination / "pair.pt")
        run_training(
            command(
                paths,
                destination,
                args.variant,
                1,
                resume=True,
                updates=20,
            ),
            check=True,
        )
        receipt = dict(
            complete=True,
            fresh=True,
            forcing_mode="direct",
            source=os.environ["SAMUDRA_CODE_COMMIT"],
        )
        receipt.update(staging_seconds=staging_seconds, training_calls=_RUN_TIMINGS)
        return out / "REFERENCE.json", receipt
    reference_hardware = json.loads(
        (args.root / "gpu-reference.hardware.json").read_text()
    )
    distributed_hardware = json.loads(
        (args.root / "gpu-distributed.hardware.json").read_text()
    )
    if (
        len(reference_hardware) != 1
        or len(distributed_hardware) != 4
        or {x["name"] for x in reference_hardware}
        != {x["name"] for x in distributed_hardware}
    ):
        raise ValueError("One/four-GPU qualification must use the same GPU type")
    if not (out / "REFERENCE.json").exists():
        raise ValueError("One-GPU reference must finish first")
    destination, uninterrupted = out / "distributed4", out / "uninterrupted4"
    if destination.exists() or uninterrupted.exists():
        raise ValueError("Existing qualification requires explicit recovery review")
    run_training(command(paths, destination, args.variant, 4), check=True)
    initialization = compare_checkpoints(
        out / "reference1/step-00000.pt", destination / "step-00000.pt", exact=True
    )
    comparable = compare_checkpoints(
        out / "reference1/pair.pt", destination / "last.pt"
    )
    events = compare_events(
        out / "reference1/events.jsonl", destination / "events.jsonl"
    )
    run_training(
        command(paths, destination, args.variant, 4, resume=True, updates=1),
        check=True,
    )
    run_training(
        command(paths, uninterrupted, args.variant, 4, updates=3),
        check=True,
    )
    restart = compare_checkpoints(
        uninterrupted / "last.pt", destination / "last.pt", exact=True, compare_rng=True
    )
    run_training(
        command(
            paths,
            destination,
            args.variant,
            4,
            resume=True,
            updates=19,
        ),
        check=True,
    )
    rows = [
        json.loads(line)
        for line in (destination / "events.jsonl").read_text().splitlines()
    ]
    warm = rows[3:]
    reference = [
        json.loads(line)
        for line in (out / "reference1/events.jsonl").read_text().splitlines()
    ]
    seconds = {
        source: sum(r["seconds"] for r in warm if r["source"] == source)
        / sum(r["source"] == source for r in warm)
        for source in ("om4", "observation")
    }
    state = json.loads((destination / "state.json").read_text())
    if state["step"] != 22 or state["rank_disagreement"] != 0:
        raise ValueError("Distributed final counts/rank agreement failed")
    samples = [
        json.loads(line)
        for line in (args.root / f"gpu-{args.stage}.jsonl").read_text().splitlines()
    ]
    active = [
        s
        for s in samples
        if "utilization" in s
        and any(
            r["update_started_unix"] <= s["time"] <= r["update_finished_unix"]
            for r in warm
        )
    ]
    gpu_utilization = {
        identity: sum(s["utilization"] for s in active if s["uuid"] == identity)
        / sum(s["uuid"] == identity for s in active)
        for identity in {s["uuid"] for s in active}
    }
    if len(gpu_utilization) != 4 or min(gpu_utilization.values()) <= 50:
        raise ValueError(
            f"Warm utilization must exceed 50% on all four GPUs: {gpu_utilization}"
        )
    result = dict(
        complete=True,
        warm_gpu_utilization_percent=gpu_utilization,
        source=os.environ["SAMUDRA_CODE_COMMIT"],
        initialization=initialization,
        one_vs_four=comparable,
        event_comparison=events,
        resumed_vs_uninterrupted=restart,
        final_state=state,
        warm_update_seconds=seconds,
        reference_update_seconds={
            source: sum(r["seconds"] for r in reference[2:] if r["source"] == source)
            / sum(r["source"] == source for r in reference[2:])
            for source in ("om4", "observation")
        },
        warm_max_data_wait_seconds=max(r["data_wait_seconds"] for r in warm),
        warm_mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm)
        / len(warm),
        peak_rank_rss_kib=max(r["max_rank_rss_kib"] for r in rows),
        peak_allocated_bytes=max(r["peak_allocated_bytes"] for r in rows),
    )
    result.update(staging_seconds=staging_seconds, training_calls=_RUN_TIMINGS)
    return out / "QUALIFIED.json", result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument(
        "--variant",
        choices=("B-shared-deep-wide-signed", "B-shared-deep-wide-weak-variogram"),
        required=True,
    )
    parser.add_argument("--stage", choices=("reference", "distributed"), required=True)
    args = parser.parse_args()
    args.root.mkdir(parents=True, exist_ok=True)
    stop, worker, failures = start_telemetry(args.root / f"gpu-{args.stage}.jsonl")
    try:
        receipt_path, receipt = run(args)
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or failures:
        raise RuntimeError(f"GPU telemetry failed: {failures}")
    receipt["telemetry_finalized"] = True
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)
