# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Resume a qualified fresh direct-forcing run inside an explicit GPU-hour release."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

from qualify_stochastic_dense_ddp import command, start_telemetry
from stochastic_campaign_cache import stage_caches
from stochastic_campaign_release import validate_release


def production_command(paths, output, variant, world_size, wall_minutes):
    return command(paths, output, variant, world_size, resume=True, updates=7978) + [
        "--checkpoint-every",
        "500",
        "--hours",
        str(wall_minutes / 60),
    ]


def prepare_checkpoint(qualified, output, source, world_size, pins):
    import torch

    if output.exists():
        raise ValueError("Existing production output requires explicit resume review")
    saved = torch.load(qualified / "last.pt", map_location="cpu", weights_only=False)
    if saved["step"] != 22 or saved["counts"] != {"om4": 11, "observation": 11}:
        raise ValueError("Qualification exposure changed")
    contract = saved["contract"]
    if (
        contract.get("producer") != source
        or contract.get("forcing_mode") != "direct"
        or contract.get("main_updates") != 8000
        or len(saved["rank_rng"]) != world_size
    ):
        raise ValueError(
            "Qualification architecture, schedule, producer or world size changed"
        )
    expected = dict(
        arm="B",
        objective="fair-crps",
        effective_batch=8,
        training_members=4,
        cooldown_updates=0,
        om4_window_mode="native-30day",
        replay=False,
        learning_rate=1e-4,
        velocity_init_signed_crps_weight=1.0,
        widths=[64, 128, 256],
        initializer_widths=[96, 192, 384],
        initializer_blocks=3,
        seed=1729,
    )
    if (
        any(contract.get(k) != v for k, v in expected.items())
        or contract.get("velocity_init_variogram_weight", 0) != 0
    ):
        raise ValueError("Qualification scientific configuration differs")
    if contract.get("om4_cohort", {}).get("window_count") != 2548:
        raise ValueError("Expected verified dense OM4 cohort")
    output.mkdir(parents=True)
    shutil.copyfile(qualified / "last.pt", output / "last.pt")
    shutil.copyfile(qualified / "execution.json", output / "execution.json")
    for name in ("last.pt", "execution.json"):
        with (output / name).open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != pins[name]:
                raise ValueError(f"Copied qualification {name} differs from pin")
    (output / "QUALIFICATION_PARENT.json").write_text(
        json.dumps(
            dict(
                checkpoint=str(qualified / "last.pt"),
                included_updates=22,
                fresh_initialization=True,
                producer=source,
                world_size=world_size,
            ),
            indent=2,
        )
        + "\n"
    )


def run(args):
    release = json.loads((args.root / "PRODUCTION_RELEASE.json").read_text())
    source = os.environ["SAMUDRA_CODE_COMMIT"]
    world_size = int(os.environ["CAMPAIGN_WORLD_SIZE"])
    validate_release(
        release, source, world_size, int(os.environ["CAMPAIGN_WALL_MINUTES"]), args.root
    )
    qualified_root = args.root / args.variant
    result = json.loads((qualified_root / "QUALIFIED.json").read_text())
    if not result["complete"] or result["source"] != source:
        raise ValueError("Direct-forcing DDP qualification is incomplete or stale")
    qualified = qualified_root / ("reference1" if world_size == 1 else "distributed4")
    output = args.root / "production" / args.variant
    prepare_checkpoint(
        qualified,
        output,
        source,
        world_size,
        {
            name: release["pins"][str((qualified / name).relative_to(args.root))]
            for name in ("last.pt", "execution.json")
        },
    )
    paths = json.loads((args.root / "paths.json").read_text())
    stage_caches(args.root, paths)
    stop, worker, failures = start_telemetry(output / "gpu-production.jsonl")
    try:
        subprocess.run(
            production_command(
                paths,
                output,
                args.variant,
                world_size,
                int(os.environ["CAMPAIGN_WALL_MINUTES"]),
            ),
            check=True,
        )
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or failures:
        raise RuntimeError(f"Production telemetry failed: {failures}")
    state = json.loads((output / "COMPLETE.json").read_text())
    if state != {
        "step": 8000,
        "counts": {"om4": 4000, "observation": 4000},
        "complete": True,
    }:
        raise ValueError("Production did not reach the authorized mixed exposure")
    print(
        json.dumps(
            dict(training_complete=state, evaluation="separate single-GPU allocation")
        ),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument(
        "--variant", choices=["B-shared-deep-wide-signed"], required=True
    )
    run(parser.parse_args())
