# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""CPU-only reconciliation of a pinned stochastic campaign production release."""

import argparse
import hashlib
import json
import math
import os
import re
import subprocess
from pathlib import Path

SHORT_GPU_HOURS = 6.486666666666666
VARIANT = "B-shared-deep-wide-signed"


def finite(value, name, *, minimum=0):
    if type(value) not in (int, float) or not math.isfinite(value) or value < minimum:
        raise ValueError(f"Invalid {name}: require finite value >= {minimum}")
    return value


def positive_integer(value, name):
    if type(value) is not int or value <= 0:
        raise ValueError(f"Invalid {name}: require positive integer")
    return value


def job_id(value):
    value = str(value)
    if not re.fullmatch(r"[0-9]+", value):
        raise ValueError("Invalid Slurm job ID")
    return value


def slurm_fields(raw):
    lines = [line for line in raw.splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("Require exactly one Slurm job record")
    return dict(re.findall(r"(?:^|\s)([A-Za-z][A-Za-z0-9_]*)=(\S+)", raw))


def allocated_gpus(fields):
    entries = {}
    for item in fields.get("AllocTRES", "").split(","):
        if "=" in item:
            key, value = item.split("=", 1)
            if key in entries:
                raise ValueError("Duplicate AllocTRES entry")
            entries[key] = value
    try:
        generic = int(entries["gres/gpu"]) if "gres/gpu" in entries else None
        typed = [int(v) for k, v in entries.items() if k.startswith("gres/gpu:")]
    except ValueError as error:
        raise ValueError("Invalid allocated GPU count") from error
    if typed and (min(typed) <= 0 or generic not in (None, sum(typed))):
        raise ValueError("Inconsistent allocated GPU counts")
    return positive_integer(generic if generic is not None else sum(typed), "GPUs")


def time_limit_seconds(value):
    match = re.fullmatch(r"(?:(\d+)-)?(\d+):(\d{2}):(\d{2})", value)
    if match is None:
        raise ValueError("Invalid finite Slurm TimeLimit")
    days, hours, minutes, seconds = (int(v or 0) for v in match.groups())
    if minutes >= 60 or seconds >= 60 or (match[1] is not None and hours >= 24):
        raise ValueError("Invalid Slurm TimeLimit fields")
    return positive_integer(
        days * 86400 + hours * 3600 + minutes * 60 + seconds, "TimeLimit"
    )


def write_allocation_receipt(root, job):
    """Capture the scheduler's actual allocation before entering the container."""
    job = job_id(job)
    raw = subprocess.check_output(
        ["scontrol", "show", "job", "-o", job], text=True, timeout=30
    )
    fields = slurm_fields(raw)
    if fields.get("JobId") != job:
        raise ValueError("Slurm returned a different job")
    allocated_gpus(fields)
    time_limit_seconds(fields["TimeLimit"])
    receipt = dict(job_id=job, raw=raw, fields=fields)
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    destination = root / f"allocation-{job}.json"
    temporary = destination.with_suffix(".tmp")
    temporary.write_text(json.dumps(receipt, indent=2) + "\n")
    temporary.replace(destination)
    return receipt


def checked_path(root, relative):
    path = Path(relative)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"Invalid pinned relative path: {relative}")
    result = Path(root) / path
    if (
        not result.resolve().is_relative_to(Path(root).resolve())
        or not result.is_file()
    ):
        raise ValueError(f"Missing or escaping pinned file: {relative}")
    return result


def verify_digest(root, relative, expected):
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError(f"Invalid SHA256 for {relative}")
    with checked_path(root, relative).open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != expected:
        raise ValueError(f"SHA256 differs: {relative}")


def validate_release(release, source, world_size, wall_minutes, root):
    """Fail closed before staging data or resuming the qualified checkpoint."""
    root = Path(root)
    positive_integer(world_size, "world size")
    positive_integer(wall_minutes, "wall minutes")
    if (
        world_size not in (1, 4)
        or release["source"] != source
        or release["target_updates"] != 8000
        or release["world_size"] != world_size
        or release["wall_minutes"] != wall_minutes
    ):
        raise ValueError("Production source, allocation or update budget differs")
    if release["short_gpu_hours"] != SHORT_GPU_HOURS:
        raise ValueError("Actual short-stage GPU-hour ledger differs")
    allocations = release["qualification_allocations"]
    if not isinstance(allocations, list) or not allocations:
        raise ValueError("Require actual qualification allocations")
    jobs, qualification = set(), 0.0
    for allocation in allocations:
        job = job_id(allocation["job_id"])
        if job in jobs:
            raise ValueError("Duplicate qualification job")
        jobs.add(job)
        qualification += (
            positive_integer(allocation["gpus"], "qualification GPUs")
            * finite(allocation["elapsed_seconds"], "qualification elapsed seconds")
            / 3600
        )
    if not math.isfinite(qualification) or qualification > 2.25:
        raise ValueError("Qualification exceeds 2.25 GPU-hours")
    prior = finite(release["prior_allocated_gpu_hours"], "prior GPU-hours")
    if not math.isclose(
        prior, SHORT_GPU_HOURS + qualification, rel_tol=0, abs_tol=1e-10
    ):
        raise ValueError("Prior GPU-hours do not reconcile with actual jobs")
    reserve = finite(
        release["diagnostic_reserve_gpu_hours"], "diagnostic reserve", minimum=4
    )
    total = prior + world_size * wall_minutes / 60 + reserve
    maximum = finite(release["maximum_total_gpu_hours"], "maximum GPU-hours")
    if (
        total > 40
        or maximum > 40
        or not math.isclose(total, maximum, rel_tol=0, abs_tol=1e-10)
    ):
        raise ValueError(
            "Production allocation exceeds or differs from 40 GPU-hour ledger"
        )

    runtime = release["runtime"]
    rate = finite(runtime["update_seconds"], "update seconds")
    if rate == 0 or runtime["remaining_updates"] != 7978:
        raise ValueError("Require measured rate and exactly 7978 remaining updates")
    factor = finite(
        runtime["training_safety_factor"], "training safety factor", minimum=1.05
    )
    startup = finite(runtime["startup_seconds"], "startup seconds")
    checkpoint = finite(runtime["checkpoint_seconds"], "checkpoint seconds")
    count = positive_integer(runtime["remaining_checkpoint_count"], "checkpoint count")
    if count < 16:
        raise ValueError("Require at least 16 remaining checkpoints")
    projected = 7978 * rate * factor + startup + count * checkpoint
    if not math.isfinite(projected) or projected > wall_minutes * 60:
        raise ValueError(
            "Measured training, startup and checkpoint projection does not fit"
        )

    current_job = job_id(os.environ["SLURM_JOB_ID"])
    if current_job in jobs:
        raise ValueError("Production job already counted as qualification")
    receipt = json.loads((root / f"allocation-{current_job}.json").read_text())
    fields = slurm_fields(receipt["raw"])
    if (
        receipt["job_id"] != current_job
        or fields.get("JobId") != current_job
        or receipt["fields"] != fields
        or allocated_gpus(fields) != world_size
        or time_limit_seconds(fields["TimeLimit"]) != wall_minutes * 60
    ):
        raise ValueError("Actual Slurm allocation differs from release")

    qualified = f"{VARIANT}/{'reference1' if world_size == 1 else 'distributed4'}"
    required = {
        "SOURCE.json",
        f"{VARIANT}/QUALIFIED.json",
        f"{qualified}/last.pt",
        f"{qualified}/execution.json",
    }
    pins = release["pins"]
    if not isinstance(pins, dict) or not required <= pins.keys():
        raise ValueError("Missing required qualification/source pins")
    for relative, expected in pins.items():
        verify_digest(root, relative, expected)
    manifest = json.loads((root / "SOURCE.json").read_text())
    manifest_sha = hashlib.sha256(
        json.dumps(manifest["files"], sort_keys=True).encode()
    ).hexdigest()
    if manifest["sha256"] != source or manifest_sha != source or not manifest["files"]:
        raise ValueError("Source manifest identity differs")
    for relative, expected in manifest["files"].items():
        verify_digest(root / "code", relative, expected)
    return dict(
        qualification_gpu_hours=qualification,
        maximum_total_gpu_hours=total,
        projected_total_seconds=projected,
        allocation=receipt,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--job", required=True)
    args = parser.parse_args()
    print(json.dumps(write_allocation_receipt(args.root, args.job)), flush=True)
