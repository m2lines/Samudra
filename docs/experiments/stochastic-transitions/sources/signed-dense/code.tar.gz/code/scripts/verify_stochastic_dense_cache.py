# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Exercise the actual dense-cache loader and provenance checks on CPU."""

import argparse
import copy
import hashlib
import json
from pathlib import Path

import torch

from samudra.experiments.monthly_model_data import ModelMonths
from samudra.experiments.observation_training import Samples
from samudra.experiments.shared_era5 import SharedEra5
from samudra.experiments.stochastic_om4_windows import build_five_day_om4_windows
from samudra.experiments.stochastic_transition_data import CompactNativeLoader
from samudra.experiments.stochastic_transition_train import (
    configure_dense_om4_windows,
    verify_dense_cache_extensions,
)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--samples", type=Path, required=True)
    parser.add_argument("--om4", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    data = Samples(
        args.samples, torch.device("cpu"), surface_fill="zero", global_observations=True
    )
    packed, forcing_root = args.root / "packed-om4", args.root / "forcing-cache"
    reader = ModelMonths(
        args.om4 / "OM4.zarr", "om4", data.grid, args.om4, packed=packed
    )
    windows, cohort = build_five_day_om4_windows(reader)
    proof_sha = digest(forcing_root / "COMPLETE.json")
    extension = verify_dense_cache_extensions(packed, forcing_root, cohort, proof_sha)
    print(json.dumps(dict(stage="extension-lineage-verified")), flush=True)
    forcing_reader = copy.copy(reader)
    forcing_reader.windows = windows
    forcing = SharedEra5(
        forcing_root, forcing_reader, data, proof_sha, full_readback=True
    )
    configured = configure_dense_om4_windows(reader, forcing, built=(windows, cohort))
    loader = CompactNativeLoader(reader, forcing, data, resident=False)
    # Select first/last plus origins whose latest initial field uses a newly added frame.
    parent_proof = json.loads((packed / "COMPLETE.json").read_text())["extension"]
    parent = json.loads(
        (Path(parent_proof["parent_cache"]) / "COMPLETE.json").read_text()
    )
    added = set(cohort["required_frame_indices"]) - set(parent["indices"])
    selected = {0, len(windows) - 1}
    covered = set()
    for index in sorted(added):
        if index in covered:
            continue
        candidates = [
            i
            for i, (start, stop, _, _) in enumerate(windows)
            if start - 19 <= index < stop
        ]
        if not candidates:
            raise ValueError("Added frame is not consumed by any dense window")
        chosen = max(
            candidates,
            key=lambda i: len(
                added.intersection(range(windows[i][0] - 19, windows[i][1])) - covered
            ),
        )
        selected.add(chosen)
        covered.update(
            added.intersection(range(windows[chosen][0] - 19, windows[chosen][1]))
        )
    if covered != added:
        raise ValueError("Actual loader checks do not cover every added frame")
    selected = sorted(selected)
    checks = []
    for index in selected:
        sample = loader(index)
        if (
            sample["targets"].shape[1] != 6
            or sample["surface"].shape[1] != 25
            or sample["duration"] != 30
        ):
            raise ValueError("Actual dense loader history/forecast shape differs")
        if sample["atmosphere"].shape[1:3] != (25, 8):
            raise ValueError("Actual dense forcing alignment differs")
        for key in (
            "surface",
            "targets",
            "initial_target",
            "atmosphere",
            "contexts",
            "weights",
        ):
            if not torch.isfinite(sample[key]).all():
                raise ValueError(f"Actual dense loader produced nonfinite {key}")
        if not torch.allclose(sample["weights"], torch.full((6,), 1 / 6)):
            raise ValueError("Actual dense weights differ")
        checks.append(
            dict(window=index, start=windows[index][0], first=sample["first"])
        )
        del sample
    result = dict(
        complete=True,
        device="cpu",
        cohort=configured,
        extension=extension,
        sampled_windows=checks,
        sampled_window_count=len(checks),
        added_frames_exercised=len(covered),
        packed_proof_sha256=digest(packed / "COMPLETE.json"),
        forcing_proof_sha256=proof_sha,
        verifier_sha256=digest(__file__),
    )
    (args.root / "VERIFIED.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                complete=True,
                windows=len(windows),
                required_frames=cohort["required_frame_count"],
                sampled_windows=len(checks),
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
