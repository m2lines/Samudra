# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Dense OM4 forecast origins inside an existing training cohort's date bounds."""

import hashlib
import json

import numpy as np

HISTORY_BINS = 19
TARGET_BINS = 6
BIN_SECONDS = 5 * 86400


def _digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def required_frame_indices(windows):
    """All source frames consumed by history, reconstruction and forecast."""
    return sorted(
        {
            index
            for start, stop, _, _ in windows
            for index in range(start - HISTORY_BINS, stop)
        }
    )


def build_five_day_om4_windows(reader):
    """Return 30-day windows and provenance without changing the input reader.

    The existing calendar-month cohort defines the permitted earliest history
    and latest target interval. Every native origin within that envelope is
    eligible, provided all 25 consumed bins are contiguous. Cache coverage is
    deliberately not used to select examples: callers must verify the returned
    required indices against both packed OM4 and ERA5 before using these windows.
    """
    if reader.kind != "om4":
        raise ValueError("Five-day origin sampling is restricted to OM4")
    bounds = np.asarray(reader.bounds, dtype=object)
    if bounds.ndim != 2 or bounds.shape[1] != 2 or not len(bounds):
        raise ValueError("Require nonempty source interval bounds with shape N,2")
    for first, last in bounds:
        if (last - first).total_seconds() != BIN_SECONDS:
            raise ValueError("Require five-day source intervals")
    if any(bounds[i + 1, 0] < bounds[i, 1] for i in range(len(bounds) - 1)):
        raise ValueError("Source intervals overlap or are not ordered")
    if not reader.windows:
        raise ValueError("Require the original calendar-month training cohort")
    original = []
    for start, stop, weights, duration in reader.windows:
        if (
            not isinstance(start, (int, np.integer))
            or not isinstance(stop, (int, np.integer))
            or start < HISTORY_BINS
            or stop <= start
            or stop > len(bounds)
            or len(weights) != stop - start
            or duration <= 0
        ):
            raise ValueError("Invalid original training window")
        original.append(
            [int(start), int(stop), [float(w) for w in weights], float(duration)]
        )
    first_history = min(w[0] - HISTORY_BINS for w in original)
    last_target_stop = max(w[1] for w in original)
    gaps = bounds[1:, 0] != bounds[:-1, 1]
    windows = []
    candidate_count = cutoff_count = gap_count = 0
    for start in range(HISTORY_BINS, len(bounds) - TARGET_BINS + 1):
        candidate_count += 1
        stop = start + TARGET_BINS
        if start - HISTORY_BINS < first_history or stop > last_target_stop:
            cutoff_count += 1
            continue
        if gaps[start - HISTORY_BINS : stop - 1].any():
            gap_count += 1
            continue
        windows.append((start, stop, [1.0 / TARGET_BINS] * TARGET_BINS, 30))
    if not windows:
        raise ValueError("No contiguous 30-day windows inside original training bounds")
    indices = required_frame_indices(windows)
    source_intervals = [[i, str(bounds[i, 0]), str(bounds[i, 1])] for i in indices]
    receipt = dict(
        schema="om4-five-day-origins-v1",
        original_window_count=len(original),
        history_bins=HISTORY_BINS,
        target_bins=TARGET_BINS,
        target_duration_days=30,
        stride_bins=1,
        source_candidate_count=candidate_count,
        excluded_cutoff_count=cutoff_count,
        excluded_gap_count=gap_count,
        window_count=len(windows),
        earliest_permitted_history_index=first_history,
        latest_permitted_target_stop=last_target_stop,
        earliest_permitted_history_time=str(bounds[first_history, 0]),
        latest_permitted_target_end=str(bounds[last_target_stop - 1, 1]),
        first_origin_index=windows[0][0],
        last_origin_index=windows[-1][0],
        first_forecast_interval_start=str(bounds[windows[0][0], 0]),
        last_forecast_interval_start=str(bounds[windows[-1][0], 0]),
        required_frame_count=len(indices),
        required_frame_indices=indices,
        original_windows_sha256=_digest(original),
        windows_sha256=_digest(windows),
        required_source_intervals_sha256=_digest(source_intervals),
    )
    return windows, receipt
