# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Matched one-pass stochastic transition comparison, without replay or pretraining."""

import argparse
import copy
import json
import math
import os
import random
import resource
import signal
import time
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from samudra.experiments.observation_pilot import atomic_json, atomic_torch, digest
from samudra.experiments.physical_state_train import update_ema
from samudra.experiments.task_schedule import sample_indices


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "om4", "packed-om4", "shared-era5", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--shared-era5-proof-sha256", required=True)
    p.add_argument("--reference", type=Path)
    p.add_argument("--fork-checkpoint", type=Path)
    p.add_argument("--continue-checkpoint", type=Path)
    p.add_argument(
        "--forcing-mode", choices=("bottleneck", "direct"), default="bottleneck"
    )
    p.add_argument(
        "--om4-window-mode",
        choices=("calendar-month", "native-30day"),
        default="calendar-month",
    )
    p.add_argument("--velocity-init-mean-mse-weight", type=float, default=0.0)
    p.add_argument("--velocity-init-mean-mse-debias", action="store_true")
    p.add_argument("--velocity-init-crps-multiplier", type=float, default=1.0)
    p.add_argument("--velocity-init-variogram-weight", type=float, default=0.0)
    p.add_argument(
        "--velocity-init-variogram-lags", type=int, nargs="+", default=[1, 2, 4, 8]
    )
    p.add_argument("--velocity-init-signed-crps-weight", type=float, default=0.0)
    p.add_argument(
        "--velocity-init-signed-crps-lags", type=int, nargs="+", default=[1, 2, 4, 8]
    )
    p.add_argument("--arm", choices=list("ABC"), required=True)
    p.add_argument(
        "--objective",
        choices=("mae", "member-mse", "fair-crps", "multiscale-fair-crps"),
    )
    p.add_argument("--ensemble-mean-mse-weight", type=float, default=0.0)
    p.add_argument(
        "--training-mode", choices=("joint", "initializer-only"), default="joint"
    )
    p.add_argument("--multiscale-sigmas", default="1,2,4,8")
    p.add_argument("--multiscale-weights", default="1,1,1,1,1")
    p.add_argument("--main-updates", type=int, default=4000)
    p.add_argument("--cooldown-updates", type=int, default=1000)
    p.add_argument("--effective-batch", type=int, default=8)
    p.add_argument("--microbatch", type=int, default=1)
    p.add_argument("--members", type=int, default=4)
    p.add_argument("--widths", type=int, nargs="+", default=[64, 128, 256])
    p.add_argument("--initializer-widths", type=int, nargs="+")
    p.add_argument("--initializer-blocks", type=int, default=1)
    p.add_argument("--noise-mode", choices=("iid", "multiscale"), default="iid")
    p.add_argument("--noise-processing-blocks", type=int, choices=(0, 3), default=0)
    p.add_argument(
        "--noise-architecture",
        default="legacy",
        choices=(
            "legacy",
            "joint_coarse",
            "joint_multires",
            "gan_fullgrid",
            "shared_input",
        ),
    )
    p.add_argument("--conditional-gan", action="store_true")
    p.add_argument("--gan-critic-updates", type=int, default=5)
    p.add_argument("--seed", type=int, default=1729)
    p.add_argument("--checkpoint-every", type=int, default=500)
    p.add_argument("--max-new-updates", type=int)
    p.add_argument("--hours", type=float, default=46)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--allow-world-size-migration", action="store_true")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--fused-adam", action="store_true")
    p.add_argument("--resident-native-cache", action="store_true")
    p.add_argument("--compile", action="store_true")
    p.add_argument("--activation-checkpointing", action="store_true")
    p.add_argument("--check-rank-sync", action="store_true")
    p.add_argument("--prefetch-workers", type=int, default=4)
    p.add_argument("--prefetch-updates", type=int, default=4)
    p.add_argument("--obs-cache-size", type=int, default=64)
    p.add_argument("--wandb-project", default="observational-transfer")
    p.add_argument("--wandb-entity", default="ocean_emulators")
    return p


def counts(step, contract):
    main = min(step, contract["main_updates"])
    return dict(om4=main // 2, observation=(main + 1) // 2 + step - main)


def phase(step, contract):
    main, cool = contract["main_updates"], contract["cooldown_updates"]
    if not 0 <= step < main + cool:
        raise ValueError("Update outside contract")
    if step < main:
        return "observation" if step % 2 == 0 else "om4", 1e-4
    return "observation", 1e-4 + (1e-6 - 1e-4) * (step - main + 1) / cool


def canonical_contract(contract):
    """Upgrade only missing loss metadata from pre-ablation checkpoints."""
    result = dict(contract)
    result.setdefault(
        "objective", "member-mse" if contract["arm"] == "A" else "fair-crps"
    )
    result.setdefault("ensemble_mean_mse_weight", 0.0)
    return result


def contracts_match(saved, requested):
    return canonical_contract(saved) == canonical_contract(requested)


def configuration(args):
    if args.main_updates <= 0 or args.main_updates % 2 or args.cooldown_updates < 0:
        raise ValueError("Require positive even main length and nonnegative cooldown")
    if (
        min(
            args.effective_batch,
            args.microbatch,
            args.checkpoint_every,
            args.prefetch_workers,
            args.prefetch_updates,
            args.obs_cache_size,
        )
        < 1
        or args.members < 2
    ):
        raise ValueError("Invalid batch/checkpoint/worker/member count")
    if args.hours <= 0 or (
        args.max_new_updates is not None and args.max_new_updates < 1
    ):
        raise ValueError("Invalid runtime limit")
    objective = getattr(args, "objective", None) or (
        "member-mse" if args.arm == "A" else "fair-crps"
    )
    auxiliary = getattr(args, "ensemble_mean_mse_weight", 0.0)
    if objective not in ("mae", "member-mse", "fair-crps", "multiscale-fair-crps"):
        raise ValueError("Unknown objective")
    if not math.isfinite(auxiliary) or auxiliary < 0:
        raise ValueError("Auxiliary MSE weight must be finite and nonnegative")
    if auxiliary and objective != "fair-crps":
        raise ValueError("Auxiliary ensemble mean MSE requires fair CRPS")
    if objective == "fair-crps" and args.arm == "A":
        raise ValueError(
            "Fair CRPS requires a stochastic architecture with multiple members"
        )
    mode = getattr(args, "training_mode", "joint")
    if mode not in ("joint", "initializer-only"):
        raise ValueError("Unknown training mode")
    velocity_aux = getattr(args, "velocity_init_mean_mse_weight", 0.0)
    velocity_multiplier = getattr(args, "velocity_init_crps_multiplier", 1.0)
    if (
        not math.isfinite(velocity_aux)
        or velocity_aux < 0
        or not math.isfinite(velocity_multiplier)
        or velocity_multiplier <= 0
    ):
        raise ValueError("Invalid velocity initializer weights")
    velocity_options = {}
    variogram_weight = getattr(args, "velocity_init_variogram_weight", 0.0)
    if not math.isfinite(variogram_weight) or variogram_weight < 0:
        raise ValueError("Variogram weight must be finite and nonnegative")
    if variogram_weight:
        from .stochastic_variogram import validate_lags

        if objective != "fair-crps" or mode != "joint":
            raise ValueError("Variogram intervention requires joint fair CRPS")
        lags = list(
            validate_lags(getattr(args, "velocity_init_variogram_lags", [1, 2, 4, 8]))
        )
        velocity_options.update(
            velocity_init_variogram_weight=variogram_weight,
            velocity_init_variogram_lags=lags,
            velocity_init_variogram=dict(
                scope="OM4 latest initializer state only; all uo/vo depths",
                order=1,
                estimator="fair finite-ensemble: plugin minus unbiased variance/M",
                directions=["E", "N", "NE", "NW"],
                path_mask="all traversed cells wet and target-finite; periodic longitude, bounded latitude",
                aggregation="endpoint-mean area weights; equal supported channels, directions and lags",
                normalization="fixed OM4 per-channel mean/std",
                outer_reconstruction_weight=0.1,
            ),
        )
    signed_weight = getattr(args, "velocity_init_signed_crps_weight", 0.0)
    if not math.isfinite(signed_weight) or signed_weight < 0:
        raise ValueError("Signed-increment CRPS weight must be finite and nonnegative")
    if signed_weight:
        from .stochastic_variogram import validate_lags

        if objective != "fair-crps" or mode != "joint" or args.arm != "B":
            raise ValueError("Signed-increment intervention requires joint B fair CRPS")
        lags = list(
            validate_lags(getattr(args, "velocity_init_signed_crps_lags", [1, 2, 4, 8]))
        )
        velocity_options.update(
            velocity_init_signed_crps_weight=signed_weight,
            velocity_init_signed_crps_lags=lags,
            velocity_init_signed_crps=dict(
                scope="OM4 latest initializer state only; all uo/vo depths",
                estimator="fair CRPS of signed spatial increments",
                increment_orientation="start minus offset endpoint",
                directions=["E", "N", "NE", "NW"],
                path_mask="all traversed cells wet and target-finite; periodic longitude, bounded latitude",
                aggregation="endpoint-mean area weights; equal supported channels, directions and lags",
                normalization="fixed OM4 per-channel mean/std",
                outer_reconstruction_weight=0.1,
            ),
        )
    if velocity_aux != 0 or velocity_multiplier != 1:
        if objective != "fair-crps" or mode != "joint":
            raise ValueError("Velocity intervention requires joint fair CRPS")
        velocity_options.update(
            velocity_init_mean_mse_weight=velocity_aux,
            velocity_init_crps_multiplier=velocity_multiplier,
        )
    if getattr(args, "velocity_init_mean_mse_debias", False):
        if velocity_aux <= 0 or args.arm == "A":
            raise ValueError(
                "Corrected mean MSE requires stochastic positive auxiliary"
            )
        velocity_options["velocity_init_mean_mse_debias"] = True
    training = (
        {} if mode == "joint" else dict(training_mode=mode, processor_trainable=False)
    )
    multiscale = {}
    if objective == "multiscale-fair-crps":
        from .stochastic_multiscale_loss import validate_scales

        sigmas, weights = validate_scales(
            [float(x) for x in args.multiscale_sigmas.split(",")],
            [float(x) for x in args.multiscale_weights.split(",")],
        )
        multiscale = dict(
            multiscale_sigmas=list(sigmas),
            multiscale_weights=list(weights),
            multiscale_operator="gaussian-grid-cells-truncate3-area-mask-circular-lon-zero-lat-v1",
        )
    loss = {
        "member-mse": "MSE" if args.arm == "A" else "member-MSE",
        "mae": "MAE",
        "fair-crps": "fair-CRPS",
        "multiscale-fair-crps": "multiscale-fair-CRPS",
    }[objective]
    if auxiliary:
        loss += "+ensemble-mean-MSE"
    noise = {}
    noise_mode = getattr(args, "noise_mode", "iid")
    noise_blocks = getattr(args, "noise_processing_blocks", 0)
    if noise_mode not in ("iid", "multiscale") or noise_blocks not in (0, 3):
        raise ValueError("Unknown noise ablation configuration")
    if args.arm == "A" and (noise_mode != "iid" or noise_blocks):
        raise ValueError("Noise ablations require a stochastic architecture")
    if noise_mode != "iid" and noise_blocks:
        raise ValueError("Noise structure and processing are separate ablations")
    if noise_mode != "iid":
        noise.update(
            noise_mode=noise_mode,
            noise_sigmas=[0, 1, 2, 4],
            noise_operator="separable-gaussian-truncate4-circular-lon-truncated-lat-row-l2-v1",
            noise_injection_variance="match-iid-bilinear-expectation-per-pixel-v1",
        )
    if noise_blocks:
        noise.update(noise_processing_blocks=noise_blocks, noise_processing_width=32)
    architecture = getattr(args, "noise_architecture", "legacy")
    if architecture not in (
        "legacy",
        "joint_coarse",
        "joint_multires",
        "gan_fullgrid",
        "shared_input",
    ):
        raise ValueError("Unknown noise architecture")
    if architecture != "legacy":
        if args.arm == "A" or noise_mode != "iid" or noise_blocks:
            raise ValueError(
                "Joint noise requires stochastic IID without preprocessing"
            )
        noise["noise_architecture"] = architecture
    capacity = {}
    initializer_widths = getattr(args, "initializer_widths", None)
    initializer_blocks = getattr(args, "initializer_blocks", 1)
    if initializer_blocks < 1:
        raise ValueError("Initializer block count must be positive")
    if initializer_widths is not None:
        if not initializer_widths or min(initializer_widths) < 1:
            raise ValueError("Initializer widths must be positive")
        if list(initializer_widths) != list(args.widths):
            capacity["initializer_widths"] = list(initializer_widths)
    if initializer_blocks != 1:
        capacity["initializer_blocks"] = initializer_blocks
    gan = {}
    if getattr(args, "conditional_gan", False):
        if architecture != "gan_fullgrid" or args.arm != "B" or mode != "joint":
            raise ValueError("Conditional GAN requires joint B gan_fullgrid")
        if objective != "fair-crps" or auxiliary or velocity_options:
            raise ValueError("Conditional GAN requires otherwise unchanged fair CRPS")
        critic_updates = getattr(args, "gan_critic_updates", 5)
        if critic_updates < 1:
            raise ValueError("Critic update count must be positive")
        gan = dict(
            conditional_gan=True,
            gan_critic_updates=critic_updates,
            gan_initializer_weight=0.1,
            gan_gp_weight=10.0,
            gan_drift_weight=0.001,
            gan_critic_widths=[32, 64, 128],
            gan_critic_lr=1e-4,
            gan_critic_adam_betas=[0.5, 0.9],
            gan_target="latest OM4 initial state, all 77 normalized fields",
            gan_generator_pairs="disjoint adjacent member pairs, averaged",
            gan_critic_sampling_seed=args.seed + 700007,
            gan_conditioning="detached generator conditioning; no critic-condition gradient to ERA5 adapter",
            gan_observation_loss="unchanged fair CRPS; no observed velocity GAN target",
        )
        if args.members % 2:
            raise ValueError("Conditional GAN requires an even generator member count")
    cohort = {}
    if getattr(args, "om4_window_mode", "calendar-month") == "native-30day":
        if gan:
            raise ValueError("Dense OM4 sampling is not qualified for conditional GAN")
        cohort = dict(
            om4_window_mode="native-30day",
            om4_sampling_origin_updates=0,
            om4_averaged_readout="equal-weight six native five-day forecast bins (30 days)",
        )
    forcing_mode = getattr(args, "forcing_mode", "bottleneck")
    if forcing_mode not in ("bottleneck", "direct"):
        raise ValueError("Unknown forcing mode")
    forcing = {"forcing_mode": "direct"} if forcing_mode == "direct" else {}
    return dict(
        **forcing,
        **cohort,
        **capacity,
        **gan,
        **noise,
        **multiscale,
        **velocity_options,
        **training,
        version=1,
        objective=objective,
        ensemble_mean_mse_weight=auxiliary,
        architecture="samudra-stochastic-transition",
        arm=args.arm,
        widths=args.widths,
        history=19,
        physical_history_slots=2,
        state_channels=77,
        forcing_channels=8,
        forcing_adapter="identity" if forcing_mode == "direct" else [8, 32, 3],
        main_updates=args.main_updates,
        cooldown_updates=args.cooldown_updates,
        effective_batch=args.effective_batch,
        training_members=1 if args.arm == "A" else args.members,
        seed=args.seed,
        learning_rate=1e-4,
        minimum_lr=1e-6,
        ema_half_life=100,
        ema_reset_at_cooldown=True,
        retain_adam=True,
        gradient_clip=1.0,
        observation_weights=[0.5, 0.5, 0.1],
        om4_weights=[0.5, 0.5, 0.1],
        loss=loss,
        spatial_gradient_loss=False,
        replay=False,
        initialization_task="surface",
        artificial_hiding=False,
        initial_reconstruction="latest state, available surface for OBS; all fields for OM4",
        monthly_readout="calendar-weighted member trajectories, not direct denoising",
        native_readout="all native leads averaged, not random single-lead subsampling",
        normalization="fixed OM4 grid mean/std, frozen OBS ERA5 statistics",
        global_observations=True,
        precision="bf16 autocast with fp32 parameters/loss",
        activation_checkpointing=args.activation_checkpointing,
    )


def build_model(saved, data, *, use_ema=True):
    """Evaluation entrypoint; saved=None is intentionally unsupported."""
    model = make_model(data.grid["names"].tolist(), data.device, saved["contract"])
    model.load_state_dict(saved["ema"] if use_ema else saved["model"], strict=True)
    return model


def make_model(names, device, contract):
    from samudra.experiments.samudra_stochastic_transition import (
        SamudraStochasticTransition,
    )

    metadata = SimpleNamespace(
        channels=len(names),
        history=19,
        surface=[names.index("thetao_0"), names.index("zos")],
    )
    model = SamudraStochasticTransition(
        metadata,
        arm=contract["arm"],
        widths=tuple(contract["widths"]),
        forcing_channels=8 if contract.get("forcing_mode") == "direct" else 3,
        forcing_mode=contract.get("forcing_mode", "bottleneck"),
        noise_mode=contract.get("noise_mode", "iid"),
        noise_processing_blocks=contract.get("noise_processing_blocks", 0),
        noise_architecture=contract.get("noise_architecture", "legacy"),
        initializer_widths=contract.get("initializer_widths"),
        initializer_blocks=contract.get("initializer_blocks", 1),
    ).to(device)
    loss_contract = canonical_contract(contract)
    model.training_mode = loss_contract.get("training_mode", "joint")
    if model.training_mode == "initializer-only":
        model.processor.requires_grad_(False)
    model.velocity_init_mean_mse_debias = loss_contract.get(
        "velocity_init_mean_mse_debias", False
    )
    model.velocity_init_mean_mse_weight = loss_contract.get(
        "velocity_init_mean_mse_weight", 0.0
    )
    model.velocity_init_crps_multiplier = loss_contract.get(
        "velocity_init_crps_multiplier", 1.0
    )
    model.velocity_init_variogram_weight = loss_contract.get(
        "velocity_init_variogram_weight", 0.0
    )
    model.velocity_init_variogram_lags = loss_contract.get(
        "velocity_init_variogram_lags", [1, 2, 4, 8]
    )
    model.velocity_init_signed_crps_weight = loss_contract.get(
        "velocity_init_signed_crps_weight", 0.0
    )
    model.velocity_init_signed_crps_lags = loss_contract.get(
        "velocity_init_signed_crps_lags", [1, 2, 4, 8]
    )
    model.velocity_indices = [
        i for i, n in enumerate(names) if n.startswith(("uo_", "vo_"))
    ]
    model.objective = loss_contract["objective"]
    model.multiscale_sigmas = loss_contract.get("multiscale_sigmas", (1, 2, 4, 8))
    model.multiscale_weights = loss_contract.get("multiscale_weights", (1, 1, 1, 1, 1))
    model.ensemble_mean_mse_weight = loss_contract["ensemble_mean_mse_weight"]
    return model


def rng_state():
    return dict(
        cpu=torch.get_rng_state(),
        cuda=torch.cuda.get_rng_state(),
        numpy=np.random.get_state(),
        python=random.getstate(),
    )


def restore_rng(state):
    torch.set_rng_state(state["cpu"])
    torch.cuda.set_rng_state(state["cuda"])
    np.random.set_state(state["numpy"])
    random.setstate(state["python"])


def resume_rng_state(
    saved,
    contract,
    *,
    world_size,
    rank,
    microbatch,
    allow_migration=False,
    previous_execution=None,
):
    """Select resume RNG without relaxing scientific or exposure contracts.

    For microbatch one every stochastic draw uses a generator seeded by the
    global update and slot, not the ambient rank RNG. Thus rank-zero ambient
    state can be copied on an explicitly requested execution migration.
    """
    if not contracts_match(saved["contract"], contract):
        raise ValueError("Resume contract differs")
    validate_sampling_origin(contract)
    if saved["counts"] != counts(saved["step"], contract):
        raise ValueError("Checkpoint exposure differs")
    old_size = len(saved["rank_rng"])
    if not 0 <= rank < world_size or old_size < 1:
        raise ValueError("Invalid resume rank or saved RNG states")
    if old_size == world_size:
        return saved["rank_rng"][rank], None
    if not allow_migration:
        raise ValueError("Resume world-size differs; explicit migration required")
    execution = saved.get("execution", previous_execution) or {}
    if execution.get("world_size") != old_size:
        # A launch may have written its new execution receipt and then exited
        # before its first checkpoint. Preserve the old checkpoint's evidence.
        execution = execution.get("resume_checkpoint_execution") or {}
    if (
        contract.get("conditional_gan")
        or contract["effective_batch"] != 8
        or microbatch != 1
        or execution.get("microbatch") != 1
        or old_size not in (1, 2, 4, 8)
        or world_size not in (1, 2, 4, 8)
        or execution.get("world_size") != old_size
    ):
        raise ValueError(
            "World-size migration requires non-GAN global batch 8, verified "
            "old/new microbatch 1, and world sizes dividing 8"
        )
    return saved["rank_rng"][0], dict(
        step=saved["step"],
        counts=dict(saved["counts"]),
        previous_world_size=old_size,
        world_size=world_size,
        previous_microbatch=1,
        microbatch=1,
        ambient_rng="saved rank-zero state restored on every destination rank",
        stochastic_rng="seed + completed_update * 1000003 + global_slot * 1009",
        retained=["model", "ema", "optimizer", "step", "counts"],
    )


def configure_dense_om4_windows(reader, forcing, *, built=None):
    """Verify complete cache coverage before replacing the monthly cohort."""
    from .stochastic_om4_windows import build_five_day_om4_windows

    windows, receipt = (
        built if built is not None else build_five_day_om4_windows(reader)
    )
    required = set(receipt["required_frame_indices"])
    missing_packed = sorted(required - set(reader.packed_indices))
    missing_forcing = sorted(required - set(forcing.positions))
    if missing_packed or missing_forcing:
        raise ValueError(
            "Dense OM4 cohort requires cache staging; "
            f"packed missing {len(missing_packed)} indices {missing_packed}; "
            f"ERA5 missing {len(missing_forcing)} indices {missing_forcing}. "
            "Do not filter eligible origins by cache availability."
        )
    if receipt["window_count"] != len(windows) or not windows:
        raise ValueError("Dense OM4 cohort count differs from builder receipt")
    reader.windows = windows
    return dict(receipt, packed_coverage_complete=True, era5_coverage_complete=True)


def verify_dense_cache_extensions(packed_root, forcing_root, cohort, forcing_sha256):
    """Verify immutable parent lineage and retained values of both extended caches."""
    roots = {"packed": Path(packed_root), "era5": Path(forcing_root)}
    proofs = {
        name: json.loads((root / "COMPLETE.json").read_text())
        for name, root in roots.items()
    }
    proof_hashes = {
        name: digest(root / "COMPLETE.json") for name, root in roots.items()
    }
    if proof_hashes["era5"] != forcing_sha256:
        raise ValueError("Dense ERA5 proof differs from requested digest")
    expected_cohort = {
        key: cohort[key]
        for key in (
            "windows_sha256",
            "required_source_intervals_sha256",
            "window_count",
            "required_frame_count",
        )
    }
    required = cohort["required_frame_indices"]
    source_hash = proofs["packed"]["source_metadata_sha256"]
    verified = {}
    for name, root in roots.items():
        proof = proofs[name]
        extension = proof.get("extension", {})
        if (
            extension.get("schema") != "stochastic-dense-cache-extension-v1"
            or extension.get("cohort") != expected_cohort
            or extension.get("source_metadata_sha256") != source_hash
        ):
            raise ValueError(f"{name} extension cohort/source contract differs")
        parent_root = Path(extension["parent_cache"])
        parent_path = parent_root / "COMPLETE.json"
        parent_hash = digest(parent_path)
        if parent_hash != extension.get("parent_proof_sha256"):
            raise ValueError(f"{name} parent proof digest differs")
        parent = json.loads(parent_path.read_text())
        if name == "packed":
            if any(
                parent[key] != proof[key]
                for key in ("source", "source_metadata_sha256", "verification")
            ):
                raise ValueError("Packed extension changed original source contract")
            old_indices, new_indices = parent["indices"], proof["indices"]
        else:
            if proof["contracts"] != parent["contracts"] or any(
                proof["sources"].get(path) != value
                for path, value in parent["sources"].items()
            ):
                raise ValueError(
                    "ERA5 extension changed original source/statistics contracts"
                )
            for filename in ("indices.npy", "values.npy"):
                if digest(parent_root / filename) != parent["files"][filename]:
                    raise ValueError(f"Parent ERA5 {filename} changed")
                if digest(root / filename) != proof["files"][filename]:
                    raise ValueError(f"Dense ERA5 {filename} changed")
            old_indices = np.load(parent_root / "indices.npy").tolist()
            new_indices = np.load(root / "indices.npy").tolist()
        if (
            new_indices != required
            or len(set(old_indices)) != len(old_indices)
            or not set(old_indices).issubset(new_indices)
            or extension.get("old_frame_count") != len(old_indices)
            or extension.get("added_frame_indices")
            != sorted(set(new_indices) - set(old_indices))
        ):
            raise ValueError(
                f"{name} extension indices or retained-count contract differs"
            )
        positions = {index: offset for offset, index in enumerate(new_indices)}
        if name == "packed":
            if len(parent["frame_sha256"]) != len(old_indices) or len(
                proof["frame_sha256"]
            ) != len(new_indices):
                raise ValueError("Packed extension frame-hash count differs")
            if any(
                parent["frame_sha256"][offset]
                != proof["frame_sha256"][positions[index]]
                for offset, index in enumerate(old_indices)
            ):
                raise ValueError("Packed extension changed a retained frame")
        else:
            old_values = np.load(parent_root / "values.npy", mmap_mode="r")
            new_values = np.load(root / "values.npy", mmap_mode="r")
            if (
                old_values.dtype != new_values.dtype
                or old_values.shape[1:] != new_values.shape[1:]
                or len(old_values) != len(old_indices)
                or len(new_values) != len(new_indices)
            ):
                raise ValueError("ERA5 extension value shape or dtype differs")
            for offset, index in enumerate(old_indices):
                if (
                    old_values[offset].tobytes()
                    != new_values[positions[index]].tobytes()
                ):
                    raise ValueError(f"ERA5 extension changed retained frame {index}")
        verified[name] = dict(
            parent_proof_sha256=parent_hash,
            proof_sha256=proof_hashes[name],
            retained_frame_count=len(old_indices),
            added_frame_count=len(new_indices) - len(old_indices),
            retained_frames_verified_unchanged=True,
        )
    return dict(
        schema="verified-stochastic-dense-cache-extension-v1",
        cohort=expected_cohort,
        source_metadata_sha256=source_hash,
        **verified,
    )


def dense_continuation_contract(saved, requested, *, checkpoint, checkpoint_sha256):
    """Authorize only the reviewed monthly-1k to dense-origin continuation."""
    parent = canonical_contract(saved["contract"])
    target = canonical_contract(requested)
    if (
        saved["step"] != 1000
        or saved["counts"] != {"om4": 500, "observation": 500}
        or parent.get("om4_window_mode", "calendar-month") != "calendar-month"
        or target.get("om4_window_mode") != "native-30day"
        or not target.get("om4_cohort", {}).get("packed_coverage_complete")
        or not target.get("om4_cohort", {}).get("era5_coverage_complete")
        or target.get("conditional_gan")
        or target["effective_batch"] != 8
        or target["main_updates"] != 8000
        or target["cooldown_updates"] != 0
        or target.get("om4_sampling_origin_updates") != 0
    ):
        raise ValueError(
            "Dense continuation requires the monthly 1k mixed checkpoint and verified dense cohort"
        )
    allowed = {
        "producer",
        "om4_window_mode",
        "om4_cohort",
        "om4_sampling_origin_updates",
        "om4_averaged_readout",
        "om4_cache_extension",
    }
    extension = target.get("om4_cache_extension", {})
    for field, name in (("packed_proof", "packed"), ("shared_era5_proof", "era5")):
        if parent.get(field) == target.get(field):
            continue
        verified = extension.get(name, {})
        if (
            extension.get("schema") != "verified-stochastic-dense-cache-extension-v1"
            or extension.get("source_metadata_sha256") != target.get("om4_metadata")
            or verified.get("parent_proof_sha256") != parent.get(field)
            or verified.get("proof_sha256") != target.get(field)
            or verified.get("retained_frames_verified_unchanged") is not True
            or extension.get("cohort", {}).get("windows_sha256")
            != target["om4_cohort"]["windows_sha256"]
        ):
            raise ValueError(
                f"Dense continuation {field} change lacks verified parent lineage"
            )
        allowed.add(field)
    differences = {
        key
        for key in parent.keys() | target.keys()
        if parent.get(key) != target.get(key)
    }
    if differences - allowed:
        raise ValueError(
            f"Dense continuation changes unapproved fields: {sorted(differences - allowed)}"
        )
    if not checkpoint_sha256 or target.get("producer") in (None, "unrecorded"):
        raise ValueError(
            "Dense continuation requires checkpoint digest and truthful producer identity"
        )
    target["om4_sampling_origin_updates"] = saved["counts"]["om4"]
    target["continuation_lineage"] = dict(
        path=str(checkpoint),
        sha256=checkpoint_sha256,
        step=saved["step"],
        counts=dict(saved["counts"]),
        parent_contract=dict(saved["contract"]),
        parent_producer=parent.get("producer"),
        producer=target["producer"],
        changed_fields=sorted(differences | {"om4_sampling_origin_updates"}),
        om4_sampling_origin_updates=saved["counts"]["om4"],
        observation_sampling="original task exposure stream retained",
        retain_adam=True,
        retain_ema=True,
    )
    return target


def sampling_exposure(step, contract, source):
    exposure = counts(step, contract)[source]
    if source == "om4":
        exposure -= contract.get("om4_sampling_origin_updates", 0)
    if exposure < 0:
        raise ValueError("Sampling precedes the declared OM4 cohort transition")
    return exposure


def validate_sampling_origin(contract):
    """A dense cohort starts at zero or at its explicitly recorded transition."""
    origin = contract.get("om4_sampling_origin_updates", 0)
    lineage = contract.get("continuation_lineage")
    if lineage is None:
        if origin != 0:
            raise ValueError(
                "Nonzero OM4 sampling origin requires continuation lineage"
            )
        return
    if (
        contract.get("om4_window_mode") != "native-30day"
        or origin != 500
        or lineage.get("om4_sampling_origin_updates") != origin
        or lineage.get("step") != 1000
        or lineage.get("counts") != {"om4": 500, "observation": 500}
    ):
        raise ValueError("OM4 sampling origin differs from the reviewed continuation")


class UpdatePrefetch:
    """Bounded CPU-only lookahead; sampling order belongs to the trainer.

    Depth includes the current update. While GPU computation runs there are at
    most depth-1 prepared/queued updates ahead. No global RNG is consumed here.
    """

    def __init__(self, selection, loader, *, start, stop, depth=4, workers=4):
        if depth < 1 or workers < 1 or start < 0 or stop < start:
            raise ValueError("Invalid prefetch bounds")
        self.selection, self.loader = selection, loader
        self.expected, self.stop, self.depth = start, stop, depth
        self.executor = ThreadPoolExecutor(
            max_workers=workers, thread_name_prefix="onepass-data"
        )
        self.pending = {}

    def _load(self, source, index):
        started = time.monotonic()
        result = self.loader(source, index)
        if any(
            isinstance(v, torch.Tensor) and v.device.type != "cpu"
            for v in result.values()
        ):
            raise ValueError("Prefetch loader produced CUDA tensors")
        return result, time.monotonic() - started

    def take(self, step):
        if step != self.expected or step >= self.stop:
            raise ValueError(
                "Prefetch consumption must follow the declared update sequence"
            )
        for future_step in range(step, min(self.stop, step + self.depth)):
            if future_step in self.pending:
                continue
            source, slots = self.selection(future_step)
            self.pending[future_step] = (
                slots,
                [self.executor.submit(self._load, source, index) for _, index in slots],
            )
        slots, futures = self.pending.pop(step)
        loaded = [future.result() for future in futures]
        self.expected += 1
        return (
            slots,
            [item for item, _ in loaded],
            sum(seconds for _, seconds in loaded),
        )

    def close(self):
        self.executor.shutdown(wait=True, cancel_futures=True)
        self.pending.clear()


def main():
    args = parser().parse_args()
    if args.allow_world_size_migration and not (
        args.resume or args.continue_checkpoint
    ):
        raise ValueError(
            "World-size migration requires --resume or --continue-checkpoint"
        )
    if args.continue_checkpoint and (args.resume or args.fork_checkpoint):
        raise ValueError("Continuation is separate from resume and legacy fork")
    if args.continue_checkpoint and any(
        (args.output / name).exists() for name in ("protocol.json", "last.pt")
    ):
        raise ValueError("Continuation requires a new output directory")
    if args.continue_checkpoint and args.microbatch != 1:
        raise ValueError("Dense continuation requires microbatch 1")
    contract = configuration(args)
    if not torch.cuda.is_available():
        raise RuntimeError("Training requires CUDA")
    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.physical_state_batching import compatible_groups
    from samudra.experiments.physical_state_distributed import DistributedRun
    from samudra.experiments.physical_state_prefetch import native_to_device
    from samudra.experiments.shared_era5 import SharedEra5
    from samudra.experiments.stochastic_transition_objectives import (
        native_batch_objective,
        observation_batch_objective,
    )

    torch.set_num_threads(1)
    device = torch.device("cuda", int(os.environ.get("LOCAL_RANK", 0)))
    torch.cuda.set_device(device)
    runtime = DistributedRun(device)
    if contract.get("conditional_gan") and runtime.world_size != 1:
        raise ValueError("Conditional GAN pilot is qualified for one GPU only")
    if args.resident_native_cache and runtime.world_size != 1:
        raise ValueError(
            "Resident cache memory budget is qualified for one process only"
        )
    if args.effective_batch % runtime.world_size:
        raise ValueError("World size must divide global batch")
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    data = Samples(args.data, device, surface_fill="zero", global_observations=True)
    cpu_data = Samples(
        args.data, torch.device("cpu"), surface_fill="zero", global_observations=True
    )
    cpu_data.__dict__["read_sample"] = lru_cache(maxsize=args.obs_cache_size)(
        cpu_data.read_sample.__wrapped__
    )
    paths = data.paths("train")
    if (len(paths), len(data.paths("validation")), len(data.paths("test"))) != (
        243,
        9,
        96,
    ):
        raise ValueError("Observation cohort changed")
    reader = ModelMonths(
        args.om4 / "OM4.zarr", "om4", data.grid, args.om4, packed=args.packed_om4
    )
    if args.om4_window_mode == "calendar-month" and len(reader.windows) != 409:
        raise ValueError("OM4 window count changed")
    dense_windows = None
    forcing_reader = reader
    if args.om4_window_mode == "native-30day":
        from .stochastic_om4_windows import build_five_day_om4_windows

        dense_windows = build_five_day_om4_windows(reader)
        contract["om4_cache_extension"] = verify_dense_cache_extensions(
            args.packed_om4,
            args.shared_era5,
            dense_windows[1],
            args.shared_era5_proof_sha256,
        )
        # SharedEra5's unchanged exact indices/count/bounds checks validate the
        # new cohort. The original monthly reader remains intact until success.
        forcing_reader = copy.copy(reader)
        forcing_reader.windows = dense_windows[0]
    forcing = SharedEra5(
        args.shared_era5,
        forcing_reader,
        data,
        args.shared_era5_proof_sha256,
        full_readback=True,
    )
    if args.om4_window_mode == "native-30day":
        contract["om4_cohort"] = configure_dense_om4_windows(
            reader, forcing, built=dense_windows
        )
    from samudra.experiments.stochastic_transition_data import (
        CompactNativeLoader,
        verified_local_frames,
    )

    verified_frames = ()
    if os.environ.get("ONEPASS_LOCAL_DATA") and os.environ.get("SLURM_JOB_ID"):
        receipt_name = f"node-local-{os.environ['SLURM_JOB_ID']}.json"
        receipts = [p / receipt_name for p in (args.output, *args.output.parents)]
        receipt = next((p for p in receipts if p.is_file()), None)
        if receipt is None:
            raise ValueError(
                "Node-local data advertised without same-job verification receipt"
            )
        verified_frames = verified_local_frames(
            args.packed_om4, receipt, os.environ["ONEPASS_LOCAL_DATA"]
        )
    native_loader = CompactNativeLoader(
        reader,
        forcing,
        data,
        verified_frames=verified_frames,
        resident=args.resident_native_cache,
    )
    contract.update(
        grid=digest(args.data / "grid.npz"),
        statistics=digest(args.data / "statistics.npz"),
        observation_manifest=digest(args.data / "SHA256SUMS"),
        om4_metadata=digest(args.om4 / "OM4.zarr/.zmetadata"),
        packed_proof=digest(args.packed_om4 / "COMPLETE.json"),
        shared_era5_proof=args.shared_era5_proof_sha256,
        reference=digest(args.reference) if args.reference else None,
        producer=os.environ.get("SAMUDRA_CODE_COMMIT", "unrecorded"),
    )
    continuation_saved = None
    continuation_execution = None
    if args.continue_checkpoint:
        continuation_saved = torch.load(
            args.continue_checkpoint, map_location="cpu", weights_only=False
        )
        contract = dense_continuation_contract(
            continuation_saved,
            contract,
            checkpoint=args.continue_checkpoint,
            checkpoint_sha256=digest(args.continue_checkpoint),
        )
        parent_execution = args.continue_checkpoint.parent / "execution.json"
        if parent_execution.exists():
            continuation_execution = json.loads(parent_execution.read_text())
        proof_execution = (
            continuation_saved.get("execution", continuation_execution) or {}
        )
        if proof_execution.get("microbatch") != 1:
            raise ValueError("Dense continuation needs verified parent microbatch 1")
    elif args.resume and args.om4_window_mode == "native-30day":
        prior = torch.load(
            args.output / "last.pt", map_location="cpu", weights_only=False
        )
        if "continuation_lineage" in prior["contract"]:
            contract["continuation_lineage"] = prior["contract"]["continuation_lineage"]
            contract["om4_sampling_origin_updates"] = prior["contract"][
                "om4_sampling_origin_updates"
            ]
        del prior
    validate_sampling_origin(contract)
    fork_saved = None
    if args.fork_checkpoint:
        from .stochastic_velocity_intervention import validate_fork

        fork_saved = torch.load(
            args.fork_checkpoint, map_location="cpu", weights_only=False
        )
        contract["fork_lineage"] = dict(
            path=str(args.fork_checkpoint),
            sha256=digest(args.fork_checkpoint),
            step=fork_saved["step"],
            counts=fork_saved["counts"],
            parent_contract=fork_saved["contract"],
            retain_adam=True,
            reset_ema_to_raw=True,
        )
        validate_fork(fork_saved, contract)
    args.output.mkdir(parents=True, exist_ok=True)
    execution_path = args.output / "execution.json"
    previous_execution = (
        json.loads(execution_path.read_text()) if execution_path.exists() else None
    )
    # Every rank must read the old execution receipt before rank zero replaces it.
    runtime.barrier()
    protocol = args.output / "protocol.json"
    if protocol.exists() and not contracts_match(
        json.loads(protocol.read_text()), contract
    ):
        raise ValueError("Output protocol differs")
    if runtime.primary:
        atomic_json(contract, protocol)
        if "om4_cohort" in contract:
            atomic_json(contract["om4_cohort"], args.output / "om4-cohort.json")
    model = make_model(data.grid["names"].tolist(), device, contract)
    ema = copy.deepcopy(model).eval().requires_grad_(False)
    if args.activation_checkpointing:
        model.initializer.checkpoint_blocks = True
        model.processor.checkpoint_blocks = True
    if args.compile:
        model.enable_compile()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=1e-4, weight_decay=0.01, fused=args.fused_adam
    )
    gan = None
    if contract.get("conditional_gan"):
        from .stochastic_gan_training import ConditionalGanTraining

        gan = ConditionalGanTraining(
            model,
            seed=args.seed,
            learning_rate=contract["gan_critic_lr"],
            widths=tuple(contract["gan_critic_widths"]),
        )
    last = args.output / "last.pt"
    if last.exists() != args.resume:
        raise ValueError("Existing checkpoint requires --resume and vice versa")
    completed, run_id = 0, None
    execution_migrations = []
    checkpoint_execution = None
    if args.resume or continuation_saved is not None:
        saved = (
            continuation_saved
            if continuation_saved is not None
            else torch.load(last, map_location="cpu", weights_only=False)
        )
        source_execution = (
            continuation_execution
            if continuation_saved is not None
            else previous_execution
        )
        rng, migration = resume_rng_state(
            saved,
            saved["contract"] if continuation_saved is not None else contract,
            world_size=runtime.world_size,
            rank=runtime.rank,
            microbatch=args.microbatch,
            allow_migration=args.allow_world_size_migration,
            previous_execution=source_execution,
        )
        checkpoint_execution = saved.get("execution", source_execution)
        if (
            checkpoint_execution
            and "resume_checkpoint_execution" in checkpoint_execution
        ):
            checkpoint_execution = checkpoint_execution["resume_checkpoint_execution"]
        execution_migrations = list(saved.get("execution_migrations", []))
        if migration is not None:
            migration["checkpoint"] = str(args.continue_checkpoint or last)
            execution_migrations.append(migration)
            if runtime.primary:
                atomic_json(
                    execution_migrations, args.output / "execution-migrations.json"
                )
        model.load_state_dict(saved["model"], strict=True)
        ema.load_state_dict(saved["ema"], strict=True)
        optimizer.load_state_dict(saved["optimizer"])
        completed, run_id = saved["step"], saved["wandb_id"]
        if continuation_saved is not None:
            run_id = None
        if saved["counts"] != counts(completed, contract):
            raise ValueError("Checkpoint exposure differs")
        if gan is not None:
            gan.load_state_dict(saved["gan"])
            expected = saved["counts"]["om4"] * contract["gan_critic_updates"]
            if (
                gan.updates != expected
                or gan.examples != expected * args.effective_batch
            ):
                raise ValueError("Checkpoint discriminator exposure differs")
        restore_rng(rng)
        del saved
    del continuation_saved
    if fork_saved is not None and not args.resume:
        from .stochastic_velocity_intervention import restore_fork

        restore_fork(fork_saved, model, ema, optimizer)
        completed = fork_saved["step"]
        if len(fork_saved["rank_rng"]) != runtime.world_size:
            raise ValueError("Fork world size differs")
        restore_rng(fork_saved["rank_rng"][runtime.rank])
    del fork_saved
    if runtime.primary:
        atomic_json(
            dict(
                world_size=runtime.world_size,
                microbatch=args.microbatch,
                compiled=args.compile,
                fused_adam=args.fused_adam,
                prefetch_workers=args.prefetch_workers,
                prefetch_updates=args.prefetch_updates,
                obs_cache_size=args.obs_cache_size,
                resident_native_cache=native_loader.cache_info,
                resume_checkpoint_execution=checkpoint_execution,
            ),
            execution_path,
        )
    run = None
    if runtime.primary and not args.smoke:
        import wandb

        run = wandb.init(
            project=args.wandb_project,
            entity=args.wandb_entity,
            name=f"onepass-{args.arm}",
            config=contract,
            dir=str(args.output),
            id=run_id,
            resume="must" if run_id else None,
        )
        run_id = run.id
        atomic_json(dict(id=run.id, url=run.url), args.output / "wandb.json")
    run_id = runtime.gather(run_id)[0]
    total = args.main_updates + args.cooldown_updates
    stop = False

    def stopping(*_):
        nonlocal stop
        stop = True

    for sig in (signal.SIGTERM, signal.SIGUSR1):
        signal.signal(sig, stopping)

    def save(snapshot=False):
        states = runtime.gather(rng_state())
        disagreement = (
            runtime.parameter_disagreement(model) if args.check_rank_sync else None
        )
        if disagreement is not None and disagreement != 0:
            raise RuntimeError("Ranks diverged")
        if runtime.primary:
            payload = dict(
                contract=contract,
                model=model.state_dict(),
                ema=ema.state_dict(),
                optimizer=optimizer.state_dict(),
                step=completed,
                counts=counts(completed, contract),
                rank_rng=states,
                execution=dict(
                    world_size=runtime.world_size, microbatch=args.microbatch
                ),
                wandb_id=run_id,
            )
            if execution_migrations:
                payload["execution_migrations"] = execution_migrations
            if gan is not None:
                payload["gan"] = gan.state_dict()
            atomic_torch(payload, last)
            if snapshot:
                atomic_torch(payload, args.output / f"step-{completed:05d}.pt")
            atomic_json(
                dict(
                    step=completed,
                    counts=counts(completed, contract),
                    complete=completed == total,
                    rank_disagreement=disagreement,
                ),
                args.output / "state.json",
            )
        runtime.barrier()

    if not args.resume:
        save(True)
    initial_step = completed
    wall_start = time.monotonic()

    def slots(step):
        source, _ = phase(step, contract)
        exposure = sampling_exposure(step, contract, source)
        indices = sample_indices(
            len(paths) if source == "observation" else len(reader.windows),
            args.seed + (0 if source == "observation" else 100003),
            exposure,
            args.effective_batch,
        )
        return source, [
            (i, index) for i, index in enumerate(indices) if runtime.owns(i)
        ]

    def load(source, index):
        return (
            cpu_data.load(paths[index])
            if source == "observation"
            else native_loader(index)
        )

    execution_stop = (
        min(total, completed + args.max_new_updates)
        if args.max_new_updates is not None
        else total
    )
    prefetch = UpdatePrefetch(
        slots,
        load,
        start=completed,
        stop=execution_stop,
        depth=args.prefetch_updates,
        workers=args.prefetch_workers,
    )
    critic_prefetch = None
    if gan is not None:

        def critic_slots(update):
            indices = sample_indices(
                len(reader.windows),
                contract["gan_critic_sampling_seed"],
                update,
                args.effective_batch,
            )
            return "om4", list(enumerate(indices))

        critic_prefetch = UpdatePrefetch(
            critic_slots,
            load,
            start=gan.updates,
            stop=counts(execution_stop, contract)["om4"]
            * contract["gan_critic_updates"],
            depth=args.prefetch_updates,
            workers=args.prefetch_workers,
        )
    try:
        while completed < total:
            if runtime.any(
                stop
                or time.monotonic() - wall_start > args.hours * 3600
                or (
                    args.max_new_updates is not None
                    and completed - initial_step >= args.max_new_updates
                )
            ):
                break
            step_started = time.time()
            tic = time.monotonic()
            source, lr = phase(completed, contract)
            if completed == args.main_updates:
                ema.load_state_dict(model.state_dict())
            selection, cpu_samples, prepare_seconds = prefetch.take(completed)
            data_wait = time.monotonic() - tic
            samples = [native_to_device(s, device) for s in cpu_samples]
            model.train()
            critic_records = []
            critic_data_wait = 0.0
            if gan is not None and source == "om4":
                for _ in range(contract["gan_critic_updates"]):
                    wait_started = time.monotonic()
                    _, critic_cpu_samples, _ = critic_prefetch.take(gan.updates)
                    critic_data_wait += time.monotonic() - wait_started
                    critic_samples = [
                        native_to_device(s, device) for s in critic_cpu_samples
                    ]
                    critic_records.append(
                        gan.update(model, critic_samples, microbatch=args.microbatch)
                    )
                    del critic_samples, critic_cpu_samples
            optimizer.zero_grad(set_to_none=True)
            for group in optimizer.param_groups:
                group["lr"] = lr
            velocity_stats = torch.zeros(3, device=device)
            variogram_stats = torch.zeros(5, device=device)
            signed_stats = torch.zeros(5, device=device)
            components = torch.zeros(3, device=device)
            loss_total = torch.zeros((), device=device)
            for group in compatible_groups(samples, args.microbatch):
                seed = args.seed + completed * 1000003 + selection[group[0]][0] * 1009
                generator = torch.Generator(device=device).manual_seed(seed)
                inputs = [samples[i] for i in group]
                seeds = [
                    args.seed + completed * 1000003 + selection[i][0] * 1009
                    for i in group
                ]
                function = (
                    observation_batch_objective
                    if source == "observation"
                    else native_batch_objective
                )
                # Native reconstruction is called once per sample, while OBS never
                # calls it. Reset here to avoid stale diagnostics across either path.
                model.variogram_diagnostics = torch.zeros(5, device=device)
                model.signed_increment_diagnostics = torch.zeros(5, device=device)
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    extra = (
                        {"initializer_critic": gan.critic}
                        if gan is not None and source == "om4"
                        else {}
                    )
                    loss, parts = function(
                        model,
                        data,
                        inputs,
                        generator,
                        members=contract["training_members"],
                        seeds=seeds,
                        **extra,
                    )
                scale = len(group) / args.effective_batch
                if not torch.isfinite(loss):
                    raise FloatingPointError("Nonfinite loss")
                (loss * scale).backward()
                loss_total += loss.detach() * scale
                components += parts * scale
                if source == "om4" and hasattr(model, "velocity_diagnostics"):
                    velocity_stats += model.velocity_diagnostics * scale
                if source == "om4":
                    variogram_stats += model.variogram_diagnostics * scale / len(group)
                    signed_stats += (
                        model.signed_increment_diagnostics * scale / len(group)
                    )
            runtime.sum_gradients(model)
            grad = torch.nn.utils.clip_grad_norm_(
                model.parameters(), 1.0, error_if_nonfinite=True
            )
            optimizer.step()
            update_ema(ema, model, 100)
            torch.cuda.synchronize(device)
            elapsed = time.monotonic() - tic
            usage = resource.getrusage(resource.RUSAGE_SELF)
            rows = runtime.gather(
                dict(
                    loss=float(loss_total),
                    components=components.cpu().tolist(),
                    variogram_terms=variogram_stats.cpu().tolist(),
                    signed_increment_terms=signed_stats.cpu().tolist(),
                    seconds=elapsed,
                    data_wait_seconds=data_wait,
                    data_prepare_worker_seconds=prepare_seconds,
                    native_prepare_phases={
                        key: sum(
                            s.get("native_prepare_phases", {}).get(key, 0.0)
                            for s in cpu_samples
                        )
                        for key in (
                            "checksum_seconds",
                            "gather_seconds",
                            "normalization_seconds",
                            "forcing_seconds",
                        )
                    },
                    max_rss_kib=usage.ru_maxrss,
                    major_faults=usage.ru_majflt,
                    minor_faults=usage.ru_minflt,
                    peak_allocated_bytes=torch.cuda.max_memory_allocated(device),
                )
            )
            completed += 1
            event = dict(
                step=completed,
                source=source,
                lr=lr,
                loss=sum(r["loss"] for r in rows),
                components=np.sum([r["components"] for r in rows], axis=0).tolist(),
                grad_norm=float(grad),
                seconds=max(r["seconds"] for r in rows),
                data_wait_seconds=max(r["data_wait_seconds"] for r in rows),
                data_prepare_worker_seconds=sum(
                    r["data_prepare_worker_seconds"] for r in rows
                ),
                native_prepare_phases={
                    key: sum(r["native_prepare_phases"][key] for r in rows)
                    for key in rows[0]["native_prepare_phases"]
                },
                max_rank_rss_kib=max(r["max_rss_kib"] for r in rows),
                major_faults=sum(r["major_faults"] for r in rows),
                minor_faults=sum(r["minor_faults"] for r in rows),
                queued_updates=len(prefetch.pending),
                peak_allocated_bytes=max(r["peak_allocated_bytes"] for r in rows),
                velocity_auxiliary_terms=velocity_stats.cpu().tolist(),
                update_started_unix=step_started,
                update_finished_unix=time.time(),
                counts=counts(completed, contract),
            )
            if contract.get("velocity_init_variogram_weight", 0.0):
                for i, name in enumerate(
                    (
                        "fair",
                        "plugin",
                        "finite_ensemble_correction",
                        "weighted_auxiliary",
                        "weighted_base_initializer_crps",
                    )
                ):
                    event[f"velocity_init_variogram/{name}"] = sum(
                        r["variogram_terms"][i] for r in rows
                    )
            if contract.get("velocity_init_signed_crps_weight", 0.0):
                for i, name in enumerate(
                    (
                        "fair",
                        "accuracy",
                        "spread",
                        "weighted_auxiliary",
                        "weighted_base_initializer_crps",
                    )
                ):
                    event[f"velocity_init_signed_crps/{name}"] = sum(
                        r["signed_increment_terms"][i] for r in rows
                    )
            if gan is not None:
                event.update(
                    gan_critic_updates=gan.updates,
                    gan_critic_examples=gan.examples,
                    gan_critic_data_wait_seconds=critic_data_wait,
                    gan_critic_seconds=sum(r["seconds"] for r in critic_records),
                    gan_critic_records=critic_records,
                    gan_initializer_unweighted=(
                        float(components[2]) if source == "om4" else None
                    ),
                )
            if runtime.primary:
                with (args.output / "events.jsonl").open("a") as stream:
                    stream.write(json.dumps(event) + "\n")
                print(json.dumps(event), flush=True)
                if run:
                    run.log(event, step=completed)
            # Release current CPU/GPU example containers before filling the next queue slot.
            del cpu_samples, samples, inputs
            if (
                completed - contract.get("fork_lineage", {}).get("step", 0)
            ) % args.checkpoint_every == 0 or completed in (
                args.main_updates,
                total,
            ):
                save(True)
        save(completed == total)
        if completed == total and runtime.primary:
            atomic_json(
                dict(
                    step=completed,
                    counts=counts(completed, contract),
                    complete=True,
                    **(
                        dict(
                            gan_critic_updates=gan.updates,
                            gan_critic_examples=gan.examples,
                        )
                        if gan is not None
                        else {}
                    ),
                ),
                args.output / "COMPLETE.json",
            )
    finally:
        prefetch.close()
        if critic_prefetch is not None:
            critic_prefetch.close()
        if run:
            run.finish()


if __name__ == "__main__":
    main()
