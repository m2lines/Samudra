# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Prepare training-only controls on CPU, then evaluate fixed conditioning swaps.

Run `prepare --help` first. Evaluation consumes its immutable prepared bundle.
The interventions measure model sensitivity; they do not identify ocean causality.
"""

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch

SURFACE = [38, 76]
NAMES = [f"{v}_{d}" for v in ("uo", "vo", "thetao", "so") for d in range(19)] + ["zos"]
MONTHS = ["2014-01", "2014-04", "2014-05"]
SEED = 904003
MODES = ["recipient", "input-swap", "interior-swap"]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def dates(values):
    return np.asarray(values, dtype="datetime64[s]").astype(str).tolist()


def month_index(value):
    return int(str(value)[5:7]) - 1


def calendar_signature(values):
    """Year-free sequence; preserve month/day/time and year-boundary offsets."""
    labels = dates(values)
    year = int(labels[-1][:4])
    return [(int(x[:4]) - year, x[4:]) for x in labels]


def select_donor(recipient, candidates):
    """Most recent training-year history with exactly matching calendar bins."""
    target = dates(recipient)
    signature = calendar_signature(target)
    eligible = []
    for identity, history in candidates:
        history = dates(history)
        if (
            history[-1][:4] != target[-1][:4]
            and max(history) < "2014-01-01"
            and calendar_signature(history) == signature
        ):
            eligible.append((history[-1], identity))
    if not eligible:
        raise ValueError("No exact same-calendar training-year donor")
    return max(eligible, key=lambda x: (x[0], str(x[1])))[1]


def monthly_average(records, shape, *, cutoff="2014-01-01", strict_wet=None):
    """Unique timestamp records only; repeated windows must be byte-identical.

    Invalid observation pixels contribute no samples. No spatial fallback is used.
    Every source value is checked against the exclusive training-date cutoff.
    """
    total = np.zeros((12, *shape), dtype=np.float64)
    count = np.zeros((12, *shape), dtype=np.uint32)
    seen = {}
    for label, values in records:
        label = dates([label])[0]
        if label >= cutoff:
            raise ValueError(f"Climatology record outside training dates: {label}")
        values = np.asarray(values, dtype=np.float32)
        checksum = hashlib.sha256(values.tobytes()).hexdigest()
        if label in seen:
            if seen[label] != checksum:
                raise ValueError(f"Conflicting duplicate training timestamp: {label}")
            continue
        seen[label] = checksum
        if values.shape != tuple(shape):
            raise ValueError("Climatology field shape differs")
        valid = np.isfinite(values)
        if strict_wet is not None:
            if not valid[strict_wet].all():
                raise ValueError("Nonfinite packed training field on wet support")
            valid &= strict_wet
        m = month_index(label)
        total[m] += np.where(valid, values, 0)
        count[m] += valid
    result = np.divide(total, count, out=np.full_like(total, np.nan), where=count > 0)
    return result.astype(np.float32), count, seen


def swap_interior(recipient, donor, surface=SURFACE):
    """Swap both initialized interior states, preserving recipient surface slots."""
    if recipient.shape != donor.shape or recipient.ndim != 5 or recipient.shape[1] != 2:
        raise ValueError("Require matched member,2,channel,y,x initial states")
    result = donor.clone()
    result[:, :, surface] = recipient[:, :, surface]
    return result


def initialize(model, sample, mask, members=8, seed=SEED, donor=None):
    """Input swap replaces only surface history and its validity indicators."""
    source = sample if donor is None else donor
    condition, _, _ = model.encode_native(
        source["surface"][:, : model.history],
        sample["atmosphere"][:, : model.history],
        sample["contexts"][:, model.history - 1],
        mask,
        source["validity"][:, : model.history],
        return_anchors=False,
    )
    condition = condition.expand(members, *condition.shape[1:])
    generator = torch.Generator(device=condition.device).manual_seed(seed)
    return model.initialize(condition, None, None, mask, generator)


def trajectory(model, initial, sample, mask, seed=SEED):
    """Continue a fixed initial state with only recipient forcing/calendar."""
    state = initial
    generator = torch.Generator(device=state.device).manual_seed(seed)
    for step in range(model.history, sample["atmosphere"].shape[1]):
        state = model.advance(
            state,
            sample["atmosphere"][:, step].expand(len(state), -1, -1, -1),
            sample["contexts"][:, step].expand(len(state), -1, -1, -1),
            mask,
            generator,
        )
        yield state[:, -1].float()


def field_metrics(draws, gold, climate, mask, lat, paired=None):
    """Common-reference support, cos-latitude means; missing metrics are null.

    Anomaly correlation is spatial centered correlation after subtracting the
    training monthly climatology at each grid cell. Anomaly error equals raw
    error algebraically; skill is 1 - model MSE / climatology MSE.
    """
    x, y, c = [np.asarray(v, dtype=np.float64) for v in (draws, gold, climate)]
    if x.ndim != 4 or x.shape[1:] != y.shape or y.shape != c.shape or len(x) < 2:
        raise ValueError("Need matched ensemble and reference/climatology fields")
    valid = np.asarray(mask, bool) & np.isfinite(y) & np.isfinite(c)
    if not np.isfinite(x[:, valid]).all():
        raise ValueError("Nonfinite prediction on fixed reference/climatology support")
    x, y, c = (np.where(valid, v, 0) for v in (x, y, c))
    w = valid * np.cos(np.deg2rad(lat))[None, :, None]
    den = w.sum((-2, -1))

    def avg(v):
        return np.divide(
            (v * w).sum((-2, -1)), den, out=np.full(v.shape[:-2], np.nan), where=den > 0
        )

    def corr(a, b):
        a = a - avg(a)[..., None, None]
        b = b - avg(b)[..., None, None]
        var = np.sqrt(avg(a * a) * avg(b * b))
        return np.divide(avg(a * b), var, out=np.full_like(var, np.nan), where=var > 0)

    if paired is None:
        paired = draws
    paired = np.asarray(paired, dtype=np.float64)
    if paired.shape != x.shape or not np.isfinite(paired[:, valid]).all():
        raise ValueError("Invalid paired recipient ensemble")
    paired = np.where(valid, paired, 0)
    mean = x.mean(0)
    mse, cmse = avg((mean - y) ** 2), avg((c - y) ** 2)
    pair = sum(np.abs(x[i] - x[j]) for i in range(len(x)) for j in range(i))
    crps = avg(np.abs(x - y).mean(0) - pair / (len(x) * (len(x) - 1)))
    return dict(
        mean_mse=mse,
        rmse=np.sqrt(mse),
        climatology_mse=cmse,
        climatology_rmse=np.sqrt(cmse),
        fair_crps=crps,
        climatology_mae=avg(np.abs(c - y)),
        bias=avg(mean - y),
        mse_skill=1
        - np.divide(mse, cmse, out=np.full_like(mse, np.nan), where=cmse > 0),
        correlation=corr(mean, y),
        anomaly_correlation=corr(mean - c, y - c),
        anomaly_gold_power=avg((y - c) ** 2),
        anomaly_mean_power=avg((mean - c) ** 2),
        anomaly_member_power=avg((x - c) ** 2).mean(0),
        member_mse=avg((x - y) ** 2).mean(0),
        spread_variance=avg(x.var(0, ddof=1)),
        paired_member_change_rmse=np.sqrt(avg((x - paired) ** 2).mean(0)),
        paired_mean_change_rmse=np.sqrt(avg((mean - paired.mean(0)) ** 2)),
        support_weight=den,
    )


def metric_rows(values, names, **identity):
    return [
        dict(
            identity,
            channel=name,
            **{
                key: float(value[i]) if np.isfinite(value[i]) else None
                for key, value in values.items()
            },
        )
        for i, name in enumerate(names)
    ]


def validate_checkpoint(saved, prepared):
    c = saved["contract"]
    expected = dict(
        arm="B",
        forcing_mode="direct",
        objective="fair-crps",
        initializer_widths=[96, 192, 384],
        initializer_blocks=3,
        widths=[64, 128, 256],
        velocity_init_signed_crps_weight=1.0,
        seed=1729,
        grid=prepared["grid_sha256"],
        om4_window_mode="native-30day",
    )
    if saved["step"] != 8000 or saved["counts"] != {"om4": 4000, "observation": 4000}:
        raise ValueError("Require final 8000-update mixed checkpoint")
    if any(c.get(key) != value for key, value in expected.items()):
        raise ValueError("Checkpoint architecture/objective/grid contract differs")
    for key in ("statistics", "packed_proof", "observation_manifest"):
        expected_sha = prepared.get(key + "_sha256")
        if not expected_sha or c.get(key) != expected_sha:
            raise ValueError(f"Checkpoint {key} differs from prepared inputs")
    for key in ("window_count", "windows_sha256", "required_source_intervals_sha256"):
        if c.get("om4_cohort", {}).get(key) != prepared["cohort"][key]:
            raise ValueError("Checkpoint training cohort differs from climatology")


def normalize_surface(values, grid):
    mask = grid["mask"][SURFACE]
    valid = np.isfinite(values) & mask
    result = np.where(
        valid,
        (values - grid["mean"][SURFACE, None, None]) / grid["std"][SURFACE, None, None],
        0,
    ).astype(np.float32)
    return result, valid


def observation_training_records(paths, key, spatial_shape):
    """Read target-native records; OHC never passes through interpolated T levels."""
    if key not in ("surface", "interior", "ohc"):
        raise ValueError("Unknown observation climatology field")
    channels = 28 if key == "interior" else 2
    for path in paths:
        with np.load(path) as saved:
            if key == "surface":
                yield from zip(dates(saved["midpoints"]), saved[key], strict=True)
            else:
                yield path.stem + "-15", saved[key].reshape(channels, *spatial_shape)


def prepare(args):
    import cftime
    import zarr

    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.stochastic_om4_windows import build_five_day_om4_windows

    args.output.mkdir(parents=True, exist_ok=False)
    paths = json.loads(args.paths.read_text())
    root, packed_root = Path(paths["samples"]), Path(paths["packed_om4"])
    data = Samples(root, "cpu", surface_fill="zero", global_observations=True)
    if data.grid["names"].tolist() != NAMES:
        raise ValueError("Unexpected native channel order")
    reader = ModelMonths(
        Path(paths["om4"]) / "OM4.zarr",
        "om4",
        data.grid,
        Path(paths["om4"]),
        packed=packed_root,
    )
    windows, cohort = build_five_day_om4_windows(reader)
    proof = json.loads((packed_root / "COMPLETE.json").read_text())
    required = cohort["required_frame_indices"]
    if (
        len(windows) != 2548
        or len(required) != 2812
        or proof["indices"] != required
        or max(str(reader.bounds[i, 1]) for i in required) >= "2014-01-01"
    ):
        raise ValueError("Require verified 2548-origin/2812-frame training-only cohort")
    labels = dates([reader.midpoints[i] for i in required])

    def om4_records():
        for index, label in zip(required, labels, strict=True):
            offset = reader.packed_indices[index]
            value = reader.packed[offset]
            if (
                hashlib.sha256(value.tobytes()).hexdigest()
                != reader.packed_hashes[offset]
            ):
                raise ValueError(f"Packed frame changed at {index}")
            yield label, value

    climate, counts, seen = monthly_average(
        om4_records(),
        data.grid["mask"].shape,
        strict_wet=data.grid["mask"].astype(bool),
    )
    np.savez(args.output / "om4-climatology.npz", mean=climate, count=counts)
    del climate, counts
    train_paths = data.paths("train")
    if len(train_paths) != 243 or any(p.stem >= "2014-01" for p in train_paths):
        raise ValueError("Expected 243 pre-2014 training observation windows")
    train_hashes = {str(p): digest(p) for p in train_paths}
    obs_histories = []

    surface_clim, surface_counts, obs_seen = monthly_average(
        observation_training_records(
            train_paths, "surface", data.grid["mask"].shape[-2:]
        ),
        (2, *data.grid["mask"].shape[-2:]),
    )
    interior_clim, interior_counts, _ = monthly_average(
        observation_training_records(
            train_paths, "interior", data.grid["mask"].shape[-2:]
        ),
        (28, *data.grid["mask"].shape[-2:]),
    )
    ohc_clim, ohc_counts, _ = monthly_average(
        observation_training_records(train_paths, "ohc", data.grid["mask"].shape[-2:]),
        (2, *data.grid["mask"].shape[-2:]),
    )
    np.savez(
        args.output / "observation-climatology.npz",
        surface=surface_clim,
        surface_count=surface_counts,
        interior=interior_clim,
        interior_count=interior_counts,
        ohc=ohc_clim,
        ohc_count=ohc_counts,
    )
    for path in train_paths:
        with np.load(path) as saved:
            obs_histories.append((str(path), dates(saved["midpoints"][:19])))
    store = zarr.open_consolidated(str(args.om4_gold), mode="r")
    ta = store["time"]
    gold_labels = [
        d.strftime("%Y-%m-%dT%H:%M:%S")
        for d in cftime.num2date(
            ta[:], ta.attrs["units"], ta.attrs.get("calendar", "standard")
        )
    ]
    lookup = {label: i for i, label in enumerate(gold_labels)}
    if len(lookup) != len(gold_labels):
        raise ValueError("Duplicate gold timestamps")
    np.testing.assert_allclose(store["x"][:], data.grid["lon"], atol=1e-6, rtol=0)
    np.testing.assert_allclose(store["y"][:], data.grid["lat"], atol=1e-6, rtol=0)
    mask = np.stack(
        [store[f"mask_{i}"][:] for i in range(19)] * 4 + [store["mask_0"][:]]
    )
    np.testing.assert_array_equal(mask, data.grid["mask"])
    candidates = [
        (start, dates(reader.midpoints[start - 19 : start]))
        for start, _, _, _ in windows
    ]
    validation = data.paths("validation")
    if len(validation) != 9:
        raise ValueError("Require frozen nine-origin observation evaluation")
    cases = []
    for path in validation:
        sample = data.load(path)
        raw = sample["raw"]
        recipient_dates = dates(raw["midpoints"])
        donor_path = Path(select_donor(recipient_dates[:19], obs_histories))
        with np.load(donor_path) as donor:
            donor_surface, donor_validity = normalize_surface(
                donor["surface"][:19], data.grid
            )
        payload = {
            key: sample[key][0].numpy()
            for key in ("surface", "validity", "atmosphere", "contexts")
        }
        payload.update(
            donor_surface=donor_surface,
            donor_validity=donor_validity,
            gold_surface=raw["surface"],
            gold_interior=sample["interior"][0].numpy(),
            gold_ohc=raw["ohc"],
            month_weights=raw["month_weights"],
            midpoints=np.array(recipient_dates),
        )
        name = "observation-" + path.stem
        np.savez(args.output / (name + ".npz"), **payload)
        cases.append(
            dict(
                name=name,
                source="observation",
                month=path.stem,
                donor=str(donor_path),
                sample_sha256=digest(path),
                seed=SEED,
            )
        )
        if path.stem not in MONTHS:
            continue
        wanted = recipient_dates[:25]
        ids = [lookup[label] for label in wanted]
        if not np.all(np.diff(ids) == 1):
            raise ValueError("Noncontiguous held-out OM4 dates")
        donor_start = select_donor(wanted[:19], candidates)
        donor_indices = range(donor_start - 19, donor_start)
        donor_physical = np.stack(
            [reader.packed[reader.packed_indices[i]][SURFACE] for i in donor_indices]
        )
        donor_surface, donor_validity = normalize_surface(donor_physical, data.grid)
        surface = np.stack(
            [np.stack([store[n][i] for n in ("thetao_0", "zos")]) for i in ids]
        )
        surface, validity = normalize_surface(surface, data.grid)
        gold = np.stack(
            [np.stack([store[n][ids[t]] for n in NAMES]) for t in [18, 19, 21, 24]]
        )
        if not np.isfinite(gold[:, mask.astype(bool)]).all():
            raise ValueError("Nonfinite OM4 held-out reference")
        name = "om4-" + path.stem
        np.savez(
            args.output / (name + ".npz"),
            surface=surface,
            validity=validity,
            atmosphere=payload["atmosphere"][:25],
            contexts=payload["contexts"][:25],
            donor_surface=donor_surface,
            donor_validity=donor_validity,
            gold=gold,
            midpoints=np.array(wanted),
            month_weights=np.full(6, 1 / 6, dtype=np.float32),
        )
        cases.append(
            dict(
                name=name,
                source="om4",
                month=path.stem,
                donor_indices=list(donor_indices),
                donor_dates=dates(reader.midpoints[donor_start - 19 : donor_start]),
                gold_indices=ids,
                seed=SEED,
            )
        )
        data.read_sample.cache_clear()
    np.savez(args.output / "grid.npz", **data.grid)
    files = {p.name: digest(p) for p in sorted(args.output.glob("*.npz"))}
    write_json(
        args.output / "PREPARED.json",
        dict(
            complete=True,
            schema="stochastic-conditioning-v1",
            cohort=cohort,
            cases=cases,
            files=files,
            grid_sha256=digest(root / "grid.npz"),
            statistics_sha256=digest(root / "statistics.npz"),
            observation_manifest_sha256=digest(root / "SHA256SUMS"),
            packed_proof_sha256=digest(packed_root / "COMPLETE.json"),
            train_sample_sha256=train_hashes,
            om4_gold_metadata_sha256=digest(args.om4_gold / ".zmetadata"),
            training_om4_unique_timestamps=len(seen),
            training_obs_unique_timestamps=len(obs_seen),
            climate="unique training records, midpoint calendar month, no spatial fallback",
            observation_ohc_climate="Monthly mean of training sample ohc maps, preserving the original observational target integration/remapping operator; no integration of interpolated temperature climatology.",
            script_sha256=digest(__file__),
        ),
    )


def physical_ohc(temperature, mask):
    """Native-layer OHC, J/m2, requiring every contributing level to be present.

    Accept 14 observed or 19 model levels. Missing deep values never receive a
    climatological fallback. These layers end at 2000 m, within the first 14 slots.
    """
    from samudra.constants import build_om4_layout
    from samudra.metrics.kernels import CP, OHC_LAYERS, RHO

    x = np.asarray(temperature, dtype=np.float64)
    dz = np.asarray(build_om4_layout().depth_thickness[: x.shape[-3]])
    edges = np.concatenate([[0.0], np.cumsum(dz)])
    maps = []
    for layer in OHC_LAYERS:
        overlap = np.maximum(
            0,
            np.minimum(edges[1:], layer.max_depth)
            - np.maximum(edges[:-1], layer.min_depth),
        )
        if not np.isclose(overlap.sum(), layer.max_depth - layer.min_depth):
            raise ValueError("Temperature axis does not span OHC layer")
        used = overlap > 0
        valid = np.isfinite(x[..., used, :, :]) & np.asarray(mask, bool)[used]
        complete = valid.all(-3)
        total = (
            np.where(valid, x[..., used, :, :], 0) * overlap[used, None, None]
        ).sum(-3)
        maps.append(np.where(complete, total * RHO * CP, np.nan))
    return np.stack(maps, axis=-3)


def map_limits(fields, support, *, symmetric):
    """Pooled robust bounds for comparable maps; missing pixels never set scale."""
    values = np.stack(fields)[:, support]
    values = values[np.isfinite(values)]
    if not len(values):
        return (-1.0, 1.0)
    if symmetric:
        limit = max(float(np.percentile(np.abs(values), 99)), 1e-12)
        return (-limit, limit)
    low, high = np.percentile(values, [1, 99])
    if high <= low:
        padding = max(abs(float(low)) * 1e-6, 1e-12)
        low, high = low - padding, high + padding
    return float(low), float(high)


def save_maps(output, name, draws, gold, climate, names, grid):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    mean = draws.mean(0)
    error = mean - gold
    anomaly_gold, anomaly_mean, anomaly_member = (
        gold - climate,
        mean - climate,
        draws[0] - climate,
    )
    physical_limits, error_limits, anomaly_limits, units = [], [], [], []
    fig, axes = plt.subplots(
        len(names), 5, figsize=(17, 2.7 * len(names)), squeeze=False
    )
    anomaly_fig, anomaly_axes = plt.subplots(
        len(names), 3, figsize=(12, 2.7 * len(names)), squeeze=False
    )
    extent = [grid["lon"][0], grid["lon"][-1], grid["lat"][0], grid["lat"][-1]]

    def panel(figure, ax, field, support, title, limits, unit, cmap):
        im = ax.imshow(
            np.where(support, field, np.nan),
            origin="lower",
            cmap=cmap,
            vmin=limits[0],
            vmax=limits[1],
            extent=extent,
            aspect="auto",
        )
        ax.set_title(f"{title}\n[{limits[0]:.4g}, {limits[1]:.4g}] {unit}", fontsize=8)
        colorbar = figure.colorbar(im, ax=ax, shrink=0.7, extend="both")
        colorbar.set_label(unit, fontsize=7)

    for i, channel in enumerate(names):
        support = np.isfinite(gold[i]) & np.isfinite(climate[i])
        velocity = channel.startswith(("uo_", "vo_"))
        unit = (
            "m/s"
            if velocity
            else "degC"
            if channel.startswith("thetao_")
            else "psu"
            if channel.startswith("so_")
            else "m"
        )
        units.append(unit)
        physical = [gold[i], climate[i], mean[i], draws[0, i]]
        anomalies = [anomaly_gold[i], anomaly_mean[i], anomaly_member[i]]
        physical_limits.append(map_limits(physical, support, symmetric=velocity))
        error_limits.append(map_limits([error[i]], support, symmetric=True))
        anomaly_limits.append(map_limits(anomalies, support, symmetric=True))
        for j, (field, label) in enumerate(
            zip(
                physical,
                ["reference", "training climate", "ensemble mean", "member 0"],
                strict=True,
            )
        ):
            panel(
                fig,
                axes[i, j],
                field,
                support,
                channel + ": " + label,
                physical_limits[-1],
                unit,
                "RdBu_r" if velocity else "viridis",
            )
        panel(
            fig,
            axes[i, 4],
            error[i],
            support,
            channel + ": mean error",
            error_limits[-1],
            unit,
            "RdBu_r",
        )
        for j, (field, label) in enumerate(
            zip(
                anomalies,
                ["reference - climate", "mean - climate", "member 0 - climate"],
                strict=True,
            )
        ):
            panel(
                anomaly_fig,
                anomaly_axes[i, j],
                field,
                support,
                channel + ": " + label,
                anomaly_limits[-1],
                unit,
                "RdBu_r",
            )
    fig.suptitle(
        "First four panels share row limits; mean error has its own zero-centered scale.\nLimits clip pooled 1st/99th percentiles (velocity: 99th absolute); error: 99th absolute.",
        fontsize=9,
    )
    anomaly_fig.suptitle(
        "Anomalies relative to training monthly climatology; each row shares a zero-centered scale.\nLimits clip the pooled 99th absolute percentile of the three anomaly fields.",
        fontsize=9,
    )
    for figure, suffix in ((fig, ""), (anomaly_fig, "-anomalies")):
        figure.tight_layout(rect=(0, 0, 1, 0.97))
        figure.savefig(output / (name + suffix + ".png"), dpi=110)
        plt.close(figure)
    np.savez_compressed(
        output / (name + ".npz"),
        members=draws,
        reference=gold,
        climatology=climate,
        names=names,
        units=units,
        mean_error=error,
        reference_anomaly=anomaly_gold,
        mean_anomaly=anomaly_mean,
        member0_anomaly=anomaly_member,
        physical_limits=physical_limits,
        error_limits=error_limits,
        anomaly_limits=anomaly_limits,
    )


def plot_depths(output, rows, modes):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from samudra.constants import build_om4_layout

    depths = build_om4_layout().depth_levels
    fig, axes = plt.subplots(2, 4, figsize=(15, 9), sharey=True)
    for row, variable in enumerate(("uo", "vo")):
        for col, metric in enumerate(
            ("rmse", "mse_skill", "anomaly_correlation", "paired_member_change_rmse")
        ):
            ax = axes[row, col]
            for mode in modes:
                values = []
                for depth in range(19):
                    selected = [
                        r
                        for r in rows
                        if r["source"] == "om4"
                        and r["lead"] == 0
                        and r["intervention"] == mode
                        and r["channel"] == f"{variable}_{depth}"
                    ]
                    if metric == "rmse":
                        value = np.sqrt(np.mean([r["mean_mse"] for r in selected]))
                    elif metric == "mse_skill":
                        value = 1 - np.mean(
                            [r["mean_mse"] for r in selected]
                        ) / np.mean([r["climatology_mse"] for r in selected])
                    else:
                        finite = [r[metric] for r in selected if r[metric] is not None]
                        value = np.mean(finite) if finite else np.nan
                    values.append(value)
                ax.plot(values, depths, label=mode)
            ax.set_title(variable + " " + metric, fontsize=9)
            ax.grid(alpha=0.25)
            ax.set_xlabel("m/s" if metric.endswith("rmse") else "dimensionless")
        axes[row, 0].set_ylabel("Depth (m)")
    axes[0, 0].invert_yaxis()
    axes[0, 0].legend(fontsize=7)
    fig.suptitle(
        "Three OM4 initializer cases; training monthly climatology; fixed member noise"
    )
    fig.tight_layout()
    fig.savefig(output / "all-depths.png", dpi=140)
    fig.savefig(output / "all-depths.pdf")
    plt.close(fig)


def evaluate(args):
    from types import SimpleNamespace

    from samudra.experiments.stochastic_transition_train import build_model

    started = time.monotonic()
    args.output.mkdir(parents=True, exist_ok=False)
    prepared = json.loads((args.prepared / "PREPARED.json").read_text())
    for name, checksum in prepared["files"].items():
        if digest(args.prepared / name) != checksum:
            raise ValueError(f"Prepared input changed: {name}")
    grid = dict(np.load(args.prepared / "grid.npz"))
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    validate_checkpoint(saved, prepared)
    device = "cuda"
    model = build_model(
        saved, SimpleNamespace(grid=grid, device=device), use_ema=True
    ).eval()
    if (
        model.forcing_channels != 8
        or model.forcing_mode != "direct"
        or model.arm != "B"
    ):
        raise ValueError("Require direct-eight deterministic processor contract")
    mask = torch.as_tensor(grid["mask"], device=device)
    mean = torch.as_tensor(grid["mean"][:, None, None], device=device)
    std = torch.as_tensor(grid["std"][:, None, None], device=device)
    with np.load(args.prepared / "om4-climatology.npz") as source:
        om4_climate = source["mean"]
    with np.load(args.prepared / "observation-climatology.npz") as source:
        obs_surface, obs_interior, obs_ohc = (
            source["surface"],
            source["interior"],
            source["ohc"],
        )
    rows, receipts = [], []
    modes = MODES + (["full-state-swap"] if args.full_state_swap else [])
    map_selection = [0, 9, 18, 19, 28, 37, 38, 47, 66, 76]

    def score_output(entry, mode, lead, draws, gold, climate, channels, field_mask):
        key = (entry["name"], str(lead))
        if mode == "recipient":
            paired_draws[key] = draws.copy()
        values = field_metrics(
            draws, gold, climate, field_mask, grid["lat"], paired_draws[key]
        )
        rows.extend(
            metric_rows(
                values,
                channels,
                case=entry["name"],
                source=entry["source"],
                intervention=mode,
                lead=lead,
            )
        )

    with torch.inference_mode():
        for entry in prepared["cases"]:
            if time.monotonic() - started > args.max_seconds:
                raise TimeoutError("Diagnostic wall-time budget exhausted")
            case_start = time.monotonic()
            paired_draws = {}
            with np.load(args.prepared / (entry["name"] + ".npz")) as source:
                values = dict(source)
            weights = values["month_weights"]
            if (
                len(weights) != len(values["atmosphere"]) - 19
                or len(weights) < 6
                or not np.isfinite(weights).all()
                or (weights < 0).any()
                or not np.isclose(weights.sum(), 1)
            ):
                raise ValueError("Invalid calendar-month forecast weights")
            sample = {
                k: torch.as_tensor(values[k], device=device, dtype=torch.float32)[None]
                for k in ("surface", "atmosphere", "contexts", "validity")
            }
            donor = {
                k: torch.as_tensor(
                    values["donor_" + k], device=device, dtype=torch.float32
                )[None]
                for k in ("surface", "validity")
            }
            with torch.autocast("cuda", dtype=torch.bfloat16):
                recipient = initialize(model, sample, mask, seed=entry["seed"])
                changed = initialize(
                    model, sample, mask, seed=entry["seed"], donor=donor
                )
            states = {
                "recipient": recipient,
                "input-swap": changed,
                "interior-swap": swap_interior(recipient, changed),
            }
            if args.full_state_swap:
                # Same donor initialization as input-swap: a deliberate identity check.
                states["full-state-swap"] = changed
            for mode in modes:
                state = states[mode]
                if not torch.isfinite(state).all():
                    raise ValueError("Nonfinite initialized state")
                steps = {0: state[:, -1].float()}
                monthly = torch.zeros_like(steps[0])
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    for lead, prediction in enumerate(
                        trajectory(model, state, sample, mask), 1
                    ):
                        if time.monotonic() - started > args.max_seconds:
                            raise TimeoutError("Diagnostic wall-time budget exhausted")
                        if not torch.isfinite(prediction).all():
                            raise ValueError("Nonfinite forecast")
                        monthly += prediction * float(values["month_weights"][lead - 1])
                        if lead in (1, 3, 6):
                            steps[lead] = prediction
                for lead, prediction in steps.items():
                    draws = (prediction * std + mean).cpu().numpy()
                    m = month_index(values["midpoints"][18 + lead])
                    if entry["source"] == "om4":
                        gold = values["gold"][[0, 1, 3, 6].index(lead)]
                        climate = om4_climate[m]
                        score_output(
                            entry,
                            mode,
                            lead * 5,
                            draws,
                            gold,
                            climate,
                            NAMES,
                            grid["mask"],
                        )
                        if lead == 0:
                            ids = map_selection
                            save_maps(
                                args.output,
                                entry["name"] + "-" + mode,
                                draws[:, ids],
                                np.where(grid["mask"][ids], gold[ids], np.nan),
                                climate[ids],
                                [NAMES[i] for i in ids],
                                grid,
                            )
                    else:
                        score_output(
                            entry,
                            mode,
                            lead * 5,
                            draws[:, SURFACE],
                            values["gold_surface"][18 + lead],
                            obs_surface[m],
                            [NAMES[i] for i in SURFACE],
                            grid["mask"][SURFACE],
                        )
                if entry["source"] == "observation":
                    ids = list(range(38, 52)) + list(range(57, 71))
                    physical = (monthly * std + mean).cpu().numpy()
                    m = month_index(entry["month"])
                    interior_mask = grid["mask"][ids].copy()
                    interior_mask[0] = False  # Surface SST is scored separately.
                    score_output(
                        entry,
                        mode,
                        "calendar-month",
                        physical[:, ids],
                        values["gold_interior"],
                        obs_interior[m],
                        [NAMES[i] for i in ids],
                        interior_mask,
                    )
                    ohc = physical_ohc(physical[:, 38:57], grid["mask"][38:57])
                    ohc_climate = obs_ohc[m]
                    ohc_mask = np.isfinite(ohc).all(0) & np.isfinite(ohc_climate)
                    score_output(
                        entry,
                        mode,
                        "calendar-month-OHC",
                        ohc,
                        values["gold_ohc"],
                        ohc_climate,
                        ["ohc_0_700", "ohc_700_2000"],
                        ohc_mask,
                    )
            torch.cuda.synchronize()
            receipt = dict(case=entry["name"], seconds=time.monotonic() - case_start)
            receipts.append(receipt)
            print(json.dumps(receipt), flush=True)
            # Durable partial results never imply completion.
            write_json(
                args.output / "partial.json",
                dict(complete=False, receipts=receipts, rows=rows),
            )
    plot_depths(args.output, rows, modes)
    with (args.output / "metrics.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    write_json(
        args.output / "COMPLETE.json",
        dict(
            complete=True,
            checkpoint_sha256=digest(args.checkpoint),
            contract=saved["contract"],
            prepared_sha256=digest(args.prepared / "PREPARED.json"),
            script_sha256=digest(__file__),
            weights="ema",
            members=8,
            seed=SEED,
            modes=modes,
            receipts=receipts,
            rows=rows,
            seconds=time.monotonic() - started,
            interpretation="Paired conditioning interventions, one training seed; donor fields may be out of distribution. No causal ocean claim.",
            interior_swap="Donor surface-conditioned states use recipient ERA5/calendar/noise; both interior history states replaced, both recipient generated SST/SSH states retained.",
            optional_full_swap="Identical to input-swap by construction, not an independent intervention.",
            metrics="Cos-latitude common reference/climatology support. RMSE of ensemble mean; fair finite-ensemble CRPS. Monthly OM4 climatology from unique training frames; OBS climatology from unique training dates. Missing/zero-variance scores are null.",
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser(
        "prepare", help="CPU-only training climatology and fixed cases"
    )
    prep.add_argument("--paths", type=Path, required=True)
    prep.add_argument("--om4-gold", type=Path, required=True)
    prep.add_argument("--output", type=Path, required=True)
    run = commands.add_parser(
        "evaluate", help="Final EMA checkpoint, eight fixed members"
    )
    for key in ("prepared", "checkpoint", "output"):
        run.add_argument("--" + key, type=Path, required=True)
    run.add_argument("--max-seconds", type=float, default=9000)
    run.add_argument("--full-state-swap", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(1)
    if args.command == "prepare":
        prepare(args)
    else:
        if args.max_seconds <= 0 or args.max_seconds > 10800:
            raise ValueError(
                "Evaluation must fit the three-GPU-hour diagnostic release"
            )
        evaluate(args)


if __name__ == "__main__":
    main()
