# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Upgrade verified controls with donor ERA5, then evaluate conditioning swaps.

Run `prepare --help` first. Evaluation consumes its immutable prepared bundle.
The interventions measure model sensitivity; they do not identify ocean causality.
"""

import argparse
import csv
import hashlib
import json
import shutil
import time
from pathlib import Path

import numpy as np
import torch

SURFACE = [38, 76]
NAMES = [f"{v}_{d}" for v in ("uo", "vo", "thetao", "so") for d in range(19)] + ["zos"]
MONTHS = ["2014-01", "2014-04", "2014-05"]
SEED = 904003
MODES = ["recipient", "input-swap", "interior-state-swap", "full-state-swap"]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def dates(values):
    return np.asarray(values, dtype="datetime64[s]").astype(str).tolist()


def month_index(value):
    return int(str(value)[5:7]) - 1


def calendar_signature(values):
    """Year-free sequence; preserve month/day/time and year-boundary offsets."""
    labels = dates(values)
    year = int(labels[-1][:4])
    return [(int(x[:4]) - year, x[4:]) for x in labels]


def select_donor(recipient, candidates):
    """Most recent training-year history with exactly matching calendar bins."""
    target = dates(recipient)
    signature = calendar_signature(target)
    eligible = []
    for identity, history in candidates:
        history = dates(history)
        if (
            history[-1][:4] != target[-1][:4]
            and max(history) < "2014-01-01"
            and calendar_signature(history) == signature
        ):
            eligible.append((history[-1], identity))
    if not eligible:
        raise ValueError("No exact same-calendar training-year donor")
    return max(eligible, key=lambda x: (x[0], str(x[1])))[1]


def monthly_average(records, shape, *, cutoff="2014-01-01", strict_wet=None):
    """Unique timestamp records only; repeated windows must be byte-identical.

    Invalid observation pixels contribute no samples. No spatial fallback is used.
    Every source value is checked against the exclusive training-date cutoff.
    """
    total = np.zeros((12, *shape), dtype=np.float64)
    count = np.zeros((12, *shape), dtype=np.uint32)
    seen = {}
    for label, values in records:
        label = dates([label])[0]
        if label >= cutoff:
            raise ValueError(f"Climatology record outside training dates: {label}")
        values = np.asarray(values, dtype=np.float32)
        checksum = hashlib.sha256(values.tobytes()).hexdigest()
        if label in seen:
            if seen[label] != checksum:
                raise ValueError(f"Conflicting duplicate training timestamp: {label}")
            continue
        seen[label] = checksum
        if values.shape != tuple(shape):
            raise ValueError("Climatology field shape differs")
        valid = np.isfinite(values)
        if strict_wet is not None:
            if not valid[strict_wet].all():
                raise ValueError("Nonfinite packed training field on wet support")
            valid &= strict_wet
        m = month_index(label)
        total[m] += np.where(valid, values, 0)
        count[m] += valid
    result = np.divide(total, count, out=np.full_like(total, np.nan), where=count > 0)
    return result.astype(np.float32), count, seen


def swap_interior(recipient, donor, surface=SURFACE):
    """Swap both initialized interior states, preserving recipient surface slots."""
    if recipient.shape != donor.shape or recipient.ndim != 5 or recipient.shape[1] != 2:
        raise ValueError("Require matched member,2,channel,y,x initial states")
    result = donor.clone()
    result[:, :, surface] = recipient[:, :, surface]
    return result


def initialize(model, sample, mask, members=8, seed=SEED, donor=None):
    """Input swap replaces only surface history and its validity indicators."""
    source = sample if donor is None else donor
    condition, _, _ = model.encode_native(
        source["surface"][:, : model.history],
        sample["atmosphere"][:, : model.history],
        sample["contexts"][:, model.history - 1],
        mask,
        source["validity"][:, : model.history],
        return_anchors=False,
    )
    condition = condition.expand(members, *condition.shape[1:])
    generator = torch.Generator(device=condition.device).manual_seed(seed)
    return model.initialize(condition, None, None, mask, generator)


def initialization_states(model, recipient, donor, mask, *, members=8, seed=SEED):
    """Three paired-noise initializations generate four distinct interventions."""
    base = initialize(model, recipient, mask, members=members, seed=seed)
    input_swap = initialize(
        model, recipient, mask, members=members, seed=seed, donor=donor
    )
    independent = initialize(model, donor, mask, members=members, seed=seed)
    return {
        "recipient": base,
        "input-swap": input_swap,
        "interior-state-swap": swap_interior(base, independent, surface=model.surface),
        "full-state-swap": independent,
    }


def initial_perturbations(states, mask, lat, std, *, case, names):
    """Report input perturbation sizes in both physical history slots.

    Paired member changes expose a weak intervention even when later forecast
    differences are small. The ensemble-mean change is reported separately.
    """
    weight = mask * torch.cos(torch.deg2rad(lat))[None, :, None]
    denominator = weight.sum((-2, -1))
    if (denominator <= 0).any():
        raise ValueError("Empty initial-state diagnostic support")
    base = states["recipient"].float()
    rows = []
    for mode, state in states.items():
        difference = (state.float() - base) * std
        member_rms = (
            ((difference.square() * weight).sum((-2, -1)) / denominator).mean(0).sqrt()
        )
        mean_rms = (
            (difference.mean(0).square() * weight).sum((-2, -1)) / denominator
        ).sqrt()
        for slot in range(2):
            for channel, name in enumerate(names):
                rows.append(
                    dict(
                        case=case,
                        intervention=mode,
                        history_slot=slot,
                        channel=name,
                        paired_member_change_rmse=member_rms[slot, channel].item(),
                        paired_mean_change_rmse=mean_rms[slot, channel].item(),
                    )
                )
    return rows


def trajectory(model, initial, sample, mask, seed=SEED):
    """Continue a fixed initial state with only recipient forcing/calendar."""
    state = initial
    generator = torch.Generator(device=state.device).manual_seed(seed)
    for step in range(model.history, sample["atmosphere"].shape[1]):
        state = model.advance(
            state,
            sample["atmosphere"][:, step].expand(len(state), -1, -1, -1),
            sample["contexts"][:, step].expand(len(state), -1, -1, -1),
            mask,
            generator,
        )
        yield state[:, -1].float()


def field_metrics(draws, gold, climate, mask, lat, paired=None):
    """Common-reference support, cos-latitude means; missing metrics are null.

    Anomaly correlation is spatial centered correlation after subtracting the
    training monthly climatology at each grid cell. Anomaly error equals raw
    error algebraically; skill is 1 - model MSE / climatology MSE.
    """
    x, y, c = [np.asarray(v, dtype=np.float64) for v in (draws, gold, climate)]
    if x.ndim != 4 or x.shape[1:] != y.shape or y.shape != c.shape or len(x) < 2:
        raise ValueError("Need matched ensemble and reference/climatology fields")
    valid = np.asarray(mask, bool) & np.isfinite(y) & np.isfinite(c)
    if not np.isfinite(x[:, valid]).all():
        raise ValueError("Nonfinite prediction on fixed reference/climatology support")
    x, y, c = (np.where(valid, v, 0) for v in (x, y, c))
    w = valid * np.cos(np.deg2rad(lat))[None, :, None]
    den = w.sum((-2, -1))

    def avg(v):
        return np.divide(
            (v * w).sum((-2, -1)), den, out=np.full(v.shape[:-2], np.nan), where=den > 0
        )

    def corr(a, b):
        a = a - avg(a)[..., None, None]
        b = b - avg(b)[..., None, None]
        var = np.sqrt(avg(a * a) * avg(b * b))
        return np.divide(avg(a * b), var, out=np.full_like(var, np.nan), where=var > 0)

    if paired is None:
        paired = draws
    paired = np.asarray(paired, dtype=np.float64)
    if paired.shape != x.shape or not np.isfinite(paired[:, valid]).all():
        raise ValueError("Invalid paired recipient ensemble")
    paired = np.where(valid, paired, 0)
    mean = x.mean(0)
    mse, cmse = avg((mean - y) ** 2), avg((c - y) ** 2)
    pair = sum(np.abs(x[i] - x[j]) for i in range(len(x)) for j in range(i))
    crps = avg(np.abs(x - y).mean(0) - pair / (len(x) * (len(x) - 1)))
    return dict(
        mean_mse=mse,
        rmse=np.sqrt(mse),
        climatology_mse=cmse,
        climatology_rmse=np.sqrt(cmse),
        fair_crps=crps,
        climatology_mae=avg(np.abs(c - y)),
        bias=avg(mean - y),
        mse_skill=1
        - np.divide(mse, cmse, out=np.full_like(mse, np.nan), where=cmse > 0),
        correlation=corr(mean, y),
        anomaly_correlation=corr(mean - c, y - c),
        anomaly_gold_power=avg((y - c) ** 2),
        anomaly_mean_power=avg((mean - c) ** 2),
        anomaly_member_power=avg((x - c) ** 2).mean(0),
        member_mse=avg((x - y) ** 2).mean(0),
        spread_variance=avg(x.var(0, ddof=1)),
        paired_member_change_rmse=np.sqrt(avg((x - paired) ** 2).mean(0)),
        paired_mean_change_rmse=np.sqrt(avg((mean - paired.mean(0)) ** 2)),
        support_weight=den,
    )


def metric_rows(values, names, **identity):
    return [
        dict(
            identity,
            channel=name,
            **{
                key: float(value[i]) if np.isfinite(value[i]) else None
                for key, value in values.items()
            },
        )
        for i, name in enumerate(names)
    ]


def validate_checkpoint(saved, prepared):
    c = saved["contract"]
    expected = dict(
        arm="B",
        forcing_mode="direct",
        objective="fair-crps",
        initializer_widths=[96, 192, 384],
        initializer_blocks=3,
        widths=[64, 128, 256],
        velocity_init_signed_crps_weight=1.0,
        seed=1729,
        grid=prepared["grid_sha256"],
        om4_window_mode="native-30day",
    )
    if saved["step"] != 8000 or saved["counts"] != {"om4": 4000, "observation": 4000}:
        raise ValueError("Require final 8000-update mixed checkpoint")
    if any(c.get(key) != value for key, value in expected.items()):
        raise ValueError("Checkpoint architecture/objective/grid contract differs")
    for key in (
        "statistics",
        "packed_proof",
        "observation_manifest",
        "shared_era5_proof",
    ):
        expected_sha = prepared.get(key + "_sha256")
        if not expected_sha or c.get(key) != expected_sha:
            raise ValueError(f"Checkpoint {key} differs from prepared inputs")
    for key in ("window_count", "windows_sha256", "required_source_intervals_sha256"):
        if c.get("om4_cohort", {}).get(key) != prepared["cohort"][key]:
            raise ValueError("Checkpoint training cohort differs from climatology")


def normalize_surface(values, grid):
    mask = grid["mask"][SURFACE]
    valid = np.isfinite(values) & mask
    result = np.where(
        valid,
        (values - grid["mean"][SURFACE, None, None]) / grid["std"][SURFACE, None, None],
        0,
    ).astype(np.float32)
    return result, valid


def observation_training_records(paths, key, spatial_shape):
    """Read target-native records; OHC never passes through interpolated T levels."""
    if key not in ("surface", "interior", "ohc"):
        raise ValueError("Unknown observation climatology field")
    channels = 28 if key == "interior" else 2
    for path in paths:
        with np.load(path) as saved:
            if key == "surface":
                yield from zip(dates(saved["midpoints"]), saved[key], strict=True)
            else:
                yield path.stem + "-15", saved[key].reshape(channels, *spatial_shape)


def verified_reuse(root, expected_sha):
    """Require a pinned preparation manifest, its successful readback receipt,
    and another complete byte readback before reusing any fields or climates.
    """
    prepared_path = root / "PREPARED.json"
    if digest(prepared_path) != expected_sha:
        raise ValueError("Reused preparation manifest pin differs")
    prepared = json.loads(prepared_path.read_text())
    verified = json.loads((root / "VERIFIED.json").read_text())
    if (
        not prepared.get("complete")
        or not verified.get("complete")
        or not verified.get("all_output_files_readback")
        or verified.get("prepared_sha256") != expected_sha
    ):
        raise ValueError("Reused preparation lacks successful readback proof")
    for name, checksum in prepared["files"].items():
        if digest(root / name) != checksum:
            raise ValueError("Reused prepared file changed: " + name)
    return prepared


def check_input_pins(previous, current):
    for key, checksum in current.items():
        if previous.get(key) != checksum:
            raise ValueError("Climatology source provenance changed: " + key)


def donor_history_check(recipient_dates, donor_dates):
    recipient_dates, donor_dates = dates(recipient_dates), dates(donor_dates)
    if (
        len(recipient_dates) != 19
        or len(donor_dates) != 19
        or calendar_signature(recipient_dates) != calendar_signature(donor_dates)
        or recipient_dates[-1][:4] == donor_dates[-1][:4]
        or max(donor_dates) >= "2014-01-01"
    ):
        raise ValueError("Donor history is not exact-calendar training-year history")


def prepare(args):
    from samudra.experiments.monthly_model_data import ModelMonths, calendar_context
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.shared_era5 import SharedEra5
    from samudra.experiments.stochastic_om4_windows import build_five_day_om4_windows

    if args.output.resolve() == args.reuse_prepared.resolve():
        raise ValueError("Revision2 output must differ from immutable parent")
    previous = verified_reuse(args.reuse_prepared, args.reuse_prepared_sha256)
    if previous["schema"] != "stochastic-conditioning-v1":
        raise ValueError("Revision2 requires the original verified preparation")
    paths = json.loads(args.paths.read_text())
    root, packed_root = Path(paths["samples"]), Path(paths["packed_om4"])
    pins = dict(
        grid_sha256=digest(root / "grid.npz"),
        statistics_sha256=digest(root / "statistics.npz"),
        observation_manifest_sha256=digest(root / "SHA256SUMS"),
        packed_proof_sha256=digest(packed_root / "COMPLETE.json"),
    )
    check_input_pins(previous, pins)
    # A manifest hash alone does not establish that its named training files
    # remain identical. Recheck the actual sources used by the reused climates.
    for path, checksum in previous["train_sample_sha256"].items():
        if digest(path) != checksum:
            raise ValueError("Training observation sample changed: " + path)
    data = Samples(root, "cpu", surface_fill="zero", global_observations=True)
    reader = ModelMonths(
        Path(paths["om4"]) / "OM4.zarr",
        "om4",
        data.grid,
        Path(paths["om4"]),
        packed=packed_root,
    )
    windows, cohort = build_five_day_om4_windows(reader)
    if (
        cohort != previous["cohort"]
        or cohort["window_count"] != 2548
        or cohort["required_frame_count"] != 2812
    ):
        raise ValueError("Training cohort changed from reused climatology")
    reader.windows = windows
    forcing = SharedEra5(
        paths["forcing_cache"],
        reader,
        data,
        paths["forcing_proof_sha256"],
        full_readback=True,
    )
    start_to_window = {start: index for index, (start, _, _, _) in enumerate(windows)}
    args.output.mkdir(parents=True, exist_ok=False)
    for name in ("grid.npz", "om4-climatology.npz", "observation-climatology.npz"):
        shutil.copyfile(args.reuse_prepared / name, args.output / name)
        if digest(args.output / name) != previous["files"][name]:
            raise ValueError("Reused climate copy differs: " + name)
    cases = []
    checked_frames = set()
    for original in previous["cases"]:
        entry = dict(original)
        with np.load(args.reuse_prepared / (entry["name"] + ".npz")) as saved:
            payload = dict(saved)
        if entry["source"] == "observation":
            donor_path = Path(entry["donor"])
            if str(donor_path) not in previous["train_sample_sha256"]:
                raise ValueError("Observation donor is outside frozen training cohort")
            donor = data.load(donor_path)
            donor_dates = dates(donor["raw"]["midpoints"][:19])
            atmosphere = donor["atmosphere"][0, :19].numpy().copy()
            contexts = donor["contexts"][0, :19].numpy().copy()
            # Reconstruct exactly the frozen donor surface, checking consistency
            # with the parent bundle independently of the new ERA5 inputs.
            np.testing.assert_array_equal(
                donor["surface"][0, :19].numpy(), payload["donor_surface"]
            )
            np.testing.assert_array_equal(
                donor["validity"][0, :19].numpy(), payload["donor_validity"]
            )
            entry["donor_sample_sha256"] = previous["train_sample_sha256"][
                str(donor_path)
            ]
            data.read_sample.cache_clear()
        else:
            indices = entry["donor_indices"]
            start = indices[-1] + 1
            if (
                indices != list(range(start - 19, start))
                or start not in start_to_window
            ):
                raise ValueError("OM4 donor is not an existing dense training window")
            for index in indices:
                offset = reader.packed_indices[index]
                if index not in checked_frames:
                    if (
                        hashlib.sha256(reader.packed[offset].tobytes()).hexdigest()
                        != reader.packed_hashes[offset]
                    ):
                        raise ValueError("OM4 donor frame changed")
                    checked_frames.add(index)
            donor_surface = np.stack(
                [reader.packed[reader.packed_indices[i]][SURFACE] for i in indices]
            )
            normalized, valid = normalize_surface(donor_surface, data.grid)
            np.testing.assert_array_equal(normalized, payload["donor_surface"])
            np.testing.assert_array_equal(valid, payload["donor_validity"])
            window_index = start_to_window[start]
            atmosphere = forcing.load(reader, window_index, data)[0, :19].numpy().copy()
            donor_dates = dates(reader.midpoints[start - 19 : start])
            contexts = calendar_context(
                reader.lat, reader.lon, reader.midpoints[start - 19 : start]
            )
            entry["donor_forcing_indices"] = indices
            entry["donor_dense_window_index"] = window_index
        donor_history_check(payload["midpoints"][:19], donor_dates)
        if (
            atmosphere.shape != (19, 8, *data.grid["mask"].shape[-2:])
            or not np.isfinite(atmosphere).all()
        ):
            raise ValueError("Invalid exact donor ERA5 history")
        if (
            contexts.shape != (19, 5, *data.grid["mask"].shape[-2:])
            or not np.isfinite(contexts).all()
        ):
            raise ValueError("Invalid donor calendar history")
        payload.update(
            donor_atmosphere=atmosphere,
            donor_contexts=contexts,
            donor_midpoints=np.array(donor_dates),
        )
        entry.update(
            donor_dates=donor_dates,
            donor_initialization="donor-year surface/validity, exact donor-year ERA5 and actual donor-date calendar",
        )
        np.savez(args.output / (entry["name"] + ".npz"), **payload)
        cases.append(entry)
        print(
            json.dumps(dict(stage="prepared-independent-donor", case=entry["name"])),
            flush=True,
        )
    files = {p.name: digest(p) for p in sorted(args.output.glob("*.npz"))}
    result = dict(
        previous,
        schema="stochastic-conditioning-v2",
        cases=cases,
        files=files,
        script_sha256=digest(__file__),
        shared_era5_proof_sha256=paths["forcing_proof_sha256"],
        reused_prepared=str(args.reuse_prepared),
        reused_prepared_sha256=args.reuse_prepared_sha256,
        reused_verified_sha256=digest(args.reuse_prepared / "VERIFIED.json"),
        reused_files_full_readback=True,
        donor_packed_frames_verified=len(checked_frames),
        donor_era5_full_readback=True,
        interventions="input-swap: donor surface/validity only with recipient forcing/calendar; independent donor state: donor surface/validity/forcing/calendar with paired noise; state swaps advance with recipient future forcing/calendar",
    )
    write_json(args.output / "PREPARED.json", result)


def physical_ohc(temperature, mask):
    """Native-layer OHC, J/m2, requiring every contributing level to be present.

    Accept 14 observed or 19 model levels. Missing deep values never receive a
    climatological fallback. These layers end at 2000 m, within the first 14 slots.
    """
    from samudra.constants import build_om4_layout
    from samudra.metrics.kernels import CP, OHC_LAYERS, RHO

    x = np.asarray(temperature, dtype=np.float64)
    dz = np.asarray(build_om4_layout().depth_thickness[: x.shape[-3]])
    edges = np.concatenate([[0.0], np.cumsum(dz)])
    maps = []
    for layer in OHC_LAYERS:
        overlap = np.maximum(
            0,
            np.minimum(edges[1:], layer.max_depth)
            - np.maximum(edges[:-1], layer.min_depth),
        )
        if not np.isclose(overlap.sum(), layer.max_depth - layer.min_depth):
            raise ValueError("Temperature axis does not span OHC layer")
        used = overlap > 0
        valid = np.isfinite(x[..., used, :, :]) & np.asarray(mask, bool)[used]
        complete = valid.all(-3)
        total = (
            np.where(valid, x[..., used, :, :], 0) * overlap[used, None, None]
        ).sum(-3)
        maps.append(np.where(complete, total * RHO * CP, np.nan))
    return np.stack(maps, axis=-3)


def map_limits(fields, support, *, symmetric):
    """Pooled robust bounds for comparable maps; missing pixels never set scale."""
    values = np.stack(fields)[:, support]
    values = values[np.isfinite(values)]
    if not len(values):
        return (-1.0, 1.0)
    if symmetric:
        limit = max(float(np.percentile(np.abs(values), 99)), 1e-12)
        return (-limit, limit)
    low, high = np.percentile(values, [1, 99])
    if high <= low:
        padding = max(abs(float(low)) * 1e-6, 1e-12)
        low, high = low - padding, high + padding
    return float(low), float(high)


def save_maps(output, name, draws, gold, climate, names, grid):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    mean = draws.mean(0)
    error = mean - gold
    anomaly_gold, anomaly_mean, anomaly_member = (
        gold - climate,
        mean - climate,
        draws[0] - climate,
    )
    physical_limits, error_limits, anomaly_limits, units = [], [], [], []
    fig, axes = plt.subplots(
        len(names), 5, figsize=(17, 2.7 * len(names)), squeeze=False
    )
    anomaly_fig, anomaly_axes = plt.subplots(
        len(names), 3, figsize=(12, 2.7 * len(names)), squeeze=False
    )
    extent = [grid["lon"][0], grid["lon"][-1], grid["lat"][0], grid["lat"][-1]]

    def panel(figure, ax, field, support, title, limits, unit, cmap):
        im = ax.imshow(
            np.where(support, field, np.nan),
            origin="lower",
            cmap=cmap,
            vmin=limits[0],
            vmax=limits[1],
            extent=extent,
            aspect="auto",
        )
        ax.set_title(f"{title}\n[{limits[0]:.4g}, {limits[1]:.4g}] {unit}", fontsize=8)
        colorbar = figure.colorbar(im, ax=ax, shrink=0.7, extend="both")
        colorbar.set_label(unit, fontsize=7)

    for i, channel in enumerate(names):
        support = np.isfinite(gold[i]) & np.isfinite(climate[i])
        velocity = channel.startswith(("uo_", "vo_"))
        unit = (
            "m/s"
            if velocity
            else "degC"
            if channel.startswith("thetao_")
            else "psu"
            if channel.startswith("so_")
            else "m"
        )
        units.append(unit)
        physical = [gold[i], climate[i], mean[i], draws[0, i]]
        anomalies = [anomaly_gold[i], anomaly_mean[i], anomaly_member[i]]
        physical_limits.append(map_limits(physical, support, symmetric=velocity))
        error_limits.append(map_limits([error[i]], support, symmetric=True))
        anomaly_limits.append(map_limits(anomalies, support, symmetric=True))
        for j, (field, label) in enumerate(
            zip(
                physical,
                ["reference", "training climate", "ensemble mean", "member 0"],
                strict=True,
            )
        ):
            panel(
                fig,
                axes[i, j],
                field,
                support,
                channel + ": " + label,
                physical_limits[-1],
                unit,
                "RdBu_r" if velocity else "viridis",
            )
        panel(
            fig,
            axes[i, 4],
            error[i],
            support,
            channel + ": mean error",
            error_limits[-1],
            unit,
            "RdBu_r",
        )
        for j, (field, label) in enumerate(
            zip(
                anomalies,
                ["reference - climate", "mean - climate", "member 0 - climate"],
                strict=True,
            )
        ):
            panel(
                anomaly_fig,
                anomaly_axes[i, j],
                field,
                support,
                channel + ": " + label,
                anomaly_limits[-1],
                unit,
                "RdBu_r",
            )
    fig.suptitle(
        "First four panels share row limits; mean error has its own zero-centered scale.\nLimits clip pooled 1st/99th percentiles (velocity: 99th absolute); error: 99th absolute.",
        fontsize=9,
    )
    anomaly_fig.suptitle(
        "Anomalies relative to training monthly climatology; each row shares a zero-centered scale.\nLimits clip the pooled 99th absolute percentile of the three anomaly fields.",
        fontsize=9,
    )
    for figure, suffix in ((fig, ""), (anomaly_fig, "-anomalies")):
        figure.tight_layout(rect=(0, 0, 1, 0.97))
        figure.savefig(output / (name + suffix + ".png"), dpi=110)
        plt.close(figure)
    np.savez_compressed(
        output / (name + ".npz"),
        members=draws,
        reference=gold,
        climatology=climate,
        names=names,
        units=units,
        mean_error=error,
        reference_anomaly=anomaly_gold,
        mean_anomaly=anomaly_mean,
        member0_anomaly=anomaly_member,
        physical_limits=physical_limits,
        error_limits=error_limits,
        anomaly_limits=anomaly_limits,
    )


def plot_depths(output, rows, modes):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from samudra.constants import build_om4_layout

    depths = build_om4_layout().depth_levels
    fig, axes = plt.subplots(2, 4, figsize=(15, 9), sharey=True)
    for row, variable in enumerate(("uo", "vo")):
        for col, metric in enumerate(
            ("rmse", "mse_skill", "anomaly_correlation", "paired_member_change_rmse")
        ):
            ax = axes[row, col]
            for mode in modes:
                values = []
                for depth in range(19):
                    selected = [
                        r
                        for r in rows
                        if r["source"] == "om4"
                        and r["lead"] == 0
                        and r["intervention"] == mode
                        and r["channel"] == f"{variable}_{depth}"
                    ]
                    if metric == "rmse":
                        value = np.sqrt(np.mean([r["mean_mse"] for r in selected]))
                    elif metric == "mse_skill":
                        value = 1 - np.mean(
                            [r["mean_mse"] for r in selected]
                        ) / np.mean([r["climatology_mse"] for r in selected])
                    else:
                        finite = [r[metric] for r in selected if r[metric] is not None]
                        value = np.mean(finite) if finite else np.nan
                    values.append(value)
                ax.plot(values, depths, label=mode)
            ax.set_title(variable + " " + metric, fontsize=9)
            ax.grid(alpha=0.25)
            ax.set_xlabel("m/s" if metric.endswith("rmse") else "dimensionless")
        axes[row, 0].set_ylabel("Depth (m)")
    axes[0, 0].invert_yaxis()
    axes[0, 0].legend(fontsize=7)
    fig.suptitle(
        "Three OM4 initializer cases; training monthly climatology; fixed member noise"
    )
    fig.tight_layout()
    fig.savefig(output / "all-depths.png", dpi=140)
    fig.savefig(output / "all-depths.pdf")
    plt.close(fig)


def evaluate(args):
    from types import SimpleNamespace

    from samudra.experiments.stochastic_transition_train import build_model

    started = time.monotonic()
    args.output.mkdir(parents=True, exist_ok=False)
    prepared = json.loads((args.prepared / "PREPARED.json").read_text())
    if prepared.get("schema") != "stochastic-conditioning-v2":
        raise ValueError(
            "Independent state swaps require revision2 donor ERA5 histories"
        )
    for name, checksum in prepared["files"].items():
        if digest(args.prepared / name) != checksum:
            raise ValueError(f"Prepared input changed: {name}")
    grid = dict(np.load(args.prepared / "grid.npz"))
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    validate_checkpoint(saved, prepared)
    device = "cuda"
    model = build_model(
        saved, SimpleNamespace(grid=grid, device=device), use_ema=True
    ).eval()
    if (
        model.forcing_channels != 8
        or model.forcing_mode != "direct"
        or model.arm != "B"
    ):
        raise ValueError("Require direct-eight deterministic processor contract")
    mask = torch.as_tensor(grid["mask"], device=device)
    mean = torch.as_tensor(grid["mean"][:, None, None], device=device)
    std = torch.as_tensor(grid["std"][:, None, None], device=device)
    with np.load(args.prepared / "om4-climatology.npz") as source:
        om4_climate = source["mean"]
    with np.load(args.prepared / "observation-climatology.npz") as source:
        obs_surface, obs_interior, obs_ohc = (
            source["surface"],
            source["interior"],
            source["ohc"],
        )
    rows, receipts, perturbations = [], [], []
    modes = MODES
    map_selection = [0, 9, 18, 19, 28, 37, 38, 47, 66, 76]

    def score_output(entry, mode, lead, draws, gold, climate, channels, field_mask):
        key = (entry["name"], str(lead))
        if mode == "recipient":
            paired_draws[key] = draws.copy()
        values = field_metrics(
            draws, gold, climate, field_mask, grid["lat"], paired_draws[key]
        )
        rows.extend(
            metric_rows(
                values,
                channels,
                case=entry["name"],
                source=entry["source"],
                intervention=mode,
                lead=lead,
            )
        )

    with torch.inference_mode():
        for entry in prepared["cases"]:
            if time.monotonic() - started > args.max_seconds:
                raise TimeoutError("Diagnostic wall-time budget exhausted")
            case_start = time.monotonic()
            paired_draws = {}
            with np.load(args.prepared / (entry["name"] + ".npz")) as source:
                values = dict(source)
            weights = values["month_weights"]
            if (
                len(weights) != len(values["atmosphere"]) - 19
                or len(weights) < 6
                or not np.isfinite(weights).all()
                or (weights < 0).any()
                or not np.isclose(weights.sum(), 1)
            ):
                raise ValueError("Invalid calendar-month forecast weights")
            sample = {
                k: torch.as_tensor(values[k], device=device, dtype=torch.float32)[None]
                for k in ("surface", "atmosphere", "contexts", "validity")
            }
            donor = {
                k: torch.as_tensor(
                    values["donor_" + k], device=device, dtype=torch.float32
                )[None]
                for k in ("surface", "validity", "atmosphere", "contexts")
            }
            with torch.autocast("cuda", dtype=torch.bfloat16):
                states = initialization_states(
                    model, sample, donor, mask, seed=entry["seed"]
                )
            perturbations.extend(
                initial_perturbations(
                    states,
                    mask,
                    torch.as_tensor(grid["lat"], device=device),
                    std,
                    case=entry["name"],
                    names=NAMES,
                )
            )
            for mode in modes:
                state = states[mode]
                if not torch.isfinite(state).all():
                    raise ValueError("Nonfinite initialized state")
                steps = {0: state[:, -1].float()}
                monthly = torch.zeros_like(steps[0])
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    for lead, prediction in enumerate(
                        trajectory(model, state, sample, mask), 1
                    ):
                        if time.monotonic() - started > args.max_seconds:
                            raise TimeoutError("Diagnostic wall-time budget exhausted")
                        if not torch.isfinite(prediction).all():
                            raise ValueError("Nonfinite forecast")
                        monthly += prediction * float(values["month_weights"][lead - 1])
                        if lead in (1, 3, 6):
                            steps[lead] = prediction
                for lead, prediction in steps.items():
                    draws = (prediction * std + mean).cpu().numpy()
                    m = month_index(values["midpoints"][18 + lead])
                    if entry["source"] == "om4":
                        gold = values["gold"][[0, 1, 3, 6].index(lead)]
                        climate = om4_climate[m]
                        score_output(
                            entry,
                            mode,
                            lead * 5,
                            draws,
                            gold,
                            climate,
                            NAMES,
                            grid["mask"],
                        )
                        if lead == 0:
                            ids = map_selection
                            save_maps(
                                args.output,
                                entry["name"] + "-" + mode,
                                draws[:, ids],
                                np.where(grid["mask"][ids], gold[ids], np.nan),
                                climate[ids],
                                [NAMES[i] for i in ids],
                                grid,
                            )
                    else:
                        score_output(
                            entry,
                            mode,
                            lead * 5,
                            draws[:, SURFACE],
                            values["gold_surface"][18 + lead],
                            obs_surface[m],
                            [NAMES[i] for i in SURFACE],
                            grid["mask"][SURFACE],
                        )
                if entry["source"] == "observation":
                    ids = list(range(38, 52)) + list(range(57, 71))
                    physical = (monthly * std + mean).cpu().numpy()
                    m = month_index(entry["month"])
                    interior_mask = grid["mask"][ids].copy()
                    interior_mask[0] = False  # Surface SST is scored separately.
                    score_output(
                        entry,
                        mode,
                        "calendar-month",
                        physical[:, ids],
                        values["gold_interior"],
                        obs_interior[m],
                        [NAMES[i] for i in ids],
                        interior_mask,
                    )
                    ohc = physical_ohc(physical[:, 38:57], grid["mask"][38:57])
                    ohc_climate = obs_ohc[m]
                    ohc_mask = np.isfinite(ohc).all(0) & np.isfinite(ohc_climate)
                    score_output(
                        entry,
                        mode,
                        "calendar-month-OHC",
                        ohc,
                        values["gold_ohc"],
                        ohc_climate,
                        ["ohc_0_700", "ohc_700_2000"],
                        ohc_mask,
                    )
            torch.cuda.synchronize()
            receipt = dict(case=entry["name"], seconds=time.monotonic() - case_start)
            receipts.append(receipt)
            print(json.dumps(receipt), flush=True)
            # Durable partial results never imply completion.
            write_json(
                args.output / "partial.json",
                dict(
                    complete=False,
                    receipts=receipts,
                    rows=rows,
                    initial_perturbations=perturbations,
                ),
            )
    plot_depths(args.output, rows, modes)
    with (args.output / "metrics.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (args.output / "initial-perturbations.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(perturbations[0]))
        writer.writeheader()
        writer.writerows(perturbations)
    write_json(
        args.output / "COMPLETE.json",
        dict(
            complete=True,
            checkpoint_sha256=digest(args.checkpoint),
            contract=saved["contract"],
            prepared_sha256=digest(args.prepared / "PREPARED.json"),
            script_sha256=digest(__file__),
            weights="ema",
            members=8,
            seed=SEED,
            modes=modes,
            receipts=receipts,
            rows=rows,
            initial_perturbations=perturbations,
            seconds=time.monotonic() - started,
            interpretation="Paired conditioning interventions, one training seed; donor fields may be out of distribution. No causal ocean claim.",
            interior_swap="Independent donor-year initialization uses donor surface/validity, donor ERA5 and actual donor-date calendar with paired noise. Both interior history states replaced; both recipient generated SST/SSH states retained. All future ERA5/calendar stay recipient.",
            full_state_swap="Both complete initial history states from the independent donor-year initialization; all future forcing/calendar stay recipient.",
            metrics="Cos-latitude common reference/climatology support. RMSE of ensemble mean; fair finite-ensemble CRPS. Monthly OM4 climatology from unique training frames; OBS climatology from unique training dates. Missing/zero-variance scores are null.",
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser(
        "prepare",
        help="CPU-only revision of verified cases; reuse training climatology",
    )
    prep.add_argument("--paths", type=Path, required=True)
    prep.add_argument("--reuse-prepared", type=Path, required=True)
    prep.add_argument("--reuse-prepared-sha256", required=True)
    prep.add_argument("--output", type=Path, required=True)
    run = commands.add_parser(
        "evaluate", help="Final EMA checkpoint, eight fixed members"
    )
    for key in ("prepared", "checkpoint", "output"):
        run.add_argument("--" + key, type=Path, required=True)
    run.add_argument("--max-seconds", type=float, default=9000)
    args = parser.parse_args()
    torch.set_num_threads(1)
    if args.command == "prepare":
        prepare(args)
    else:
        if args.max_seconds <= 0 or args.max_seconds > 10800:
            raise ValueError(
                "Evaluation must fit the three-GPU-hour diagnostic release"
            )
        evaluate(args)


if __name__ == "__main__":
    main()
