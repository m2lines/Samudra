"""Bounded evaluation of immutable dense/direct signed checkpoints; no training."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
import torch
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--steps',type=int,nargs='+',required=True);p.add_argument('--forecast-step',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
torch.set_num_threads(1)
sys.path.insert(0,'/pilot-code/scripts')
from stochastic_campaign_release import allocated_gpus,time_limit_seconds,slurm_fields
job=os.environ['SLURM_JOB_ID'];allocation=json.loads((a.root/f'allocation-{job}.json').read_text());fields=slurm_fields(allocation['raw'])
if allocation['job_id']!=job or fields['JobId']!=job or allocated_gpus(fields)!=1 or time_limit_seconds(fields['TimeLimit'])!=2700 or fields.get('Requeue')!='0':raise ValueError('Expected bounded one-GPU45min allocation without automatic requeue')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((a.root/'SOURCE.json').read_text());source=manifest['sha256']
if source!=os.environ['SAMUDRA_CODE_COMMIT'] or hashlib.sha256(json.dumps(manifest['files'],sort_keys=True).encode()).hexdigest()!=source:raise ValueError('Source identity differs')
for name,sha in manifest['files'].items():
 if digest(a.root/'code'/name)!=sha:raise ValueError(f'Source changed: {name}')
if a.output.exists():raise ValueError('Existing evaluation requires explicit recovery review')
a.output.mkdir(parents=True)
paths=json.loads((a.root/'paths.json').read_text());training=a.root/'production/B-shared-deep-wide-signed';entries=[];checks={}
for step in a.steps:
 path=training/f'step-{step:05d}.pt';saved=torch.load(path,map_location='cpu',weights_only=False,mmap=True);c=saved['contract']
 if step not in (500,1000,2000,4000,8000) or saved['step']!=step or saved['counts']!={'observation':step//2,'om4':step//2}:raise ValueError('Checkpoint exposure differs')
 expected=dict(producer=source,forcing_mode='direct',om4_window_mode='native-30day',arm='B',main_updates=8000,effective_batch=8,training_members=4,velocity_init_signed_crps_weight=1.0)
 if any(c.get(k)!=v for k,v in expected.items()) or c['om4_cohort']['window_count']!=2548:raise ValueError('Scientific checkpoint contract differs')
 for key,file in [('grid','grid.npz'),('statistics','statistics.npz'),('observation_manifest','SHA256SUMS')]:
  if c[key]!=digest(Path(paths['samples'])/file):raise ValueError('Evaluation input contract differs')
 checks[str(step)]=digest(path);entries.append(dict(variant='B-signed-direct8-dense',step=step,path=str(path)));del saved
if a.forecast_step not in a.steps:raise ValueError('Forecast checkpoint must be in initializer manifest')
manifest_path=a.output/'manifest.json';manifest_path.write_text(json.dumps(entries,indent=2)+'\n')
started=time.time()
for weights in ('ema','raw'):
 raw=['--raw']if weights=='raw'else[]
 subprocess.run([sys.executable,'/pilot-code/scripts/diagnose_stochastic_velocity_wave2.py','--manifest',str(manifest_path),'--output',str(a.output/f'initializer-{weights}'),'--data',paths['samples'],'--map-steps',*[str(s)for s in a.steps],'--map-channels','uo_0','vo_0','uo_9','vo_9','uo_18','vo_18','vo_3','vo_8','vo_10',*raw],check=True)
 subprocess.run([sys.executable,'-m','samudra.experiments.stochastic_transition_evaluate','--data',paths['samples'],'--checkpoint',str(training/f'step-{a.forecast_step:05d}.pt'),'--output',str(a.output/f'forecast-{weights}'),*raw],check=True)
for entry in entries:
 if digest(Path(entry['path']))!=checks[str(entry['step'])]:raise ValueError('Checkpoint changed during evaluation')
 for weights in ('ema','raw'):
  folder=a.output/f'initializer-{weights}';proof=json.loads((folder/'COMPLETE.json').read_text())
  if not proof['complete']:raise ValueError('Initializer evaluation incomplete')
  for month in ('2014-01','2014-04','2014-05'):
   result=json.loads((folder/f"{entry['variant']}-{entry['step']:05d}-{month}.json").read_text())
   if result['checkpoint_sha256']!=checks[str(entry['step'])] or result['weights']!=weights or result['step']!=entry['step']:raise ValueError('Initializer result identity differs')
for weights in ('ema','raw'):
 result=json.loads((a.output/f'forecast-{weights}/COMPLETE.json').read_text())
 if result['checkpoint_sha256']!=checks[str(a.forecast_step)] or result['weights']!=weights or result['step']!=a.forecast_step or result['qualification']:raise ValueError('Forecast result identity differs')
(a.output/'COMPLETE.json').write_text(json.dumps(dict(complete=True,source=source,allocation=allocation,checkpoints=checks,script_sha256=digest(Path(__file__)),seconds=time.time()-started,initializer_steps=a.steps,forecast_step=a.forecast_step,weights=['ema','raw'],members=8),indent=2)+'\n')
