# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Run the pinned final conditioning diagnostic under its campaign budget.

Host preparation captures allocation-$SLURM_JOB_ID.json with raw `scontrol show
job -o`. The release pins an accounting JSON whose `raw` field is the output of
`sacct -n -X -P --format=JobIDRaw,State,ExitCode,ElapsedRaw,AllocTRES`.
All release paths are relative to --root. No scheduler submission occurs here.
"""

import argparse
import hashlib
import json
import math
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

SOURCE = "b4f8089226e75d0a8261c5c07a92890aa612ac7e952be896f6bfb66bd51da01c"
DIAGNOSTIC = "f0754d8a3ab244d5711d5519b437d8a565daf7e2da6e2d78ebc41187f1807109"
SHORT_GPU_HOURS = 6.486666666666666
KNOWN = {"21922710": (1, 407), "21922766": (4, 155), "21946812": (1, 188)}
PRODUCTION = "21929072"
MODES = ["recipient", "input-swap", "interior-state-swap", "full-state-swap"]
TERMINAL = {
    "COMPLETED",
    "FAILED",
    "CANCELLED",
    "TIMEOUT",
    "OUT_OF_MEMORY",
    "NODE_FAIL",
    "PREEMPTED",
    "BOOT_FAIL",
    "DEADLINE",
    "REVOKED",
}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def confined(root, name, *, exists=True):
    relative = Path(name)
    root = Path(root).resolve()
    result = root / relative
    if (
        not isinstance(name, str)
        or not name
        or relative.is_absolute()
        or ".." in relative.parts
        or result.resolve() == root
        or not result.resolve().is_relative_to(root)
    ):
        raise ValueError(f"Escaping or invalid release path: {name}")
    if exists and not result.is_file():
        raise ValueError(f"Missing release file: {name}")
    return result


def check_hash(root, name, expected):
    path = confined(root, name)
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError(f"Invalid digest: {name}")
    if digest(path) != expected:
        raise ValueError(f"Digest changed: {name}")
    return path


def gpu_count(tres):
    entries = {}
    for entry in tres.split(","):
        key, value = entry.split("=", 1)
        if key in entries:
            raise ValueError("Duplicate allocation resource")
        entries[key] = value
    generic = int(entries["gres/gpu"]) if "gres/gpu" in entries else None
    typed = [int(v) for k, v in entries.items() if k.startswith("gres/gpu:")]
    count = generic if generic is not None else sum(typed)
    if count <= 0 or (typed and (min(typed) <= 0 or sum(typed) != count)):
        raise ValueError("Invalid GPU allocation")
    return count


def duration(value):
    match = re.fullmatch(r"(?:(\d+)-)?(\d+):(\d{2}):(\d{2})", value)
    if not match:
        raise ValueError("Require finite Slurm duration")
    days, hours, minutes, seconds = (int(v or 0) for v in match.groups())
    if minutes >= 60 or seconds >= 60 or (match[1] and hours >= 24):
        raise ValueError("Invalid Slurm duration")
    return days * 86400 + hours * 3600 + minutes * 60 + seconds


def validate_allocation(receipt, job):
    if not re.fullmatch(r"[0-9]+", job):
        raise ValueError("Invalid current job")
    raw = receipt["raw"]
    if len(raw.strip().splitlines()) != 1:
        raise ValueError("Require one Slurm allocation")
    fields = dict(re.findall(r"(?:^|\s)([A-Za-z][A-Za-z0-9_]*)=(\S+)", raw))
    if (
        receipt["job_id"] != job
        or fields.get("JobId") != job
        or receipt.get("fields", fields) != fields
        or gpu_count(fields["AllocTRES"]) != 1
        or fields.get("Requeue") != "0"
        or fields.get("JobState") != "RUNNING"
    ):
        raise ValueError("Expected running one-GPU allocation without requeue")
    wall = duration(fields["TimeLimit"])
    elapsed = duration(fields["RunTime"])
    if not 9300 <= wall <= 10800 or elapsed < 0 or wall - elapsed < 9120:
        raise ValueError(
            "Allocation must fit 9000-second diagnostic within three hours"
        )
    return wall - elapsed


def validate_budget(accounting, final_jobs, additional_jobs, current_job):
    rows = {}
    for line in accounting["raw"].splitlines():
        if not line.strip():
            continue
        parts = line.strip().split("|")
        if len(parts) != 5:
            raise ValueError("Unexpected accounting columns")
        job, state, exit_code, elapsed, tres = parts
        if not re.fullmatch(r"[0-9]+", job) or job in rows:
            raise ValueError("Duplicate or non-allocation accounting row")
        state = state.split()[0].rstrip("+")
        if state not in TERMINAL or not re.fullmatch(r"\d+:\d+", exit_code):
            raise ValueError("Accounting allocation is not terminal")
        if not re.fullmatch(r"\d+", elapsed):
            raise ValueError("Invalid actual elapsed seconds")
        rows[job] = dict(
            gpus=gpu_count(tres),
            elapsed_seconds=int(elapsed),
            state=state,
            exit_code=exit_code,
        )
    if not isinstance(final_jobs, list) or not isinstance(additional_jobs, list):
        raise ValueError("Require explicit final and additional job lists")
    ids = list(KNOWN) + [PRODUCTION] + final_jobs + additional_jobs
    if len(ids) != len(set(ids)) or set(rows) != set(ids) or current_job in ids:
        raise ValueError("Accounting job list omits or duplicates campaign allocations")
    for job, (gpus, seconds) in KNOWN.items():
        if (rows[job]["gpus"], rows[job]["elapsed_seconds"]) != (gpus, seconds):
            raise ValueError("Known campaign allocation differs")
    prod = rows[PRODUCTION]
    if prod["gpus"] != 1 or prod["state"] != "COMPLETED" or prod["exit_code"] != "0:0":
        raise ValueError("Production must have completed successfully on one GPU")
    if prod["elapsed_seconds"] <= 0:
        raise ValueError("Missing production runtime")
    for job in final_jobs:
        if rows[job]["state"] != "COMPLETED" or rows[job]["exit_code"] != "0:0":
            raise ValueError("Unfinished final evaluation requires its reserve")
    spent = SHORT_GPU_HOURS + sum(
        x["gpus"] * x["elapsed_seconds"] / 3600 for x in rows.values()
    )
    reserve = 0 if final_jobs else 0.75
    maximum = spent + reserve + 3.0
    if not math.isfinite(maximum) or maximum > 40:
        raise ValueError(
            "Campaign exceeds 40 GPU-hours including diagnostic and final reserves"
        )
    return dict(
        actual_prior_gpu_hours=spent,
        final_evaluation_reserve_gpu_hours=reserve,
        diagnostic_reserved_gpu_hours=3.0,
        maximum_total_gpu_hours=maximum,
        actual_allocations=rows,
    )


def validate_release(root, release, job, *, wrapper=None):
    root = Path(root).resolve()
    if release["source"] != SOURCE:
        raise ValueError("Unexpected campaign source")
    pins = release["pins"]
    prepared_name = release["prepared"]
    prepared_root = confined(root, prepared_name, exists=False)
    required = {
        "SOURCE.json",
        release["script"],
        release["checkpoint"],
        release["accounting"],
        prepared_name + "/PREPARED.json",
        prepared_name + "/VERIFIED.json",
    }
    if wrapper is not None:
        wrapper = Path(wrapper).resolve()
        if not wrapper.is_relative_to(root):
            raise ValueError("Wrapper must be staged beneath campaign root")
        required.add(str(wrapper.relative_to(root)))
    if not isinstance(pins, dict) or not required <= pins.keys():
        raise ValueError("Missing required release pins")
    for name, checksum in pins.items():
        check_hash(root, name, checksum)
    code_root = confined(root, "code", exists=False)
    if pins[release["script"]] != DIAGNOSTIC:
        raise ValueError("Expected reviewed revision2 diagnostic")
    manifest = read(root / "SOURCE.json")
    canonical = hashlib.sha256(
        json.dumps(manifest["files"], sort_keys=True).encode()
    ).hexdigest()
    if not manifest["files"] or canonical != SOURCE or manifest["sha256"] != SOURCE:
        raise ValueError("Source manifest identity differs")
    for name, checksum in manifest["files"].items():
        check_hash(code_root, name, checksum)
    prepared = read(prepared_root / "PREPARED.json")
    verified = read(prepared_root / "VERIFIED.json")
    if (
        prepared.get("schema") != "stochastic-conditioning-v2"
        or prepared.get("complete") is not True
        or verified.get("complete") is not True
        or verified.get("all_output_files_readback") is not True
        or verified.get("prepared_sha256") != pins[prepared_name + "/PREPARED.json"]
        or prepared.get("script_sha256") != DIAGNOSTIC
        or prepared.get("donor_era5_full_readback") is not True
        or prepared.get("reused_files_full_readback") is not True
    ):
        raise ValueError("Prepared inputs lack pinned successful revision2 readback")
    required_payloads = {
        "grid.npz",
        "om4-climatology.npz",
        "observation-climatology.npz",
    }
    cases = prepared["cases"]
    if (
        len(cases) != 12
        or len({c["name"] for c in cases}) != 12
        or sum(c["source"] == "om4" for c in cases) != 3
        or sum(c["source"] == "observation" for c in cases) != 9
        or any(c["seed"] != 904003 for c in cases)
    ):
        raise ValueError("Expected twelve paired-noise cases")
    required_payloads.update(c["name"] + ".npz" for c in cases)
    if not required_payloads <= prepared["files"].keys():
        raise ValueError("Missing prepared payloads")
    for name, checksum in prepared["files"].items():
        check_hash(prepared_root, name, checksum)
    output = confined(root, release["output"], exists=False)
    if any(
        output.resolve().is_relative_to(p.resolve()) for p in (code_root, prepared_root)
    ):
        raise ValueError("Output cannot modify immutable source or prepared inputs")
    if output.exists() or output.is_symlink():
        raise ValueError("Diagnostic output must be new; preserve prior attempts")
    receipt = read(confined(root, f"allocation-{job}.json"))
    remaining = validate_allocation(receipt, job)
    ledger = validate_budget(
        read(confined(root, release["accounting"])),
        release["final_evaluation_job_ids"],
        release["additional_job_ids"],
        job,
    )
    return dict(
        prepared=prepared,
        allocation=receipt,
        remaining_seconds=remaining,
        ledger=ledger,
    )


def validate_checkpoint(saved, prepared):
    c = saved["contract"]
    expected = dict(
        producer=SOURCE,
        arm="B",
        forcing_mode="direct",
        main_updates=8000,
        effective_batch=8,
        training_members=4,
        velocity_init_signed_crps_weight=1.0,
        om4_window_mode="native-30day",
    )
    if (
        saved["step"] != 8000
        or saved["counts"] != {"om4": 4000, "observation": 4000}
        or any(c.get(k) != v for k, v in expected.items())
        or c.get("om4_cohort", {}).get("window_count") != 2548
    ):
        raise ValueError("Final signed/direct/dense checkpoint contract differs")
    for key in (
        "grid",
        "statistics",
        "packed_proof",
        "observation_manifest",
        "shared_era5_proof",
    ):
        if not prepared.get(key + "_sha256") or c.get(key) != prepared[key + "_sha256"]:
            raise ValueError("Checkpoint input provenance differs: " + key)


def validate_complete(result, release, prepared):
    expected = dict(
        complete=True,
        checkpoint_sha256=release["pins"][release["checkpoint"]],
        prepared_sha256=release["pins"][release["prepared"] + "/PREPARED.json"],
        script_sha256=DIAGNOSTIC,
        modes=MODES,
        members=8,
        weights="ema",
        seed=904003,
    )
    if any(result.get(k) != v for k, v in expected.items()):
        raise ValueError("Diagnostic completion receipt identity differs")
    names = [c["name"] for c in prepared["cases"]]
    receipts = [r["case"] for r in result["receipts"]]
    if sorted(receipts) != sorted(names):
        raise ValueError("Diagnostic did not complete all twelve cases")
    for key in ("rows", "initial_perturbations"):
        got = {(r["case"], r["intervention"]) for r in result[key]}
        if got != {(name, mode) for name in names for mode in MODES}:
            raise ValueError("Diagnostic omitted an intervention")


def run_bounded(command, env, cwd, timeout):
    """Kill the entire evaluation process group on deadline; retain its files."""
    process = subprocess.Popen(command, env=env, cwd=cwd, start_new_session=True)
    try:
        returncode = process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()
        raise TimeoutError("Diagnostic exceeded hard process-group deadline") from None
    if returncode:
        raise subprocess.CalledProcessError(returncode, command)


def run(root, release_path):
    started = time.monotonic()
    root = Path(root).resolve()
    release_path = Path(release_path).resolve()
    if not release_path.is_relative_to(root):
        raise ValueError("Release must be beneath campaign root")
    release_hash = digest(release_path)
    release = read(release_path)
    job = os.environ["SLURM_JOB_ID"]
    proof = validate_release(root, release, job, wrapper=__file__)
    import torch

    checkpoint = confined(root, release["checkpoint"])
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False, mmap=True)
    validate_checkpoint(saved, proof["prepared"])
    del saved
    remaining = proof["remaining_seconds"] - (time.monotonic() - started)
    timeout = min(9300, int(remaining - 120))
    if timeout < 9000:
        raise ValueError("Preflight leaves insufficient bounded evaluation time")
    output = confined(root, release["output"], exists=False)
    command = [
        sys.executable,
        str(confined(root, release["script"])),
        "evaluate",
        "--prepared",
        str(confined(root, release["prepared"], exists=False)),
        "--checkpoint",
        str(checkpoint),
        "--output",
        str(output),
        "--max-seconds",
        "9000",
    ]
    env = dict(
        os.environ,
        PYTHONUNBUFFERED="1",
        SAMUDRA_CODE_COMMIT=SOURCE,
        PYTHONPATH=str(root / "code/src"),
        PYTHONNOUSERSITE="1",
    )
    run_start = time.monotonic()
    run_bounded(command, env, root / "code", timeout)
    # Completion cannot certify files that changed while the diagnostic ran.
    if digest(release_path) != release_hash:
        raise ValueError("Release changed during evaluation")
    for name, checksum in release["pins"].items():
        check_hash(root, name, checksum)
    for name, checksum in proof["prepared"]["files"].items():
        check_hash(root / release["prepared"], name, checksum)
    result = read(output / "COMPLETE.json")
    validate_complete(result, release, proof["prepared"])
    write(
        output / "RELEASE_COMPLETE.json",
        dict(
            complete=True,
            job_id=job,
            root=str(root),
            source=SOURCE,
            allocation=proof["allocation"],
            ledger=proof["ledger"],
            release_sha256=release_hash,
            checkpoint_sha256=digest(checkpoint),
            diagnostic_complete_sha256=digest(output / "COMPLETE.json"),
            evaluation_elapsed_seconds=time.monotonic() - run_start,
            wrapper_elapsed_seconds=time.monotonic() - started,
            wrapper_sha256=digest(__file__),
            accounting_note="Actual current-job GPU-hours require terminal sacct after exit; ledger reserves three GPU-hours.",
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    run(args.root, args.release)
