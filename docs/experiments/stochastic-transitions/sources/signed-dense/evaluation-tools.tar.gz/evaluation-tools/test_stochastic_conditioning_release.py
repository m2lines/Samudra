# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Small-file release failures, scheduler accounting, and diagnostic identity."""

import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location(
    "conditioning_release",
    Path(__file__).parents[1] / "scripts/run_stochastic_conditioning_release.py",
)
release_runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release_runner)


def accounting(*extra, production_seconds=86400):
    return {
        "raw": "\n".join(
            [
                "21922710|COMPLETED|0:0|407|cpu=4,gres/gpu=1",
                "21922766|FAILED|1:0|155|cpu=16,gres/gpu=4",
                "21946812|COMPLETED|0:0|188|cpu=4,gres/gpu=1",
                f"21929072|COMPLETED|0:0|{production_seconds}|cpu=4,gres/gpu=1",
                *extra,
            ]
        )
    }


def allocation(**changes):
    fields = dict(
        JobId="900",
        JobState="RUNNING",
        Requeue="0",
        RunTime="00:00:10",
        TimeLimit="03:00:00",
        AllocTRES="cpu=4,gres/gpu=1,gres/gpu:rtx=1",
    )
    fields.update(changes)
    return dict(
        job_id="900", fields=fields, raw=" ".join(f"{k}={v}" for k, v in fields.items())
    )


@pytest.fixture
def bundle(tmp_path, monkeypatch):
    def save(name, content):
        p = tmp_path / name
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, dict):
            release_runner.write(p, content)
        else:
            p.write_text(content)
        return release_runner.digest(p)

    source_files = {"src/model.py": save("code/src/model.py", "frozen model\n")}
    source = hashlib.sha256(
        json.dumps(source_files, sort_keys=True).encode()
    ).hexdigest()
    monkeypatch.setattr(release_runner, "SOURCE", source)
    script = save("diagnostic-tools/v2.py", "# reviewed diagnostic\n")
    monkeypatch.setattr(release_runner, "DIAGNOSTIC", script)
    save("diagnostic-tools/wrapper.py", "# released wrapper\n")
    save("SOURCE.json", dict(sha256=source, files=source_files))
    cases = [
        dict(name=f"{kind}-{i}", source=kind, seed=904003)
        for kind, count in [("om4", 3), ("observation", 9)]
        for i in range(count)
    ]
    names = ["grid.npz", "om4-climatology.npz", "observation-climatology.npz"]
    names.extend(c["name"] + ".npz" for c in cases)
    files = {name: save("prepared/" + name, name + " content") for name in names}
    prepared = dict(
        complete=True,
        schema="stochastic-conditioning-v2",
        files=files,
        cases=cases,
        script_sha256=script,
        donor_era5_full_readback=True,
        reused_files_full_readback=True,
    )
    prepared_sha = save("prepared/PREPARED.json", prepared)
    save(
        "prepared/VERIFIED.json",
        dict(
            complete=True, all_output_files_readback=True, prepared_sha256=prepared_sha
        ),
    )
    save("checkpoint.pt", "small checkpoint fixture")
    save("accounting.json", accounting())
    save("allocation-900.json", allocation())
    pins = {
        name: release_runner.digest(tmp_path / name)
        for name in [
            "SOURCE.json",
            "diagnostic-tools/v2.py",
            "diagnostic-tools/wrapper.py",
            "prepared/PREPARED.json",
            "prepared/VERIFIED.json",
            "checkpoint.pt",
            "accounting.json",
        ]
    }
    release = dict(
        source=source,
        prepared="prepared",
        checkpoint="checkpoint.pt",
        script="diagnostic-tools/v2.py",
        output="output",
        pins=pins,
        accounting="accounting.json",
        final_evaluation_job_ids=[],
        additional_job_ids=[],
    )
    return tmp_path, release, prepared


def test_valid_release_reads_every_payload_and_reconciles_actual_cost(bundle):
    root, release, _ = bundle
    proof = release_runner.validate_release(
        root, release, "900", wrapper=root / "diagnostic-tools/wrapper.py"
    )
    expected = 6.486666666666666 + (407 + 4 * 155 + 188 + 86400) / 3600 + 0.75 + 3
    assert proof["ledger"]["maximum_total_gpu_hours"] == pytest.approx(expected)
    assert proof["ledger"]["actual_allocations"]["21922766"]["state"] == "FAILED"


def test_final_actual_replaces_reserve_but_failed_attempt_also_counts():
    actual = accounting(
        "901|COMPLETED|0:0|180|gres/gpu=1", "902|TIMEOUT|0:0|1800|gres/gpu=4"
    )
    result = release_runner.validate_budget(actual, ["901"], ["902"], "900")
    assert result["final_evaluation_reserve_gpu_hours"] == 0
    expected = 6.486666666666666 + (407 + 620 + 188 + 86400 + 180 + 7200) / 3600 + 3
    assert result["maximum_total_gpu_hours"] == pytest.approx(expected)
    with pytest.raises(ValueError, match="omits or duplicates"):
        release_runner.validate_budget(actual, ["901"], [], "900")


@pytest.mark.parametrize(
    "data,final,additional",
    [
        (accounting(production_seconds=115200), [], []),
        (accounting("901|FAILED|1:0|14400|gres/gpu=2"), [], ["901"]),
    ],
)
def test_reject_over_budget_including_failed_gpu_work(data, final, additional):
    with pytest.raises(ValueError, match="40 GPU-hours"):
        release_runner.validate_budget(data, final, additional, "900")


@pytest.mark.parametrize(
    "old,new",
    [
        ("|407|", "|NaN|"),
        ("|407|", "|-1|"),
        ("|407|", "|408|"),
        ("21929072|COMPLETED", "21929072|RUNNING"),
        ("21929072|COMPLETED|0:0", "21929072|FAILED|1:0"),
    ],
)
def test_reject_fabricated_or_nonterminal_accounting(old, new):
    with pytest.raises(ValueError):
        release_runner.validate_budget(
            {"raw": accounting()["raw"].replace(old, new)}, [], [], "900"
        )


@pytest.mark.parametrize(
    "changes",
    [
        dict(AllocTRES="gres/gpu=4"),
        dict(Requeue="1"),
        dict(TimeLimit="03:00:01"),
        dict(TimeLimit="UNLIMITED"),
        dict(TimeLimit="02:00:00"),
        dict(JobState="PENDING"),
        dict(RunTime="00:45:00"),
        dict(AllocTRES="gres/gpu=1,gres/gpu:rtx=2"),
    ],
)
def test_reject_wrong_or_insufficient_scheduler_allocation(changes):
    with pytest.raises(ValueError):
        release_runner.validate_allocation(allocation(**changes), "900")


@pytest.mark.parametrize(
    "name",
    [
        "code/src/model.py",
        "prepared/observation-8.npz",
        "prepared/VERIFIED.json",
        "checkpoint.pt",
        "diagnostic-tools/v2.py",
        "accounting.json",
    ],
)
def test_reject_changed_payload_source_or_pinned_control(bundle, name):
    root, release, _ = bundle
    (root / name).write_text("changed")
    with pytest.raises(ValueError, match="Digest changed"):
        release_runner.validate_release(root, release, "900")


def test_reject_self_consistent_but_different_source_manifest(bundle):
    root, release, _ = bundle
    manifest = release_runner.read(root / "SOURCE.json")
    manifest["files"]["src/model.py"] = "a" * 64
    release_runner.write(root / "SOURCE.json", manifest)
    release["pins"]["SOURCE.json"] = release_runner.digest(root / "SOURCE.json")
    with pytest.raises(ValueError, match="Source manifest"):
        release_runner.validate_release(root, release, "900")


def test_reject_failed_readback_even_when_released_hash_matches(bundle):
    root, release, _ = bundle
    path = root / "prepared/VERIFIED.json"
    proof = release_runner.read(path)
    proof["all_output_files_readback"] = False
    release_runner.write(path, proof)
    release["pins"]["prepared/VERIFIED.json"] = release_runner.digest(path)
    with pytest.raises(ValueError, match="successful revision2 readback"):
        release_runner.validate_release(root, release, "900")


def test_paths_cannot_escape_root_or_reuse_output(bundle, tmp_path):
    root, release, _ = bundle
    outside = root.parent / (root.name + "-outside")
    outside.write_text("outside")
    (root / "escape").symlink_to(outside)
    for name in ["../" + outside.name, str(outside), "escape"]:
        with pytest.raises(ValueError, match="Escaping"):
            release_runner.confined(root, name)
    (root / "output").mkdir()
    with pytest.raises(ValueError, match="must be new"):
        release_runner.validate_release(root, release, "900")


def test_checkpoint_requires_producer_counts_contract_and_input_pins():
    prepared = {
        key + "_sha256": key + "-digest"
        for key in [
            "grid",
            "statistics",
            "packed_proof",
            "observation_manifest",
            "shared_era5_proof",
        ]
    }
    contract = dict(
        producer=release_runner.SOURCE,
        arm="B",
        forcing_mode="direct",
        main_updates=8000,
        effective_batch=8,
        training_members=4,
        velocity_init_signed_crps_weight=1.0,
        om4_window_mode="native-30day",
        om4_cohort=dict(window_count=2548),
    )
    contract.update({k.removesuffix("_sha256"): v for k, v in prepared.items()})
    saved = dict(step=8000, counts=dict(om4=4000, observation=4000), contract=contract)
    release_runner.validate_checkpoint(saved, prepared)
    saved["counts"]["om4"] = 3999
    with pytest.raises(ValueError, match="checkpoint contract"):
        release_runner.validate_checkpoint(saved, prepared)
    saved["counts"]["om4"] = 4000
    contract["producer"] = "different"
    with pytest.raises(ValueError, match="checkpoint contract"):
        release_runner.validate_checkpoint(saved, prepared)
    contract["producer"] = release_runner.SOURCE
    contract["statistics"] = "different"
    with pytest.raises(ValueError, match="provenance"):
        release_runner.validate_checkpoint(saved, prepared)


def test_completion_requires_identity_and_all_cases_and_interventions(bundle):
    _, release, prepared = bundle
    result = dict(
        complete=True,
        checkpoint_sha256=release["pins"][release["checkpoint"]],
        prepared_sha256=release["pins"]["prepared/PREPARED.json"],
        script_sha256=release_runner.DIAGNOSTIC,
        modes=release_runner.MODES,
        members=8,
        weights="ema",
        seed=904003,
        receipts=[dict(case=c["name"]) for c in prepared["cases"]],
    )
    rows = [
        dict(case=c["name"], intervention=m)
        for c in prepared["cases"]
        for m in release_runner.MODES
    ]
    result.update(rows=rows, initial_perturbations=rows)
    release_runner.validate_complete(result, release, prepared)
    result["members"] = 4
    with pytest.raises(ValueError, match="receipt identity"):
        release_runner.validate_complete(result, release, prepared)
    result["members"] = 8
    result["rows"] = rows[:-1]
    with pytest.raises(ValueError, match="omitted an intervention"):
        release_runner.validate_complete(result, release, prepared)


@pytest.mark.parametrize("output", ["code/new-results", "prepared/new-results"])
def test_output_cannot_modify_frozen_inputs(bundle, output):
    root, release, _ = bundle
    release["output"] = output
    with pytest.raises(ValueError, match="immutable"):
        release_runner.validate_release(root, release, "900")


def test_hard_deadline_terminates_process_and_preserves_partial_artifacts(tmp_path):
    import os
    import sys
    import time

    child = tmp_path / "slow.py"
    child.write_text(
        "import os,time\n"
        "from pathlib import Path\n"
        'Path("partial.txt").write_text(str(os.getpid()))\n'
        "time.sleep(30)\n"
        'Path("complete.txt").write_text("should not complete")\n'
    )
    started = time.monotonic()
    with pytest.raises(TimeoutError, match="process-group deadline"):
        release_runner.run_bounded(
            [sys.executable, str(child)], dict(os.environ), tmp_path, 0.5
        )
    assert time.monotonic() - started < 5
    pid = int((tmp_path / "partial.txt").read_text())
    with pytest.raises(ProcessLookupError):
        os.kill(pid, 0)
    assert not (tmp_path / "complete.txt").exists()
