# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Leakage guards, paired interventions, anomaly scores and OHC support."""

import importlib.util
from pathlib import Path

import numpy as np
import pytest
import torch

spec = importlib.util.spec_from_file_location(
    "conditioning",
    Path(__file__).parents[1] / "scripts/diagnose_stochastic_conditioning_v2.py",
)
diag = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diag)


def test_training_climatology_deduplicates_overlapping_windows_and_rejects_leakage():
    a, b = np.array([[[2.0]]]), np.array([[[6.0]]])
    mean, count, seen = diag.monthly_average(
        [("2001-01-03", a), ("2001-01-03", a.copy()), ("2002-01-03", b)], a.shape
    )
    assert mean[0].item() == 4 and count[0].item() == 2 and len(seen) == 2
    assert np.isnan(mean[1]).all()
    with pytest.raises(ValueError, match="outside training"):
        diag.monthly_average([("2014-01-01", b)], a.shape)
    with pytest.raises(ValueError, match="Conflicting duplicate"):
        diag.monthly_average([("2001-01-03", a), ("2001-01-03", b)], a.shape)


def test_climatology_missing_support_has_no_fallback_and_wet_om4_must_be_finite():
    field = np.array([[[np.nan, 2.0]]])
    mean, count, _ = diag.monthly_average([("2010-01-01", field)], field.shape)
    assert np.isnan(mean[0, 0, 0, 0]) and count[0, 0, 0, 0] == 0
    with pytest.raises(ValueError, match="Nonfinite packed"):
        diag.monthly_average(
            [("2010-01-01", field)], field.shape, strict_wet=np.ones_like(field, bool)
        )


def test_exact_calendar_donor_handles_year_crossing_and_rejects_time_or_year_mismatch():
    target = ["2013-12-29T12:00:00", "2014-01-03T12:00:00"]
    older = ["2009-12-29T12:00:00", "2010-01-03T12:00:00"]
    latest = ["2011-12-29T12:00:00", "2012-01-03T12:00:00"]
    wrong = ["2011-12-28T12:00:00", "2012-01-03T12:00:00"]
    assert (
        diag.select_donor(
            target, [("older", older), ("latest", latest), ("bad", wrong)]
        )
        == "latest"
    )
    with pytest.raises(ValueError, match="No exact"):
        diag.select_donor(target, [("self", target), ("wrong", wrong)])


def test_interior_swap_preserves_both_surface_history_slots_and_leaves_inputs_unchanged():
    original = torch.arange(2 * 2 * 77 * 2 * 3).reshape(2, 2, 77, 2, 3).float()
    donor = -original - 10
    swapped = diag.swap_interior(original, donor)
    interior = [i for i in range(77) if i not in diag.SURFACE]
    torch.testing.assert_close(
        swapped[:, :, diag.SURFACE], original[:, :, diag.SURFACE]
    )
    torch.testing.assert_close(swapped[:, :, interior], donor[:, :, interior])
    swapped.zero_()
    assert original.count_nonzero() > 0 and donor.count_nonzero() > 0


class SpyModel:
    history = 2

    def __init__(self):
        self.encodings = []
        self.advances = []

    def encode_native(self, surface, past, context, mask, validity, return_anchors):
        self.encodings.append(
            (surface.clone(), past.clone(), context.clone(), validity.clone())
        )
        return surface[:, -1] + past[:, -1, :1] + context[:, :1], None, None

    def initialize(self, condition, known, anchor, mask, generator):
        noise = torch.randn(condition.shape, generator=generator)
        self.noise = noise.clone()
        value = condition + noise
        return value[:, None].expand(-1, 2, -1, -1, -1).clone()

    def advance(self, state, forcing, context, mask, generator):
        self.advances.append((forcing.clone(), context.clone()))
        return state + forcing[:, None, :1] + context[:, None, :1]


def test_input_swap_keeps_recipient_forcing_calendar_and_member_noise():
    model = SpyModel()
    sample = dict(
        surface=torch.ones(1, 3, 2, 2, 3),
        validity=torch.ones(1, 3, 2, 2, 3),
        atmosphere=torch.full((1, 3, 8, 2, 3), 2.0),
        contexts=torch.full((1, 3, 5, 2, 3), 3.0),
    )
    donor = dict(
        surface=torch.full((1, 2, 2, 2, 3), 7.0), validity=torch.zeros(1, 2, 2, 2, 3)
    )
    mask = torch.ones(2, 2, 3)
    original = diag.initialize(model, sample, mask, seed=4)
    noise = model.noise.clone()
    changed = diag.initialize(model, sample, mask, seed=4, donor=donor)
    torch.testing.assert_close(model.noise, noise, rtol=0, atol=0)
    torch.testing.assert_close(
        changed - original, torch.full_like(original, 6), rtol=0, atol=1e-6
    )
    first, last = model.encodings
    torch.testing.assert_close(last[0], donor["surface"])
    torch.testing.assert_close(last[1], first[1])
    torch.testing.assert_close(last[2], first[2])
    torch.testing.assert_close(last[3], donor["validity"])
    assert len(list(diag.trajectory(model, changed, sample, mask))) == 1
    torch.testing.assert_close(
        model.advances[0][0], sample["atmosphere"][:, 2].expand(8, -1, -1, -1)
    )
    torch.testing.assert_close(
        model.advances[0][1], sample["contexts"][:, 2].expand(8, -1, -1, -1)
    )


def test_metrics_climatology_predictor_has_zero_skill_and_perfect_anomalies_have_unit_skill():
    climate = np.array([[[10.0, 20.0, 30.0]]])
    target = climate + np.array([[[1.0, -2.0, 3.0]]])
    mask = np.ones_like(target, bool)
    constant = diag.field_metrics(
        np.repeat(climate[None], 8, 0), target, climate, mask, [0]
    )
    assert constant["mse_skill"].item() == 0
    assert np.isnan(constant["anomaly_correlation"]).all()
    perfect = diag.field_metrics(
        np.repeat(target[None], 8, 0), target, climate, mask, [0]
    )
    assert perfect["mse_skill"].item() == 1
    assert perfect["anomaly_correlation"].item() == pytest.approx(1)
    assert perfect["rmse"].item() == 0


def test_fair_crps_and_fixed_support_have_hand_computed_values():
    draws = np.array([[[[0.0, np.nan]]], [[[2.0, np.nan]]]])
    target = np.array([[[1.0, 100.0]]])
    climate = np.array([[[0.0, np.nan]]])
    scores = diag.field_metrics(draws, target, climate, np.ones_like(target, bool), [0])
    assert scores["fair_crps"].item() == 0  # E|X-y|=1, pair correction=1.
    assert scores["rmse"].item() == 0
    assert scores["climatology_rmse"].item() == 1
    assert scores["support_weight"].item() == 1
    draws[0, 0, 0, 0] = np.nan
    with pytest.raises(ValueError, match="Nonfinite prediction"):
        diag.field_metrics(draws, target, climate, np.ones_like(target, bool), [0])


def test_ohc_uses_native_partial_boundary_and_complete_columns_without_deep_fallback():
    from samudra.metrics.kernels import CP, RHO

    temperature = np.ones((2, 14, 1, 2))
    mask = np.ones((14, 1, 2), bool)
    result = diag.physical_ohc(temperature, mask)
    np.testing.assert_allclose(result[:, 0], 700 * RHO * CP)
    np.testing.assert_allclose(result[:, 1], 1300 * RHO * CP)
    temperature[:, 10, 0, 0] = np.nan  # 775m center straddles the700m boundary.
    result = diag.physical_ohc(temperature, mask)
    assert np.isnan(result[:, :, 0, 0]).all()
    assert np.isfinite(result[:, :, 0, 1]).all()
    with pytest.raises(ValueError, match="does not span"):
        diag.physical_ohc(temperature[:, :10], mask[:10])


def checkpoint_fixture():
    cohort = dict(
        window_count=2548,
        windows_sha256="windows",
        required_source_intervals_sha256="intervals",
    )
    contract = dict(
        arm="B",
        forcing_mode="direct",
        objective="fair-crps",
        initializer_widths=[96, 192, 384],
        initializer_blocks=3,
        widths=[64, 128, 256],
        velocity_init_signed_crps_weight=1.0,
        seed=1729,
        grid="grid",
        om4_window_mode="native-30day",
        om4_cohort=cohort.copy(),
    )
    prepared = dict(grid_sha256="grid", cohort=cohort)
    for key in (
        "statistics",
        "packed_proof",
        "observation_manifest",
        "shared_era5_proof",
    ):
        contract[key] = key + "-digest"
        prepared[key + "_sha256"] = contract[key]
    saved = dict(contract=contract, step=8000, counts=dict(om4=4000, observation=4000))
    return saved, prepared


def test_checkpoint_requires_final_direct_forcing_and_exact_training_cohort():
    saved, prepared = checkpoint_fixture()
    contract = saved["contract"]
    diag.validate_checkpoint(saved, prepared)
    contract["forcing_mode"] = "bottleneck"
    with pytest.raises(ValueError, match="contract differs"):
        diag.validate_checkpoint(saved, prepared)
    contract["forcing_mode"] = "direct"
    contract["om4_cohort"]["windows_sha256"] = "other"
    with pytest.raises(ValueError, match="training cohort differs"):
        diag.validate_checkpoint(saved, prepared)


def test_native_model_split_initialization_and_rollout_matches_forecast_on_cpu():
    from types import SimpleNamespace

    from samudra.experiments.samudra_stochastic_transition import (
        SamudraStochasticTransition,
    )

    torch.manual_seed(91)
    torch.set_num_threads(1)
    model = SamudraStochasticTransition(
        SimpleNamespace(channels=77, history=2, surface=[38, 76]),
        arm="B",
        widths=(2, 4),
        forcing_mode="direct",
    ).eval()
    sample = dict(
        surface=torch.randn(1, 4, 2, 8, 16),
        validity=torch.ones(1, 4, 2, 8, 16),
        atmosphere=torch.randn(1, 4, 8, 8, 16),
        contexts=torch.randn(1, 4, 5, 8, 16),
    )
    mask = torch.ones(77, 8, 16)
    with torch.no_grad():
        expected, initial = model.forecast(
            **sample, mask=mask, members=2, generator=torch.Generator().manual_seed(101)
        )
        got_initial = diag.initialize(model, sample, mask, members=2, seed=101)
        got = torch.stack(list(diag.trajectory(model, got_initial, sample, mask)), 1)
    torch.testing.assert_close(got_initial, initial[:, 0], rtol=0, atol=0)
    torch.testing.assert_close(got, expected[:, 0], rtol=0, atol=0)


def test_paired_member_changes_separate_noise_matched_response_from_mean_response():
    reference = np.array([[[1.0, 2.0, 3.0]]])
    base = np.repeat(reference[None], 2, 0)
    changed = base.copy()
    changed[0] += 2
    changed[1] -= 2
    result = diag.field_metrics(
        changed,
        reference,
        np.zeros_like(reference),
        np.ones_like(reference, bool),
        [0],
        paired=base,
    )
    assert result["paired_member_change_rmse"].item() == 2
    assert result["paired_mean_change_rmse"].item() == 0


def test_plot_outputs_cover_all_native_depths_and_selected_maps(tmp_path):
    rows = []
    for case in range(3):
        for mode in diag.MODES:
            for variable in ("uo", "vo"):
                for depth in range(19):
                    rows.append(
                        dict(
                            source="om4",
                            lead=0,
                            intervention=mode,
                            channel=f"{variable}_{depth}",
                            mean_mse=1.0,
                            climatology_mse=2.0,
                            anomaly_correlation=0.5,
                            paired_member_change_rmse=0.0,
                        )
                    )
    diag.plot_depths(tmp_path, rows, diag.MODES)
    reference = np.ones((1, 2, 3))
    diag.save_maps(
        tmp_path,
        "example",
        np.repeat(reference[None], 8, 0),
        reference,
        reference,
        ["uo_0"],
        dict(lon=np.arange(3), lat=np.arange(2)),
    )
    assert (tmp_path / "all-depths.png").stat().st_size > 1000
    assert (tmp_path / "all-depths.pdf").stat().st_size > 1000
    assert (tmp_path / "example.png").stat().st_size > 1000
    with np.load(tmp_path / "example.npz") as saved:
        assert saved["members"].shape == (8, 1, 2, 3)


def test_map_limits_keep_salinity_errors_visible_and_velocity_symmetric(tmp_path):
    gold = np.array([[[34.0, 35.0, 36.0], [34.5, 35.5, 36.5]]])
    climate = gold - 0.05
    draws = np.repeat((gold + 0.01)[None], 8, 0)
    diag.save_maps(
        tmp_path,
        "salinity",
        draws,
        gold,
        climate,
        ["so_9"],
        dict(lon=np.arange(3), lat=np.arange(2)),
    )
    with np.load(tmp_path / "salinity.npz") as saved:
        assert saved["physical_limits"][0, 0] > 30
        assert saved["physical_limits"][0, 1] < 40
        np.testing.assert_allclose(saved["error_limits"][0], [-0.01, 0.01])
        np.testing.assert_allclose(saved["anomaly_limits"][0], [-0.06, 0.06])
        np.testing.assert_allclose(saved["mean_error"], 0.01)
        np.testing.assert_allclose(saved["reference_anomaly"], 0.05)
        np.testing.assert_allclose(saved["mean_anomaly"], 0.06)
        assert saved["units"].tolist() == ["psu"]
    assert (tmp_path / "salinity-anomalies.png").stat().st_size > 1000
    bounds = diag.map_limits(
        [np.array([[-0.2, 0.1, 0.3]])], np.ones((1, 3), bool), symmetric=True
    )
    assert bounds[0] == -bounds[1] and bounds[1] > 0.2


def test_observation_ohc_climate_uses_saved_targets_independent_of_interpolated_temperature(
    tmp_path,
):
    paths = [tmp_path / "2001-01.npz", tmp_path / "2002-01.npz"]
    ohc = [np.array([[[2.0]], [[6.0]]]), np.array([[[4.0]], [[10.0]]])]
    for path, value in zip(paths, ohc, strict=True):
        np.savez(path, ohc=value, interior=np.full((28, 1, 1), 123.0))
    climate, count, _ = diag.monthly_average(
        diag.observation_training_records(paths, "ohc", (1, 1)), (2, 1, 1)
    )
    np.testing.assert_array_equal(climate[0, :, 0, 0], [3.0, 8.0])
    np.testing.assert_array_equal(count[0, :, 0, 0], [2, 2])
    for path, value in zip(paths, ohc, strict=True):
        np.savez(path, ohc=value, interior=np.full((28, 1, 1), np.nan))
    changed, _, _ = diag.monthly_average(
        diag.observation_training_records(paths, "ohc", (1, 1)), (2, 1, 1)
    )
    np.testing.assert_equal(changed, climate)


@pytest.mark.parametrize(
    "key", ["statistics", "packed_proof", "observation_manifest", "shared_era5_proof"]
)
def test_checkpoint_rejects_changed_or_missing_prepared_input_provenance(key):
    saved, prepared = checkpoint_fixture()
    saved["contract"][key] = "different-digest"
    with pytest.raises(ValueError, match=key):
        diag.validate_checkpoint(saved, prepared)
    saved["contract"][key] = prepared.pop(key + "_sha256")
    with pytest.raises(ValueError, match=key):
        diag.validate_checkpoint(saved, prepared)


def test_independent_state_donor_uses_own_era5_calendar_but_all_rollouts_use_recipient():
    model = SpyModel()
    model.surface = [0]
    recipient = dict(
        surface=torch.ones(1, 4, 2, 2, 3),
        validity=torch.ones(1, 4, 2, 2, 3),
        atmosphere=torch.full((1, 4, 8, 2, 3), 2.0),
        contexts=torch.full((1, 4, 5, 2, 3), 3.0),
    )
    donor = dict(
        surface=torch.full((1, 2, 2, 2, 3), 7.0),
        validity=torch.ones(1, 2, 2, 2, 3),
        atmosphere=torch.full((1, 2, 8, 2, 3), 11.0),
        contexts=torch.full((1, 2, 5, 2, 3), 13.0),
    )
    mask = torch.ones(2, 2, 3)
    states = diag.initialization_states(
        model, recipient, donor, mask, members=8, seed=4
    )
    assert list(states) == diag.MODES
    base, input_encoding, independent_encoding = model.encodings
    torch.testing.assert_close(input_encoding[1], base[1])
    torch.testing.assert_close(input_encoding[2], base[2])
    torch.testing.assert_close(independent_encoding[1], donor["atmosphere"])
    torch.testing.assert_close(independent_encoding[2], donor["contexts"][:, -1])
    # Same noise cancels: changing donor forcing/calendar adds 9+10 everywhere.
    torch.testing.assert_close(
        states["full-state-swap"] - states["input-swap"],
        torch.full_like(states["recipient"], 19.0),
        rtol=0,
        atol=2e-6,
    )
    torch.testing.assert_close(
        states["interior-state-swap"][:, :, 0], states["recipient"][:, :, 0]
    )
    torch.testing.assert_close(
        states["interior-state-swap"][:, :, 1], states["full-state-swap"][:, :, 1]
    )
    for state in states.values():
        list(diag.trajectory(model, state, recipient, mask))
    for index, (forcing, context) in enumerate(model.advances):
        step = 2 + index % 2
        torch.testing.assert_close(
            forcing, recipient["atmosphere"][:, step].expand(8, -1, -1, -1)
        )
        torch.testing.assert_close(
            context, recipient["contexts"][:, step].expand(8, -1, -1, -1)
        )


def test_initial_perturbation_reports_both_history_slots_in_physical_units():
    base = torch.zeros(8, 2, 3, 2, 3)
    donor = base.clone()
    donor[:, 0, 1] = 2.0
    donor[:, 1, 1] = 4.0
    states = {"recipient": base, "interior-state-swap": donor}
    rows = diag.initial_perturbations(
        states,
        torch.ones(3, 2, 3),
        torch.tensor([0.0, 60.0]),
        torch.full((3, 1, 1), 3.0),
        case="x",
        names=["a", "b", "c"],
    )
    changed = [
        r
        for r in rows
        if r["intervention"] == "interior-state-swap" and r["channel"] == "b"
    ]
    assert [r["paired_member_change_rmse"] for r in changed] == [6.0, 12.0]
    assert [r["paired_mean_change_rmse"] for r in changed] == [6.0, 12.0]


def test_reused_bundle_requires_pinned_verified_full_readback(tmp_path):
    import json

    np.savez(tmp_path / "climate.npz", mean=np.ones((2, 3)))
    prepared = dict(
        complete=True, files={"climate.npz": diag.digest(tmp_path / "climate.npz")}
    )
    (tmp_path / "PREPARED.json").write_text(json.dumps(prepared))
    pin = diag.digest(tmp_path / "PREPARED.json")
    proof = dict(complete=True, prepared_sha256=pin, all_output_files_readback=True)
    (tmp_path / "VERIFIED.json").write_text(json.dumps(proof))
    assert diag.verified_reuse(tmp_path, pin) == prepared
    with pytest.raises(ValueError, match="manifest pin"):
        diag.verified_reuse(tmp_path, "wrong")
    np.savez(tmp_path / "climate.npz", mean=np.zeros((2, 3)))
    with pytest.raises(ValueError, match="file changed"):
        diag.verified_reuse(tmp_path, pin)
    with pytest.raises(ValueError, match="source provenance"):
        diag.check_input_pins(
            {"statistics_sha256": "old"}, {"statistics_sha256": "new"}
        )


def test_donor_history_requires_all_exact_bins_and_training_year():
    target = np.arange(np.datetime64("2014-03-01"), np.datetime64("2014-03-20"))
    donor = np.arange(np.datetime64("2013-03-01"), np.datetime64("2013-03-20"))
    diag.donor_history_check(target, donor)
    donor[0] += np.timedelta64(1, "D")
    with pytest.raises(ValueError, match="exact-calendar"):
        diag.donor_history_check(target, donor)


def test_shared_era5_reads_exact_native_indices_normalizes_and_rejects_cache_change(
    tmp_path,
):
    import datetime
    import json
    from types import SimpleNamespace

    from samudra.experiments.shared_era5 import SharedEra5

    indices = np.arange(25)
    values = (
        np.broadcast_to(indices[:, None, None, None], (25, 8, 1, 2))
        .astype(np.float32)
        .copy()
    )
    np.save(tmp_path / "indices.npy", indices)
    np.save(tmp_path / "values.npy", values)
    bounds = np.array(
        [
            [
                datetime.datetime(2001, 1, 1) + datetime.timedelta(days=5 * int(i)),
                datetime.datetime(2001, 1, 1) + datetime.timedelta(days=5 * int(i + 1)),
            ]
            for i in indices
        ],
        dtype=object,
    )
    reader = SimpleNamespace(windows=[(19, 25, [1 / 6] * 6, 30)], bounds=bounds)
    data = SimpleNamespace(
        grid={"mask": np.ones((77, 1, 2))},
        stats={"atmosphere_mean": np.full(8, 2.0), "atmosphere_std": np.full(8, 4.0)},
        tensor=torch.as_tensor,
    )
    proof = dict(
        all_intervals_readback_exact=True,
        contracts={},
        windows=1,
        bounds=[[a.isoformat(), b.isoformat()] for a, b in bounds],
        files={
            name: diag.digest(tmp_path / name) for name in ("indices.npy", "values.npy")
        },
    )
    (tmp_path / "COMPLETE.json").write_text(json.dumps(proof))
    pin = diag.digest(tmp_path / "COMPLETE.json")
    forcing = SharedEra5(tmp_path, reader, data, pin, full_readback=True)
    got = forcing.load(reader, 0, data)[0, :19]
    np.testing.assert_array_equal(got.numpy(), (values[:19] - 2) / 4)
    values[5] += 100
    np.save(tmp_path / "values.npy", values)
    with pytest.raises(ValueError, match="cache changed"):
        SharedEra5(tmp_path, reader, data, pin, full_readback=True)
    # Even a freshly pinned forcing proof cannot silently shift source intervals.
    values[5] -= 100
    np.save(tmp_path / "values.npy", values)
    proof["bounds"][0][0] = "2001-01-02T00:00:00"
    (tmp_path / "COMPLETE.json").write_text(json.dumps(proof))
    with pytest.raises(ValueError, match="interval bounds differ"):
        SharedEra5(
            tmp_path,
            reader,
            data,
            diag.digest(tmp_path / "COMPLETE.json"),
            full_readback=True,
        )
