# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Checkpoint-local gradient decomposition. No optimizer updates or training."""

import argparse
import gc
import json
import time
from pathlib import Path

import torch

from samudra.experiments import stochastic_transition_objectives as obj
from samudra.experiments.monthly_model_data import ModelMonths
from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.shared_era5 import SharedEra5
from samudra.experiments.stochastic_transition_data import CompactNativeLoader
from samudra.experiments.stochastic_transition_train import build_model


def device_copy(x):
    if isinstance(x, torch.Tensor):
        return x.cuda()
    if isinstance(x, dict):
        return {k: device_copy(v) for k, v in x.items()}
    return x


def vectors(loss, params, retain=True):
    grads = torch.autograd.grad(loss, params, retain_graph=retain, allow_unused=True)
    return torch.cat(
        [
            torch.zeros(p.numel()) if g is None else g.detach().float().cpu().flatten()
            for p, g in zip(params, grads)
        ]
    )


def output_stats(pred, target, mask, area, names, data):
    names = list(names)
    # Objective-swap diagnostic at IDENTICAL output values. Unit is normalized
    # model output; spatial/reduction weights remain exactly as in training.
    x = pred.detach().float().requires_grad_(True)
    valid = (mask & torch.isfinite(target)).expand_as(target)
    velocity = [i for i, n in enumerate(names) if n.startswith(("uo_", "vo_"))]
    u = [names.index(f"uo_{d}") for d in range(19)]
    v = [names.index(f"vo_{d}") for d in range(19)]
    raw = target * data.std[0, 0] + data.mean[0, 0]
    speed = (raw[:, u].square() + raw[:, v].square()).sqrt()
    residual = (x.detach() - target).abs()
    rows = []
    for objective in ["member-mse", "mae", "fair-crps"]:
        if objective == "fair-crps" and len(x) < 2:
            continue
        values, support = obj.score(
            x, target, mask, area, 1.0, deterministic=False, objective=objective
        )
        loss = 0.1 * obj.average(values, support)
        (grad,) = torch.autograd.grad(loss, x)
        for channel in velocity:
            depth = int(names[channel].split("_")[1])
            support2 = valid[:, channel]
            speeds = speed[:, depth]
            thresholds = torch.quantile(
                speeds[support2], torch.tensor([0.5, 0.9, 0.99], device="cuda")
            )
            for band, lo, hi in [
                ("all", 0.0, float("inf")),
                ("bottom50", 0.0, thresholds[0]),
                ("50to90", thresholds[0], thresholds[1]),
                ("90to99", thresholds[1], thresholds[2]),
                ("top1", thresholds[2], float("inf")),
            ]:
                selected = support2 & (speeds >= lo) & (speeds < hi)
                if not selected.any():
                    continue
                g = grad[:, :, channel][:, selected].flatten()
                r = residual[:, :, channel][:, selected].flatten()
                rows.append(
                    dict(
                        objective=objective,
                        channel=names[channel],
                        speed_band=band,
                        count=g.numel(),
                        mean_abs_gradient=g.abs().mean().item(),
                        rms_gradient=g.square().mean().sqrt().item(),
                        zero_fraction=(g.abs() < 1e-12).float().mean().item(),
                        normalized_absolute_residual=r.mean().item(),
                    )
                )
    return rows


def audit(model, data, sample, source, seed):
    captures = []
    original = obj.score

    def wrapped(*args, **kwargs):
        values, support = original(*args, **kwargs)
        captures.append((args, values, support))
        return values, support

    obj.score = wrapped
    members = 1 if model.arm == "A" else 4
    gen = torch.Generator(device="cuda").manual_seed(seed)
    try:
        with torch.autocast("cuda", dtype=torch.bfloat16):
            total, _ = (
                obj.native_batch_objective
                if source == "om4"
                else obj.observation_batch_objective
            )(model, data, [sample], gen, members=members, seeds=[seed])
    finally:
        obj.score = original
    if len(captures) != 3 or not torch.isfinite(total):
        raise RuntimeError("Unexpected objective call structure or nonfinite loss")
    monthly = 0.5 * obj.average(captures[0][1], captures[0][2])
    if source == "observation":
        values, support = captures[0][1:]
        monthly = 0.25 * (
            obj.average(values[:, :14], support[:, :14])
            + obj.average(values[:, 14:], support[:, 14:])
        )
    native = 0.5 * obj.average(captures[1][1], captures[1][2])
    init_args, values, support = captures[2]
    parts = {"forecast": monthly + native}
    if source == "om4":
        velocity = torch.tensor(
            [n.startswith(("uo_", "vo_")) for n in data.grid["names"]], device="cuda"
        )
        parts["initializer_velocity"] = (
            0.1 * torch.where(support & velocity, values, 0).sum() / support.sum()
        )
        parts["initializer_other"] = (
            0.1 * torch.where(support & ~velocity, values, 0).sum() / support.sum()
        )
    else:
        parts["initializer_surface"] = 0.1 * obj.average(values, support)
    torch.testing.assert_close(sum(parts.values()), total, rtol=2e-5, atol=1e-6)
    named = [
        (n, p)
        for n, p in model.named_parameters()
        if p.requires_grad and n.startswith(("initializer.", "forcing_adapter."))
    ]
    params = [p for _, p in named]
    widths = [p.numel() for p in params]
    initmask = torch.cat(
        [
            torch.full((w,), n.startswith("initializer."), dtype=torch.bool)
            for (n, _), w in zip(named, widths)
        ]
    )
    grads = {name: vectors(loss, params) for name, loss in parts.items()}
    totalg = sum(grads.values())
    output = dict(
        loss=total.item(),
        components={k: v.item() for k, v in parts.items()},
        members=members,
        parameter_count=len(totalg),
        preclip_shared_norm=totalg.norm().item(),
        gradient_norms={},
        cosines={},
    )
    for group, select in [
        ("shared", torch.ones_like(initmask)),
        ("initializer", initmask),
        ("forcing_adapter", ~initmask),
    ]:
        output["gradient_norms"][group] = {
            k: g[select].norm().item() for k, g in grads.items()
        }
        output["cosines"][group] = {
            f"{a}__{b}": torch.nn.functional.cosine_similarity(
                ga[select], gb[select], dim=0
            ).item()
            for a, ga in grads.items()
            for b, gb in grads.items()
            if a < b
        }
    if source == "om4":
        mse_values, mse_support = original(
            init_args[0].mean(0, keepdim=True),
            init_args[1],
            sample["mask"],
            data.area,
            1.0,
            deterministic=False,
            objective="member-mse",
        )
        mean_mse = (
            0.1
            * torch.where(mse_support & velocity, mse_values, 0).sum()
            / mse_support.sum()
        )
        mse_grad = vectors(mean_mse, params)
        original_grad = grads["initializer_velocity"]
        output["velocity_mean_mse_counterfactual"] = dict(
            loss=mean_mse.item(),
            initializer_norm=mse_grad[initmask].norm().item(),
            cosine_with_actual_velocity=torch.nn.functional.cosine_similarity(
                mse_grad[initmask], original_grad[initmask], dim=0
            ).item(),
            equal_norm_aux_coefficient=(
                original_grad[initmask].norm() / mse_grad[initmask].norm()
            ).item(),
            crps_multiplier_matching_unit_aux_combined_norm=(
                (original_grad[initmask] + mse_grad[initmask]).norm()
                / original_grad[initmask].norm()
            ).item(),
        )
    # Cross-source alignment retained on disk, CPU float32, no model tensors.
    if source == "om4":
        output["output_objective_swaps"] = output_stats(
            init_args[0],
            init_args[1],
            sample["mask"],
            data.area,
            data.grid["names"],
            data,
        )
    return output, grads


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    cfg = json.loads((args.root / "config.json").read_text())
    out = args.root / "results"
    out.mkdir(exist_ok=True)
    torch.set_num_threads(1)
    torch.cuda.set_device(0)
    paths = cfg["paths"]
    data = Samples(
        Path(paths["samples"]), "cuda", surface_fill="zero", global_observations=True
    )
    cpu = Samples(
        Path(paths["samples"]), "cpu", surface_fill="zero", global_observations=True
    )
    reader = ModelMonths(
        Path(paths["om4"]) / "OM4.zarr",
        "om4",
        data.grid,
        Path(paths["om4"]),
        packed=Path(paths["packed_om4"]),
    )
    forcing = SharedEra5(
        paths["forcing_cache"],
        reader,
        data,
        paths["forcing_proof_sha256"],
        full_readback=True,
    )
    loader = CompactNativeLoader(reader, forcing, cpu, resident=False)
    samples = [
        (device_copy(loader(i)), device_copy(cpu.load(cpu.paths("train")[j])))
        for i, j in cfg["sample_indices"]
    ]
    provenance = dict(
        config=cfg,
        script_sha256=digest(Path(__file__)),
        samples=[
            dict(om4_first=a["first"], obs_path=str(cpu.paths("train")[j]))
            for (a, b), (i, j) in zip(samples, cfg["sample_indices"])
        ],
        weights="raw checkpoint parameters; training-mode BF16, no optimization",
        effective_batch_note="Three individual microbatch probes; each B has4members; not effective-batch8 gradients",
        clipping="No clipping applied. Shared norms exclude processor; cannot infer actual global clipping factor.",
        cuda=torch.cuda.get_device_name(),
    )
    atomic_json(provenance, out / "input.json")
    for variant, path in cfg["checkpoints"].items():
        saved = torch.load(path, map_location="cpu", weights_only=False)
        model = build_model(saved, data, use_ema=False).train()
        # Checkpointing bounds graph memory and preserves objective/RNG.
        model.initializer.checkpoint_blocks = True
        model.processor.checkpoint_blocks = True
        del saved
        for index, (native, obs) in enumerate(samples):
            started = time.monotonic()
            payloads = {}
            gradients = {}
            for source, sample in [("om4", native), ("observation", obs)]:
                payloads[source], gradients[source] = audit(
                    model, data, sample, source, 773001 + index
                )
                gc.collect()
                torch.cuda.empty_cache()
            om4 = gradients["om4"]["initializer_velocity"]
            payloads["cross_source_cosines"] = {
                k: torch.nn.functional.cosine_similarity(om4, g, dim=0).item()
                for k, g in gradients["observation"].items()
            }
            payloads.update(
                variant=variant,
                checkpoint_sha256=digest(Path(path)),
                sample=index,
                seconds=time.monotonic() - started,
            )
            atomic_json(payloads, out / f"{variant}-{index}.json")
            print(
                json.dumps(
                    dict(variant=variant, sample=index, seconds=payloads["seconds"])
                ),
                flush=True,
            )
            del gradients, payloads
        del model
        gc.collect()
        torch.cuda.empty_cache()
    atomic_json(
        dict(complete=True, variants=list(cfg["checkpoints"]), samples=len(samples)),
        out / "COMPLETE.json",
    )


if __name__ == "__main__":
    main()
