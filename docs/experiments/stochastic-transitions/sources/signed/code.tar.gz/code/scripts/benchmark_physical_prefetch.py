# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Matched four-GPU OM4-only I/O qualification, with no scientific continuation.

Runs three sixteen-update arms from the same initialization in separate directories.
The first four updates and remaining twelve are reported separately, not assumed
cold-disk and warm-disk: the second arm may benefit from the OS page cache.
"""

import argparse
import json
import math
import os
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path


def process_memory(root_pid):
    """Sum process-tree RSS; shared pages may be counted more than once."""
    pending = [root_pid]
    seen = set()
    rss_kib = 0
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        seen.add(pid)
        try:
            status = Path(f"/proc/{pid}/status").read_text()
            for line in status.splitlines():
                if line.startswith("VmRSS:"):
                    rss_kib += int(line.split()[1])
            pending.extend(
                int(value)
                for value in Path(f"/proc/{pid}/task/{pid}/children")
                .read_text()
                .split()
            )
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    available = next(
        int(line.split()[1])
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    return dict(rss_sum_kib=rss_kib, host_available_kib=available, processes=len(seen))


def summarize(values):
    return dict(
        mean=statistics.mean(values),
        median=statistics.median(values),
        minimum=min(values),
        maximum=max(values),
    )


def command_for(args, output):
    config = json.loads(args.reference.read_text())
    legacy = json.loads(Path(config["legacy_qualification"]).read_text())
    return [
        sys.executable,
        "-m",
        "torch.distributed.run",
        "--standalone",
        "--nproc-per-node=4",
        "-m",
        "samudra.experiments.physical_state_train",
        "--root",
        str(args.root),
        "--output",
        str(output),
        "--reference",
        str(args.reference),
        "--data",
        config["samples"],
        "--om4",
        config["om4"],
        "--packed-om4",
        legacy["packed_om4"],
        "--shared-era5",
        config["forcing_cache"],
        "--shared-era5-proof-sha256",
        config["forcing_proof_sha256"],
        "--replay-cache",
        config["replay_cache"],
        "--om4-warmup-updates",
        "10000",
        "--updates-per-task",
        "500",
        "--obs-cooldown-updates",
        "100",
        "--effective-batch",
        "8",
        "--microbatch",
        "1",
        "--members",
        "2",
        "--sampling-steps",
        "8",
        "--checkpoint-every",
        "1000",
        "--hours",
        "1.75",
        "--fused-adam",
        "--replay-after-warmup",
        "--replay-curriculum",
        "1",
        "3",
        "6",
        "11",
        "--om4-surface-masking",
        "--max-new-updates",
        str(args.updates),
        "--smoke",
        "--check-rank-sync",
    ]


def run_arm(args, name, code, extra):
    output = args.root / name
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite benchmark arm {output}")
    environment = dict(os.environ, PYTHONPATH=str(code / "src"))
    command = command_for(args, output) + extra
    if args.deterministic:
        environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
        worker = Path(__file__).with_name("qualify_physical_prefetch_worker.py")
        audit_command = [
            sys.executable,
            "-m",
            "torch.distributed.run",
            "--standalone",
            "--nproc-per-node=4",
            str(worker),
            "audit",
            "--reference",
            str(args.reference),
            "--output",
            str(args.root / f"{name}-inputs"),
        ]
        if name == "optimized":
            audit_command.append("--optimized")
        with (args.root / f"{name}-audit.log").open("w") as audit_log:
            subprocess.run(
                audit_command,
                env=environment,
                stdout=audit_log,
                stderr=subprocess.STDOUT,
                check=True,
            )
        trainer_index = command.index("samudra.experiments.physical_state_train")
        command[trainer_index - 1 : trainer_index + 1] = [str(worker), "train"]
    samples = []
    stop = threading.Event()
    started = time.monotonic()
    with (args.root / f"{name}.log").open("w") as handle:
        process = subprocess.Popen(
            command, env=environment, stdout=handle, stderr=subprocess.STDOUT
        )

        def monitor():
            while not stop.is_set():
                samples.append(
                    dict(
                        seconds=time.monotonic() - started,
                        **process_memory(process.pid),
                    )
                )
                stop.wait(1)

        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        try:
            returncode = process.wait()
        finally:
            stop.set()
            thread.join()
    wall_seconds = time.monotonic() - started
    (args.root / f"{name}-memory.json").write_text(json.dumps(samples, indent=2))
    if returncode:
        raise RuntimeError(f"{name} failed with exit {returncode}; see its log")
    events = [
        json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()
    ]
    if [event["step"] for event in events] != list(range(1, args.updates + 1)):
        raise ValueError("Benchmark updates are missing or duplicated")
    for event in events:
        if (
            event["task"] != "om4"
            or event["replay_enabled"]
            or event["rank_sync_max_abs"] != 0
        ):
            raise ValueError(
                "Wrong benchmark task, active replay, or divergent rank replicas"
            )
        if not all(
            math.isfinite(event[key]) for key in ("loss", "gradient_norm", "seconds")
        ):
            raise ValueError("Nonfinite benchmark values")
    timings = {}
    startup = min(4, max(1, args.updates // 2))
    for label, subset in (
        ("startup", events[:startup]),
        ("remaining", events[startup:]),
    ):
        timings[label] = dict(
            updates=len(subset),
            step_seconds=summarize([event["seconds"] for event in subset]),
            maximum_rank_data_seconds=summarize(
                [
                    max(rank["data_seconds"] for rank in event["rank_work"])
                    for event in subset
                ]
            ),
            maximum_rank_compute_seconds=summarize(
                [
                    max(rank["compute_seconds"] for rank in event["rank_work"])
                    for event in subset
                ]
            ),
        )
    return dict(
        code=str(code),
        command=command,
        timings=timings,
        wall_seconds=wall_seconds,
        peak_logged_rank0_gpu_gib=max(event["peak_gib"] for event in events),
        peak_process_tree_rss_gib=max(item["rss_sum_kib"] for item in samples) / 2**20,
        minimum_host_available_gib=min(item["host_available_kib"] for item in samples)
        / 2**20,
        events=events,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--baseline-code", required=True, type=Path)
    parser.add_argument("--optimized-code", required=True, type=Path)
    parser.add_argument(
        "--optimized-args",
        default="[]",
        help="JSON list of extra optimized trainer options",
    )
    parser.add_argument("--updates", type=int, default=16)
    parser.add_argument("--deterministic", action="store_true")
    args = parser.parse_args()
    if args.updates < (2 if args.deterministic else 8):
        raise ValueError("Need at least four startup and four subsequent updates")
    if os.environ.get("TORCH_CUDNN_V8_API_DISABLED") != "1":
        raise ValueError("Required cuDNN workaround missing")
    args.root.mkdir(parents=True, exist_ok=True)
    before = run_arm(args, "baseline", args.baseline_code, [])
    after = run_arm(
        args, "optimized", args.optimized_code, json.loads(args.optimized_args)
    )
    warm = run_arm(args, "baseline_warm", args.baseline_code, [])
    differences = {}
    for key in ("loss", "gradient_norm"):
        lhs = [event[key] for event in before["events"]]
        rhs = [event[key] for event in after["events"]]
        absolute = max(abs(x - y) for x, y in zip(lhs, rhs, strict=True))
        relative = max(
            abs(x - y) / max(abs(x), 1e-12) for x, y in zip(lhs, rhs, strict=True)
        )
        differences[key] = dict(max_absolute=absolute, max_relative=relative)
    for key in ("loss", "gradient_norm"):
        lhs = [event[key] for event in warm["events"]]
        rhs = [event[key] for event in after["events"]]
        differences[f"warm_{key}"] = dict(
            max_absolute=max(abs(x - y) for x, y in zip(lhs, rhs, strict=True)),
            max_relative=max(
                abs(x - y) / max(abs(x), 1e-12) for x, y in zip(lhs, rhs, strict=True)
            ),
        )
    exact_inputs = None
    exact_models = None
    if args.deterministic:
        receipts = []
        for name in ("baseline", "optimized", "baseline_warm"):
            receipts.append(
                [
                    json.loads(
                        (args.root / f"{name}-inputs" / f"rank-{rank}.json").read_text()
                    )
                    for rank in range(4)
                ]
            )
        exact_inputs = receipts[0] == receipts[1] == receipts[2]
        import torch

        states = [
            torch.load(
                args.root / name / "last.pt", map_location="cpu", weights_only=False
            )["model"]
            for name in ("baseline", "optimized", "baseline_warm")
        ]
        exact_models = all(
            all(torch.equal(states[0][key], state[key]) for key in states[0])
            for state in states[1:]
        )
    passed = all(
        value["max_absolute"] <= 1e-6 or value["max_relative"] <= 1e-5
        for value in differences.values()
    )
    if args.deterministic:
        passed = passed and exact_inputs and exact_models
    result = dict(
        exact_input_tensors=exact_inputs,
        exact_final_model_weights=exact_models,
        deterministic_algorithms=args.deterministic,
        baseline=before,
        optimized=after,
        baseline_warm=warm,
        numerical_comparison=differences,
        numerical_gate_passed=passed,
        remaining_step_speedup=before["timings"]["remaining"]["step_seconds"]["mean"]
        / after["timings"]["remaining"]["step_seconds"]["mean"],
        warm_baseline_step_speedup=warm["timings"]["remaining"]["step_seconds"]["mean"]
        / after["timings"]["remaining"]["step_seconds"]["mean"],
        scope=f"Three {args.updates}-update engineering arms; no scientific continuation or validation claim",
        caveats=[
            "Second arm may benefit from OS page cache; first4/remaining is not a controlled disk-cache distinction",
            "Step timings exclude checkpoint IO; wall_seconds includes startup and checkpoints",
            "Summed process RSS may double-count shared mapped pages; GPU memory is the logged rank0 peak",
        ],
    )
    (args.root / "BENCHMARK_RESULT.json").write_text(json.dumps(result, indent=2))
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "numerical_comparison",
                    "numerical_gate_passed",
                    "exact_input_tensors",
                    "exact_final_model_weights",
                    "remaining_step_speedup",
                    "warm_baseline_step_speedup",
                )
            },
            indent=2,
        )
    )
    if not passed:
        raise RuntimeError("Optimized numerical comparison exceeds declared tolerance")


if __name__ == "__main__":
    main()
