#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Compute scored day-30 spectra from one cached draw per held-out origin."""

import argparse
import json
from pathlib import Path

import numpy as np
import xarray as xr

from samudra.experiments.observation_pilot import digest
from samudra.metrics import kernels, spectra


def compute_fields(surface, reference, mask, lat, lon):
    """Same spatial/velocity operators as the point scorer, at day 30 only."""
    values = np.where(mask[None, None], surface, np.nan)

    def field(a):
        return xr.DataArray(
            a, dims=("time", "lat", "lon"),
            coords={"time": np.arange(len(a)), "lat": lat, "lon": lon},
        )

    u, v = kernels.geostrophic_velocity_from_zos(field(values[:, 1]), "lat", "lon")
    ru, rv = kernels.geostrophic_velocity_from_zos(field(reference[:, 1]), "lat", "lon")
    support = np.isfinite(ru) & np.isfinite(rv)
    eke = kernels.instantaneous_surface_eke(u.where(support), v.where(support))
    return {
        "sst": field(values[:, 0]).where(np.isfinite(reference[:, 0])),
        "adt": field(values[:, 1]).where(np.isfinite(reference[:, 1])),
        "eke": eke.transpose("time", "lat", "lon"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--draw", type=int, default=1, help="One-based draw index")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    receipt = json.loads((args.root / "COMPLETE.json").read_text())
    assert receipt["split"] == "test"
    assert receipt["counts"] == {"om4": 8000, "observation": 8000}
    names = [f"members-{origin}.npz" for origin in receipt["metrics"]["origins"]]
    assert set(names) == set(receipt["files"])
    assert len(names) == 96
    means, draws, references = [], [], []
    template = None
    for i, name in enumerate(names):
        path = args.root / name
        assert digest(path) == receipt["files"][name], path
        with np.load(path) as saved:
            metadata = {key: saved[key] for key in ("lat", "lon", "mask", "channel_names")}
            if template is None:
                template = metadata
            else:
                for key in template:
                    np.testing.assert_array_equal(template[key], metadata[key])
            members = saved["day30"][:, :2]
            assert 1 <= args.draw <= len(members)
            np.testing.assert_array_equal(saved["channel_names"][:2], ["thetao_0", "zos"])
            means.append(members.mean(0))
            draws.append(members[args.draw - 1])
            references.append(saved["day30_surface_reference"])
        if (i + 1) % 24 == 0:
            print(f"Verified and loaded {i + 1}/96 origins", flush=True)
    assert template is not None
    lat, lon = template["lat"], template["lon"]
    mask = template["mask"][0].astype(bool)
    reference = np.where(mask[None, None], np.stack(references), np.nan)
    curves, reconstruction = {}, {}
    for mode, surface in (("mean", means), ("draw", draws)):
        fields = compute_fields(np.stack(surface), reference, mask, lat, lon)
        for region, longitude, latitude in spectra.SPATIAL_REGIONS:
            for label, field in fields.items():
                key = f"{label}/{region}/day30"
                if key not in receipt["metrics"]["spectra"]:
                    continue
                original = receipt["metrics"]["spectra"][key]
                k, power = spectra.region_spectrum(field, longitude, latitude, name=region)
                maximum_k = 2 * np.pi / (
                    4 * spectra.METRES_PER_DEGREE / 1000 * np.max(np.diff(lat))
                )
                keep = k <= maximum_k
                k, power = k[keep], power[keep]
                np.testing.assert_allclose(k, original["k_rad_km"], rtol=1e-12)
                if mode == "mean":
                    # Saved exports denormalize then average; the GPU scorer averages
                    # normalized fields first. Permit small float32 ordering error.
                    np.testing.assert_allclose(power, original["prediction_power"], rtol=2e-4, atol=0)
                    reconstruction[key] = float(np.max(np.abs(power / original["prediction_power"] - 1)))
                else:
                    curves[key] = dict(
                        k_rad_km=k.tolist(), reference_power=original["reference_power"],
                        prediction_power=power.tolist(),
                        error_dex=spectra.log10_rmse_between_curves(
                            k, np.array(original["reference_power"]), k, power,
                        ),
                    )
    assert len(curves) == 9
    result = dict(
        draw=args.draw, checkpoint_sha256=receipt["checkpoint_sha256"],
        split=receipt["split"], counts=receipt["counts"], origins=receipt["metrics"]["origins"],
        sampling_steps=receipt["sampling_steps"], spectra=curves,
        ensemble_mean_reconstruction_max_relative_error=reconstruction,
        source=str(args.root),
        method=(
            "One fixed draw index at day 30 from each of 96 origins; no ensemble averaging. "
            "Same regional FFT, detrending, window, radial bins and four-cell cutoff as the scorer. "
            "EKE derived from each draw's SSH; velocity anomalies subtract the mean across origins. "
            "Stored reference spectra reused unchanged. Reconstructed ensemble-mean powers checked "
            "against published curves at every day-30 bin before computing draw curves."
        ),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(reconstruction, indent=2))


if __name__ == "__main__":
    main()
