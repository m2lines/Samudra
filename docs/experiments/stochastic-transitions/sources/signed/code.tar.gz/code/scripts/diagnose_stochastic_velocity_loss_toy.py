# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""CPU-only loss-gradient checks and synthetic conditional-current regression."""

import argparse
import csv
import importlib.util
import json
import math
from pathlib import Path

import torch


def crps(x, y, alpha=1.0):
    m = x.shape[0]
    ordered = x.sort(dim=0).values
    rank = torch.arange(m, dtype=x.dtype, device=x.device)
    pair = ((2 * rank - m + 1)[:, None] * ordered).sum(0) / (m * (m - 1))
    return (x - y).abs().mean(0) - alpha * pair


def objective(x, y, name):
    if name == "member-mse":
        return (x - y).square().mean()
    if name == "mae":
        return (x - y).abs().mean()
    # Paper alpha mixes fair CRPS with ordinary ensemble CRPS. The latter
    # multiplies the fair spread subtraction by (M-1)/M.
    pair_factor = 1 - 0.05 / len(x) if name == "almost-fair-0.95" else 1
    out = crps(x, y, pair_factor).mean()
    if name == "fair-plus-mean-mse":
        out = out + (x.mean(0) - y).square().mean()
    return out


def checks():
    path = Path(__file__).resolve().parents[1] / "src/samudra/experiments/stochastic_transition_objectives.py"
    spec = importlib.util.spec_from_file_location("ocean_objectives", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for m in [2, 4, 8]:
        for target in [-10.0, -0.25, 10.0]:
            x = torch.linspace(-2, 2, m).requires_grad_()
            y = torch.tensor([target])
            loss = crps(x[:, None], y).sum()
            grad = torch.autograd.grad(loss, x)[0]
            ranks = torch.arange(1, m + 1)
            expected = torch.sign(x.detach() - target) / m - (2 * ranks - m - 1) / (m * (m - 1))
            torch.testing.assert_close(grad, expected)
            actual, _ = module.score(x[:, None, None, None], y.reshape(1, 1, 1), torch.ones(1, 1, 1, dtype=torch.bool), torch.ones(1, 1), 1.0, deterministic=False)
            actual_grad = torch.autograd.grad(actual.sum(), x)[0]
            torch.testing.assert_close(actual.sum(), loss)
            torch.testing.assert_close(actual_grad, expected)
            rows.append(dict(members=m, target=target, predictions=x.detach().tolist(), loss=float(loss.detach()), gradients=grad.tolist()))
    return rows


class Toy(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.net = torch.nn.Sequential(torch.nn.Linear(1, 32), torch.nn.Tanh(), torch.nn.Linear(32, 32), torch.nn.Tanh(), torch.nn.Linear(32, 2))

    def forward(self, x):
        output = self.net(x[:, None])
        return output[:, 0], torch.nn.functional.softplus(output[:, 1]) + 1e-4


def truth(x):
    jet = torch.exp(-((x - 0.75) / 0.025).square() / 2)
    return 0.2 * torch.sin(2 * math.pi * x) + 4 * jet, 0.15 + 0.3 * jet


@torch.no_grad()
def evaluate(model):
    x = torch.linspace(0, 1, 1024)
    gold_mu, gold_sigma = truth(x)
    mu, sigma = model(x)
    jet = (x - 0.75).abs() < 0.05
    # Analytic expected CRPS between independent predicted and true Gaussians.
    delta = mu - gold_mu
    variance = sigma.square() + gold_sigma.square()
    sd = variance.sqrt()
    expected_abs = sd * math.sqrt(2 / math.pi) * torch.exp(-delta.square() / (2 * variance)) + delta * torch.erf(delta / (sd * math.sqrt(2)))
    return dict(mean_rmse=float(delta.square().mean().sqrt()), jet_mean_rmse=float(delta[jet].square().mean().sqrt()), background_mean_rmse=float(delta[~jet].square().mean().sqrt()), spread_rms=float(sigma.square().mean().sqrt()), true_spread_rms=float(gold_sigma.square().mean().sqrt()), expected_crps=float((expected_abs - sigma / math.sqrt(math.pi)).mean()), peak_mean=float(mu.max()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--updates", type=int, default=2000)
    parser.add_argument("--objectives", nargs="+")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    checks_out = checks()
    (args.output / "gradient-checks.json").write_text(json.dumps(checks_out, indent=2) + "\n")
    rows = []
    names = args.objectives or ["member-mse", "mae", "fair-crps", "fair-plus-mean-mse", "almost-fair-0.95"]
    for seed in [11, 23, 47]:
        for name in names:
            torch.manual_seed(seed)
            model = Toy()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.003)
            generator = torch.Generator().manual_seed(seed + 1000)
            for step in range(args.updates + 1):
                if step in [0, 50, 200, 500, 1000, 2000, 4000, args.updates]:
                    row = dict(seed=seed, objective=name, updates=step, **evaluate(model))
                    rows.append(row)
                    print(json.dumps(row), flush=True)
                if step == args.updates:
                    break
                x = torch.rand(128, generator=generator)
                mean, std = truth(x)
                y = mean + std * torch.randn(128, generator=generator)
                z = torch.randn(4, 128, generator=generator)
                mu, sigma = model(x)
                loss = objective(mu + sigma * z, y, name)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            x = torch.linspace(0, 1, 1024)
            with torch.no_grad():
                mu, sd = model(x)
            curve = torch.stack([x, *truth(x), mu, sd], dim=1).tolist()
            with (args.output / f"fields-{name}-{seed}.csv").open("w") as handle:
                writer = csv.writer(handle)
                writer.writerow(["x", "true_mean", "true_std", "predicted_mean", "predicted_std"])
                writer.writerows(curve)
    with (args.output / "learning-curves.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (args.output / "protocol.json").write_text(json.dumps(dict(device="cpu", updates=args.updates, seeds=[11, 23, 47], members=4, batch=128, learning_rate=0.003, objectives=names, target="normal conditioned on coordinate; narrow 4-unit jet plus broad 0.2-unit sinusoid; sigma0.15+0.3jet", interpretation="Mechanism illustration; no ocean data or ocean architecture; Gaussian family has known true mean and variance; equal random draws across objectives within seed", gradient_checks="nine cases match production fair-CRPS values and gradients"), indent=2) + "\n")


if __name__ == "__main__":
    main()
