# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""CPU-only check of variance-corrected ensemble-mean MSE supervision."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import torch

from diagnose_stochastic_velocity_loss_toy import Toy, crps, evaluate, truth


def ustat(x, y):
    """Unbiased squared error of the population mean for iid members."""
    return (x.mean(0) - y).square() - x.var(0, unbiased=True) / len(x)


def checks():
    rows = []
    generator = torch.Generator().manual_seed(1729)
    for m in [2, 4, 8]:
        values = torch.randn(m, 7, generator=generator, dtype=torch.float64).requires_grad_()
        target = torch.randn(7, generator=generator, dtype=torch.float64)
        residual = values - target
        direct = sum(residual[i] * residual[j] for i in range(m) for j in range(m) if i != j) / (m * (m - 1))
        value = ustat(values, target)
        torch.testing.assert_close(value, direct)
        gradient = torch.autograd.grad(value.sum(), values)[0]
        expected = 2 * (residual.sum(0) - residual) / (m * (m - 1))
        torch.testing.assert_close(gradient, expected)
        for mu0, sigma0, y in [(0.3, 0.2, 0.1), (0.0, 1.0, 0.0), (2.0, 0.7, -0.5)]:
            samples = 200000
            mu = torch.tensor(mu0, dtype=torch.float64, requires_grad=True)
            sigma = torch.tensor(sigma0, dtype=torch.float64, requires_grad=True)
            x = mu + sigma * torch.randn(m, samples, generator=generator, dtype=torch.float64)
            estimates = ustat(x, y)
            variance = 4 * (mu0 - y) ** 2 * sigma0**2 / m + 2 * sigma0**4 / (m * (m - 1))
            se = math.sqrt(variance / samples)
            value = estimates.mean()
            grad_mu, grad_sigma = torch.autograd.grad(value, (mu, sigma))
            assert abs(float(value.detach()) - (mu0 - y)**2) < 6 * se
            rows.append(dict(members=m, mu=mu0, sigma=sigma0, target=y, monte_carlo_samples=samples, expected=(mu0-y)**2, measured=float(value.detach()), standard_error=se, expected_gradient_mu=2*(mu0-y), measured_gradient_mu=float(grad_mu), expected_gradient_sigma=0, measured_gradient_sigma=float(grad_sigma), negative_fraction=float((estimates<0).double().mean())))
    return rows


@torch.no_grad()
def metrics(model):
    result = evaluate(model)
    x = torch.linspace(0, 1, 1024)
    true_mu, true_sigma = truth(x)
    mu, sigma = model(x)
    delta = mu - true_mu
    jet = (x - 0.75).abs() < 0.05
    radius = 1.6448536269514722 * sigma
    cdf_high = 0.5 * (1 + torch.erf((delta + radius)/(true_sigma*math.sqrt(2))))
    cdf_low = 0.5 * (1 + torch.erf((delta - radius)/(true_sigma*math.sqrt(2))))
    coverage = cdf_high-cdf_low
    result.update(conditional_std_rmse=float((sigma-true_sigma).square().mean().sqrt()), jet_conditional_std_rmse=float((sigma[jet]-true_sigma[jet]).square().mean().sqrt()), expected_90_coverage=float(coverage.mean()), jet_expected_90_coverage=float(coverage[jet].mean()), conditional_90_coverage_mae=float((coverage-.9).abs().mean()))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    (args.output / "analytic-monte-carlo-checks.json").write_text(json.dumps(checks(), indent=2)+"\n")
    rows = []
    for seed in [11, 23, 47]:
        for name in ["fair-plus-mean-mse", "fair-plus-ustat-mean-mse"]:
            torch.manual_seed(seed)
            model = Toy()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.003)
            generator = torch.Generator().manual_seed(seed + 1000)
            for step in range(2001):
                if step in [0, 50, 200, 500, 1000, 2000]:
                    row = dict(seed=seed, objective=name, updates=step, **metrics(model))
                    rows.append(row)
                    print(json.dumps(row), flush=True)
                if step == 2000:
                    break
                x = torch.rand(128, generator=generator)
                mean, std = truth(x)
                y = mean + std * torch.randn(128, generator=generator)
                z = torch.randn(4, 128, generator=generator)
                mu, sigma = model(x)
                predictions = mu + sigma*z
                auxiliary = ustat(predictions,y) if name.endswith("ustat-mean-mse") else (predictions.mean(0)-y).square()
                loss = crps(predictions,y).mean() + auxiliary.mean()
                assert torch.isfinite(loss)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            x = torch.linspace(0, 1, 1024)
            with torch.no_grad():
                mu, sd = model(x)
            with (args.output/f"fields-{name}-{seed}.csv").open("w") as handle:
                writer=csv.writer(handle)
                writer.writerow(["x","true_mean","true_std","predicted_mean","predicted_std"])
                writer.writerows(torch.stack([x,*truth(x),mu,sd],dim=1).tolist())
    with (args.output/"learning-curves.csv").open("w") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    files=[Path(__file__), Path(__file__).with_name("diagnose_stochastic_velocity_loss_toy.py")]
    (args.output/"protocol.json").write_text(json.dumps(dict(device="cpu",updates=2000,batch=128,members=4,seeds=[11,23,47],learning_rate=.003,auxiliary_weight=1.0,member_assumption="iid conditional on x",shared_randomness="same initialization, minibatches, target and member noise across objectives",source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}),indent=2)+"\n")


if __name__ == "__main__":
    main()
