# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Nine OBS origins: initialization only, without executing a processor."""

import argparse
from pathlib import Path

import numpy as np
import torch
from evaluate_stochastic_loss_initializers import score

from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.stochastic_transition_train import build_model


@torch.no_grad()
def main():
    p = argparse.ArgumentParser()
    for key in ("data", "checkpoint", "output"):
        p.add_argument("--" + key, type=Path, required=True)
    p.add_argument("--raw", action="store_true")
    p.add_argument("--members", type=int, default=8)
    p.add_argument("--limit-origins", type=int)
    args = p.parse_args()
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model = build_model(saved, data, use_ema=not args.raw).eval()

    def forbidden(*a, **kw):
        raise RuntimeError("Initializer-only diagnostic attempted processor/forecast")

    model.forecast = forbidden
    model.processor.forward = forbidden
    paths = data.paths("validation")
    assert len(paths) == 9
    paths = paths[: args.limit_origins] if args.limit_origins else paths
    args.output.mkdir(parents=True, exist_ok=True)
    results = []
    for index, path in enumerate(paths):
        sample = data.load(path)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            condition, _, _ = model.encode_native(
                sample["surface"][:, : model.history],
                sample["atmosphere"][:, : model.history],
                sample["contexts"][:, model.history - 1],
                data.mask,
                sample["validity"][:, : model.history],
                return_anchors=False,
            )
            repeated = (
                condition.unsqueeze(0)
                .expand(args.members, *condition.shape)
                .flatten(0, 1)
            )
            initial = model.initialize(
                repeated,
                None,
                None,
                data.mask,
                torch.Generator(device="cuda").manual_seed(904001 + index),
            )[:, -1].float()
        if not torch.isfinite(initial).all():
            raise ValueError("Nonfinite initializer")
        physical = (
            initial[:, model.surface] * data.std[0, 0, model.surface]
            + data.mean[0, 0, model.surface]
        )
        gold = torch.as_tensor(
            sample["raw"]["surface"][model.history - 1], device="cuda"
        )
        metrics = score(
            physical,
            gold,
            data.mask[model.surface],
            torch.as_tensor(data.grid["lat"], device="cuda"),
        )
        results.append(dict(origin=path.stem, **metrics))
        np.savez_compressed(
            args.output / f"initial-{path.stem}.npz",
            initial=initial[:, [38, 76, 47, 66]].cpu().numpy(),
            channel_names=data.grid["names"][[38, 76, 47, 66]],
            mean=data.grid["mean"][[38, 76, 47, 66]],
            std=data.grid["std"][[38, 76, 47, 66]],
            mask=data.grid["mask"][[38, 76, 47, 66]],
        )
    atomic_json(
        dict(
            checkpoint_sha256=digest(args.checkpoint),
            step=saved["step"],
            contract=saved["contract"],
            weights="raw" if args.raw else "ema",
            members=args.members,
            fields=["thetao_0", "zos"],
            units=["degC", "m"],
            scope="latest-history surface reconstruction only",
            origins=results,
        ),
        args.output / "COMPLETE.json",
    )


if __name__ == "__main__":
    main()
