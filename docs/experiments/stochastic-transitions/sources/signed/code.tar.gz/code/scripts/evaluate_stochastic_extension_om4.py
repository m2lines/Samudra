# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Single-case held-out OM4 initializer curves; never run the processor."""

import argparse
import gc
import inspect
import json
import time
from pathlib import Path

import numpy as np
import torch


def score(draws, gold, mask, lat):
    """Area-weighted per-channel metrics, with fair finite-ensemble CRPS."""
    valid = mask.bool() & torch.isfinite(gold)
    weight = valid * torch.cos(torch.deg2rad(lat))[None, :, None]
    denominator = weight.sum((-2, -1))
    if (denominator <= 0).any():
        raise ValueError("Empty channel support")
    x = torch.where(valid, draws.float(), 0)
    y = torch.where(valid, gold.float(), 0)
    mean = x.mean(0)
    member_mse = ((x - y).square() * weight).sum((-2, -1)) / denominator
    mean_mse = ((mean - y).square() * weight).sum((-2, -1)) / denominator
    absolute = (x - y).abs().mean(0)
    spread = torch.zeros_like(gold)
    for i in range(len(x)):
        for j in range(i):
            spread.add_((x[i] - x[j]).abs())
    spread /= len(x) * (len(x) - 1)
    crps = ((absolute - spread) * weight).sum((-2, -1)) / denominator
    return dict(
        mean_mse=mean_mse.cpu().tolist(),
        member_mse=member_mse.cpu().tolist(),
        fair_crps=crps.cpu().tolist(),
    )


@torch.no_grad()
def main():
    import cftime
    import zarr

    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_pilot import atomic_json, digest
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.stochastic_transition_train import build_model

    parser = argparse.ArgumentParser(description=__doc__)
    for key in ["root", "data", "om4", "training-om4", "output"]:
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument(
        "--variant",
        choices=["B-multiscale-fair-crps", "B-initializer-only"],
        required=True,
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.cuda.set_device(0)
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    paths = data.paths("validation")
    assert len(paths) == 9 and paths[2].stem == "2014-01"
    sample = data.load(paths[2])
    raw = sample["raw"]
    wanted = (
        np.asarray(raw["midpoints"][:19], dtype="datetime64[s]").astype(str).tolist()
    )
    assert wanted[-1] == "2013-12-29T12:00:00"
    store = zarr.open_consolidated(str(args.om4), mode="r")
    ta = store["time"]
    dates = cftime.num2date(
        ta[:], ta.attrs["units"], ta.attrs.get("calendar", "standard")
    )
    labels = [d.strftime("%Y-%m-%dT%H:%M:%S") for d in dates]
    if any(labels.count(t) != 1 for t in wanted):
        raise ValueError("History has no exact unique OM4 matches")
    indices = [labels.index(t) for t in wanted]
    if not np.array_equal(np.diff(indices), np.ones(18)):
        raise ValueError("Noncontiguous OM4 history")
    names = data.grid["names"].tolist()
    mask = np.stack(
        [store[f"mask_{i}"][:] for i in range(19)] * 4 + [store["mask_0"][:]]
    ).astype(bool)
    np.testing.assert_array_equal(mask, data.grid["mask"])
    np.testing.assert_allclose(store["y"][:], data.grid["lat"], atol=1e-6, rtol=0)
    np.testing.assert_allclose(store["x"][:], data.grid["lon"], atol=1e-6, rtol=0)
    surface = np.stack(
        [np.stack([store[n][i] for n in ["thetao_0", "zos"]]) for i in indices]
    ).astype(np.float32)
    gold = np.stack([store[n][indices[-1]] for n in names]).astype(np.float32)
    if (
        not np.isfinite(surface[:, mask[[38, 76]]]).all()
        or not np.isfinite(gold[mask]).all()
    ):
        raise ValueError("Nonfinite OM4 wet fields")
    normalized = np.where(
        mask[[38, 76]],
        (surface - data.grid["mean"][[38, 76], None, None])
        / data.grid["std"][[38, 76], None, None],
        0,
    )
    surface_tensor = data.tensor(normalized)[None]
    validity = data.tensor(np.broadcast_to(mask[[38, 76]], surface.shape))[None]
    gold_tensor = data.tensor(np.where(mask, gold, 0))
    lat = data.tensor(data.grid["lat"])
    reader = ModelMonths(
        args.training_om4 / "OM4.zarr", "om4", data.grid, args.training_om4
    )
    assert len(reader.windows) == 409
    # The constructor enumerates only target months through July 2013; save
    # the actual window descriptors and source, not merely packed-cache bounds.
    last_target_end = max(reader.bounds[window[1] - 1, 1] for window in reader.windows)
    if str(last_target_end)[:10] >= "2013-12-27":
        raise ValueError("Training target overlaps initializer validation bin")
    provenance = dict(
        case="2014-01 OM4 surface-history initializer only",
        cohort="one fixed held-out case, not nine-origin validation",
        history_midpoints=wanted,
        history_indices=indices,
        gold_midpoint=wanted[-1],
        seed=904003,
        members=8,
        ema=True,
        normalization="existing grid.npz statistics",
        grid_sha256=digest(args.data / "grid.npz"),
        statistics_sha256=digest(args.data / "statistics.npz"),
        sample=str(paths[2]),
        sample_sha256=digest(paths[2]),
        om4=str(args.om4),
        om4_metadata_sha256=digest(args.om4 / ".zmetadata"),
        om4_version_note="Published Torch OM4 gold; differs from staged training store metadata",
        training_om4=str(args.training_om4),
        training_window_count=len(reader.windows),
        training_target_cutoff="2013-07",
        training_latest_target_bin_end=str(last_target_end),
        training_window_first=repr(reader.windows[0]),
        training_window_last=repr(reader.windows[-1]),
        training_reader_source=inspect.getsource(ModelMonths),
        training_reader_sha256=digest(Path(inspect.getfile(ModelMonths))),
        input_scope="19 SST/SSH history bins plus same ERA5 history and last context; zero future fields or gold interior passed to model",
        area="cos(latitude), full latitude wet mask; equal-depth variable aggregation",
        script_sha256=digest(Path(__file__)),
    )
    atomic_json(provenance, args.output / "input.json")
    del reader
    results = []
    for arm in [args.variant.split("-")[0]]:
        for step in range(500, 2001, 500):
            started = time.monotonic()
            path = args.root / "production" / args.variant / f"step-{step:05d}.pt"
            saved = torch.load(path, map_location="cpu", weights_only=False)
            if saved["step"] != step or saved["contract"]["arm"] != arm:
                raise ValueError("Checkpoint identity differs")
            model = build_model(saved, data, use_ema=True).eval()
            del saved
            generator = torch.Generator(device="cuda").manual_seed(904003)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                conditioning, _, _ = model.encode_native(
                    surface_tensor,
                    sample["atmosphere"][:, :19],
                    sample["contexts"][:, 18],
                    data.mask,
                    validity,
                    return_anchors=False,
                )
                conditioning = (
                    conditioning.unsqueeze(0)
                    .expand(8, *conditioning.shape)
                    .flatten(0, 1)
                )
                initial = model.initialize(
                    conditioning, None, None, data.mask, generator
                )[:, -1].float()
            if not torch.isfinite(initial).all():
                raise ValueError(f"Nonfinite {arm}/{step} initializer")
            draws = initial * data.std[0, 0] + data.mean[0, 0]
            values = score(draws, gold_tensor, data.mask, lat)
            mse = np.array(values["mean_mse"])
            member_mse = np.array(values["member_mse"])
            crps = np.array(values["fair_crps"])
            groups = {}
            for var in ["uo", "vo", "thetao", "so", "zos"]:
                ids = [
                    i
                    for i, n in enumerate(names)
                    if n == var or n.startswith(var + "_")
                ]
                groups[var] = dict(
                    mean_rmse=float(np.sqrt(mse[ids].mean())),
                    member_rmse=float(np.sqrt(member_mse[:, ids].mean())),
                    fair_crps=float(crps[ids].mean()),
                    member_rmse_individual=np.sqrt(member_mse[:, ids].mean(1)).tolist(),
                )
            row = dict(
                arm=arm,
                variant=args.variant,
                step=step,
                checkpoint_sha256=digest(path),
                groups=groups,
                channel_names=names,
                per_channel=dict(
                    mean_rmse=np.sqrt(mse).tolist(),
                    member_rmse=np.sqrt(member_mse.mean(0)).tolist(),
                    fair_crps=crps.tolist(),
                ),
                seconds=time.monotonic() - started,
            )
            atomic_json(row, args.output / f"{arm}-{step:05d}.json")
            results.append(row)
            print(
                json.dumps(
                    dict(arm=arm, step=step, groups=groups, seconds=row["seconds"])
                ),
                flush=True,
            )
            del model, conditioning, initial, draws
            gc.collect()
            torch.cuda.empty_cache()
    import csv

    with (args.output / "variable-metrics.csv").open("w") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "arm",
                "step",
                "variable",
                "mean_rmse",
                "member_rmse",
                "fair_crps",
            ],
        )
        writer.writeheader()
        for row in results:
            for variable, group in row["groups"].items():
                writer.writerow(
                    dict(
                        arm=row["arm"],
                        step=row["step"],
                        variable=variable,
                        **{
                            key: group[key]
                            for key in ["mean_rmse", "member_rmse", "fair_crps"]
                        },
                    )
                )
    atomic_json(
        dict(
            complete=True,
            case=provenance["case"],
            input_sha256=digest(args.output / "input.json"),
            results=results,
        ),
        args.output / "COMPLETE.json",
    )


if __name__ == "__main__":
    main()
