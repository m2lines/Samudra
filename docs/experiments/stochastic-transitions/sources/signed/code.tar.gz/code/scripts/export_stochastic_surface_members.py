#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Export additional physical surface fields using the original evaluation draws."""

import argparse
import gc
import json
from datetime import timedelta
from pathlib import Path

import numpy as np
import torch

from samudra.experiments.observation_pilot import atomic_json, digest
from samudra.experiments.observation_training import Samples
from samudra.experiments.stochastic_transition_train import build_model


def export_om4(path, output, sample, data, names):
    """Contemporaneous published OM4 comparison, not observation ground truth."""
    import cftime
    import zarr

    store = zarr.open_consolidated(str(path), mode="r")
    time = store["time"]
    calendar = time.attrs.get("calendar", "standard")
    dates = cftime.num2date(time[:], time.attrs["units"], calendar)
    labels = [date.strftime("%Y-%m-%dT%H:%M:%S") for date in dates]
    wanted = [str(np.datetime64(sample["raw"]["midpoints"][i], "s")) for i in (18, 24)]
    if wanted != ["2013-12-29T12:00:00", "2014-01-28T12:00:00"]:
        raise ValueError(f"Unexpected example interval midpoints: {wanted}")
    indices = []
    for label in wanted:
        if labels.count(label) != 1:
            raise ValueError(f"OM4 time must uniquely match {label}")
        indices.append(labels.index(label))
    lat, lon = store["y"][:], store["x"][:]
    np.testing.assert_allclose(lat, data.grid["lat"], rtol=0, atol=1e-6)
    np.testing.assert_allclose(lon, data.grid["lon"], rtol=0, atol=1e-6)
    wet = store["mask_0"][:].astype(bool)
    fields = np.stack(
        [np.stack([store[name][index] for name in names]) for index in indices]
    )
    if not np.isfinite(fields[:, :, wet]).all():
        raise ValueError("Nonfinite contemporaneous OM4 values on declared wet support")
    filename = output / "OM4-comparison-2014-01.npz"
    temporary = filename.with_suffix(".tmp.npz")
    np.savez_compressed(
        temporary,
        initial=fields[0],
        day30=fields[1],
        channel_names=np.asarray(names),
        units=np.asarray([store[n].attrs.get("units", "unknown") for n in names]),
        mask=np.broadcast_to(wet, fields.shape[1:]),
        lat=lat,
        lon=lon,
        midpoints=np.asarray(wanted),
    )
    temporary.replace(filename)
    receipt = dict(
        source=str(path),
        source_metadata_sha256=digest(path / ".zmetadata"),
        source_attributes=dict(store.attrs),
        calendar=calendar,
        indices=indices,
        midpoint_labels=wanted,
        interval_bounds=[
            [str(dates[i] - timedelta(days=2.5)), str(dates[i] + timedelta(days=2.5))]
            for i in indices
        ],
        label="Contemporaneous published OM4 v3 comparison; not observation ground truth and not the staged Beta training-store version",
        output=str(filename),
        output_sha256=digest(filename),
        channels=names,
    )
    atomic_json(receipt, output / "OM4-COMPLETE.json")
    return receipt


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--om4", type=Path)
    parser.add_argument("--arms", nargs="+", choices=list("ABC"), default=list("ABC"))
    args = parser.parse_args()
    torch.cuda.set_device(0)
    data = Samples(args.data, "cuda", surface_fill="zero", global_observations=True)
    paths = data.paths("validation")
    if len(paths) != 9 or paths[2].stem != "2014-01":
        raise ValueError("Expected original nine-origin cohort, January 2014 at index2")
    sample = data.load(paths[2])
    names = data.grid["names"].tolist()
    export_names = ["uo_0", "vo_0", "so_0", "thetao_0", "zos"]
    channels = [names.index(name) for name in export_names]
    args.output.mkdir(parents=True, exist_ok=True)
    receipts = {}
    for arm in args.arms:
        checkpoint = args.root / "production" / arm / "step-05000.pt"
        original_path = (
            args.root
            / "production"
            / arm
            / "evaluation"
            / "step-05000-ema"
            / "members-2014-01.npz"
        )
        completion = json.loads((original_path.parent / "COMPLETE.json").read_text())
        checkpoint_sha = digest(checkpoint)
        if (
            completion["checkpoint_sha256"] != checkpoint_sha
            or completion["weights"] != "ema"
        ):
            raise ValueError("Saved maps and selected checkpoint provenance differ")
        saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if saved["step"] != 5000 or saved["contract"]["arm"] != arm:
            raise ValueError("Unexpected final checkpoint")
        model = build_model(saved, data, use_ema=True).eval()
        del saved
        generator = torch.Generator(device=data.device).manual_seed(904003)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            draws, initial = model.forecast(
                sample["surface"],
                sample["atmosphere"],
                sample["contexts"],
                data.mask,
                sample["validity"],
                generator=generator,
                members=8,
            )
        if not torch.isfinite(draws).all() or not torch.isfinite(initial).all():
            raise ValueError(f"{arm}: nonfinite generated field")
        arrays = dict(
            initial=initial[:, 0, -1, channels].float().cpu().numpy(),
            day30=draws[:, 0, 5, channels].float().cpu().numpy(),
        )
        checks = {}
        with np.load(original_path, allow_pickle=False) as original:
            for phase in ("initial", "day30"):
                for name in ("thetao_0", "zos"):
                    expected = original[phase][
                        :, original["channel_names"].tolist().index(name)
                    ]
                    actual = arrays[phase][:, export_names.index(name)]
                    delta = actual.astype(np.float64) - expected.astype(np.float64)
                    check = dict(
                        maximum_absolute_difference=float(np.max(np.abs(delta))),
                        rms_difference=float(np.sqrt(np.mean(delta**2))),
                        bitwise_equal=bool(np.array_equal(actual, expected)),
                        atol=1e-6,
                        rtol=1e-6,
                    )
                    checks[f"{phase}/{name}"] = check
                    print(
                        json.dumps(
                            dict(arm=arm, crosscheck=f"{phase}/{name}", **check)
                        ),
                        flush=True,
                    )
                    np.testing.assert_allclose(
                        actual,
                        expected,
                        atol=1e-6,
                        rtol=1e-6,
                        err_msg=f"{arm} {phase} {name} differs from original draws",
                    )
        output = args.output / f"{arm}-members-2014-01.npz"
        temporary = output.with_suffix(".tmp.npz")
        np.savez_compressed(
            temporary,
            **arrays,
            channel_names=np.asarray(export_names),
            units="normalized; use included mean/std",
            mean=data.grid["mean"][channels],
            std=data.grid["std"][channels],
            mask=data.grid["mask"][channels],
            lat=data.grid["lat"],
            lon=data.grid["lon"],
            initial_surface_reference=sample["raw"]["surface"][18],
            day30_surface_reference=sample["raw"]["surface"][24],
            surface_reference_names=np.asarray(["thetao_0", "zos"]),
        )
        temporary.replace(output)
        receipts[arm] = dict(
            checkpoint=str(checkpoint),
            checkpoint_sha256=checkpoint_sha,
            original_maps=str(original_path),
            original_maps_sha256=digest(original_path),
            output=str(output),
            output_sha256=digest(output),
            weights="ema",
            step=5000,
            seed=904003,
            origin="2014-01",
            origin_index=2,
            members=8,
            channels=export_names,
            crosschecks=checks,
        )
        atomic_json(receipts[arm], args.output / f"{arm}-COMPLETE.json")
        del draws, initial, model
        gc.collect()
        torch.cuda.empty_cache()
    om4 = (
        export_om4(args.om4, args.output, sample, data, export_names)
        if args.om4
        else None
    )
    atomic_json(
        dict(arms=receipts, om4=om4, complete=True), args.output / "COMPLETE.json"
    )


if __name__ == "__main__":
    main()
