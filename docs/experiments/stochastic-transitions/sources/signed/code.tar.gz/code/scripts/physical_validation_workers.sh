#!/bin/bash
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
base=/projects/ny/lz1955/multiscale/jrusak
common=(--data "$base/data/obs_full_range/d-observation-pilot/samples"
 --annual-data "$base/data/obs_full_range/d-observation-pilot/annual-instance-v1"
 --checkpoint "$base/runs/physical-state-four-beta-20261025/production/step-01200.pt"
 --training-reference "$base/runs/shared-era5-optimized-20261024/optimized/paths.json"
 --reference "$base/runs/stochastic-state-replay-v1/checkpoints/selection-reference.json"
 --members 8)
pids=()
stop_workers() { for pid in "${pids[@]}"; do kill "$pid" 2>/dev/null || true; done; }
trap stop_workers EXIT
CUDA_VISIBLE_DEVICES=0 /workspace/.venv/bin/python -m samudra.experiments.physical_state_evaluate "${common[@]}" --annual-split validation --origins 2013-11-01 --output "$PHYSICAL_EVAL_ROOT/validation" > "$PHYSICAL_EVAL_ROOT/validation.log" 2>&1 &
pids+=("$!")
origins=(2015-01-01 2018-01-01 2021-01-01)
for i in 0 1 2; do
 CUDA_VISIBLE_DEVICES=$((i+1)) /workspace/.venv/bin/python -m samudra.experiments.physical_state_evaluate "${common[@]}" --skip-validation --annual-split test --origins "${origins[$i]}" --output "$PHYSICAL_EVAL_ROOT/test-${origins[$i]}" > "$PHYSICAL_EVAL_ROOT/test-${origins[$i]}.log" 2>&1 &
 pids+=("$!")
done
for pid in "${pids[@]}"; do wait "$pid"; done
trap - EXIT
