# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Plot initializer-only held-out surface scores from saved validation draws."""
import argparse
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

p=argparse.ArgumentParser()
p.add_argument('--input',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
df=pd.read_csv(a.input)
a.output.mkdir(parents=True,exist_ok=True)
labels={'A':'A · deterministic','B':'B · stochastic initializer','C':'C · stochastic initializer + processor'}
colors={'A':'#777777','B':'#d55e00','C':'#0072b2'}
markers={'A':'o','B':'s','C':'^'}
for weights in ['ema','raw']:
 fig,axes=plt.subplots(2,2,figsize=(10,7),sharex=True)
 for col,(field,unit) in enumerate([('SST','°C'),('SSH','cm')]):
  scale=100 if field=='SSH' else 1
  for row,(metric,title) in enumerate([('ensemble_mean_rmse','Ensemble-mean RMSE'),('fair_crps','Fair CRPS')]):
   ax=axes[row,col]
   for arm in 'ABC':
    v=df[(df.arm==arm)&(df.weights==weights)&(df.field==field)].sort_values('updates')
    ax.plot(v.updates,v[metric]*scale,color=colors[arm],marker=markers[arm],markersize=4,linewidth=2 if arm=='C' else 1.4,label=labels[arm])
   ax.axvspan(4000,5000,color='#dddddd',alpha=.5,zorder=-5)
   ax.axvline(4000,color='#555555',linewidth=.8)
   ax.set_title(f'{field} · {title}',fontsize=11)
   ax.set_ylabel(unit);ax.grid(alpha=.18);ax.set_xlim(400,5100)
   ax.tick_params(labelsize=9)
   if row==1:ax.set_xlabel('Total optimizer updates')
 handles,ls=axes[0,0].get_legend_handles_labels()
 fig.legend(handles,ls,loc='lower center',ncol=3,fontsize=9,bbox_to_anchor=(.5,.04))
 fig.suptitle(f'Initialization validation · {weights.upper()} weights',fontsize=15)
 fig.text(.5,.925,'Latest history state; nine held-out origins; eight members; lower is better',ha='center',fontsize=10)
 fig.text(.5,.012,'Shaded: 1,000 observation-only cooldown updates after 4,000 mixed updates. Observed input reconstruction, not forecast skill.',ha='center',fontsize=9)
 fig.tight_layout(rect=(0,.085,1,.91))
 for ext in ['png','pdf']:fig.savefig(a.output/f'initialization-surface-{weights}.{ext}',dpi=180)
 plt.close(fig)
