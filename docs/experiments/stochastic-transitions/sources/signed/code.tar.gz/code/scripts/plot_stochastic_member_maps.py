# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Plot saved final-EMA members and pointwise fair-CRPS decomposition on CPU."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
grid=np.load(a.root/'grid.npz');ref=np.load(a.root/'reference-2014-01.npz');meta={}
units=['°C','cm','°C','PSU'];names=['SST','SSH','Temperature at level 9','Salinity at level 9'];keys=['sst','ssh','thetao9','so9'];factor=np.array([1,100,1,1])

def load(arm,name):
 with np.load(a.root/arm/'evaluation/step-05000-ema'/name) as z:
  out={k:z[k] for k in z.files}
 for k in ['day30','initial']:
  out[k]=(out[k].astype(float)*out['std'][None,:,None,None]+out['mean'][None,:,None,None])*factor[None,:,None,None]
  out[k]=np.where(out['mask'][None],out[k],np.nan)
 out['day30_reference']=out['day30_reference']*factor[:2,None,None]
 return out

def panel(ax,x,title,lo,hi,cmap='viridis'):
 im=ax.imshow(x,origin='lower',extent=[0,360,float(grid['lat'].min()),float(grid['lat'].max())],interpolation='nearest',vmin=lo,vmax=hi,cmap=cmap,aspect='auto')
 ax.set_title(title,fontsize=9);ax.set_xticks([0,120,240,360]);ax.set_yticks([-60,0,60]);ax.tick_params(labelsize=7);ax.set_facecolor('#dddddd');return im

sample={arm:load(arm,'members-2014-01.npz') for arm in 'ABC'}
for time in ['initial','day30']:
 for c,key in enumerate(keys):
  arrays=[sample[arm][time][:,c] for arm in 'ABC']
  gold=ref['surface'][18,c]*factor[c] if c<2 and time=='initial' else sample['A']['day30_reference'][c] if c<2 else None
  wet=sample['A']['mask'][c].astype(bool)
  if gold is not None:gold=np.where(wet,gold,np.nan)
  pool=np.concatenate([x[np.isfinite(x)] for x in arrays]+([gold[np.isfinite(gold)]] if gold is not None else []))
  lo,hi=np.percentile(pool,[1,99]);meta[f'{key}-{time}']={'vmin':float(lo),'vmax':float(hi),'display_limits':'pooled 1st/99th percentiles; no smoothing'}
  fig,axes=plt.subplots(10,2,figsize=(13,24),layout='constrained')
  if gold is not None: panel(axes[0,0],gold,'Observations (same five-day bin)',lo,hi)
  else:
   axes[0,0].axis('off');axes[0,0].text(.5,.5,'No instantaneous interior observation reference\nMonthly interior targets are not a time-matched reference',ha='center',va='center',transform=axes[0,0].transAxes,fontsize=10)
  panel(axes[0,1],sample['A'][time][0,c],'A: deterministic control',lo,hi)
  for j,arm in enumerate('BC'):
   panel(axes[1,j],np.mean(sample[arm][time][:,c],0),f'{arm}: ensemble mean',lo,hi)
   for m in range(8):im=panel(axes[m+2,j],sample[arm][time][m,c],f'{arm}: member {m+1}',lo,hi)
  fig.colorbar(im,ax=axes,label=units[c],shrink=.45,extend='both')
  fig.suptitle(f'{names[c]} · {"Initialization: Dec 27–31, 2013" if time=="initial" else "Day 30: Jan 26–30, 2014"}\nFinal EMA · shared limits · native pixels · tails clipped for display',fontsize=13)
  fig.savefig(a.output/f'{key}-{time}.png',dpi=125);plt.close(fig)

origin_names=sorted(p.name for p in (a.root/'A/evaluation/step-05000-ema').glob('members-*.npz'))
for scope,origins in [('2014-01',['members-2014-01.npz']),('nine-origins',origin_names)]:
 sums={arm:np.zeros((3,2,180,360)) for arm in 'ABC'};counts=np.zeros((2,180,360))
 for name in origins:
  origin={arm:load(arm,name) for arm in 'ABC'}
  y=origin['A']['day30_reference'];valid=np.isfinite(y)&origin['A']['mask'][:2].astype(bool)&grid['mask'][0].astype(bool)
  counts+=valid
  for arm,z in origin.items():
   np.testing.assert_array_equal(y,z['day30_reference'])
   x=z['day30'][:,:2];absolute=np.abs(x-y).mean(0);spread=sum(np.abs(x[i]-x[j]) for i in range(8) for j in range(i))/(8*7)
   terms=np.stack([absolute,spread,absolute-spread]);sums[arm]+=np.where(valid[None],terms,0)
 means={arm:np.divide(x,counts[None],out=np.full_like(x,np.nan),where=counts[None]>0) for arm,x in sums.items()}
 for c,key in enumerate(keys[:2]):
  fig,axes=plt.subplots(4,3,figsize=(16,11),layout='constrained');titles=['Mean member absolute error','Spread subtraction (positive)','Fair CRPS = error − spread']
  for term in range(3):
   pool=np.concatenate([means[arm][term,c][np.isfinite(means[arm][term,c])] for arm in 'ABC']);hi=np.percentile(pool,99);lo=min(0,float(np.percentile(pool,1)))
   for row,arm in enumerate('ABC'):
    im=panel(axes[row,term],means[arm][term,c],f'{arm}: {titles[term]}',lo,hi,'magma')
   fig.colorbar(im,ax=axes[:3,term],label=units[c],shrink=.6,extend='both')
   delta=means['C'][term,c]-means['B'][term,c];lim=max(float(np.nanpercentile(np.abs(delta),99)),1e-8)
   im=panel(axes[3,term],delta,f'C − B: {titles[term]}',-lim,lim,'RdBu_r');fig.colorbar(im,ax=axes[3,term],label=units[c],shrink=.7,extend='both')
  fig.suptitle(f'Day-30 {names[c]} CRPS decomposition · {scope}\nPointwise origin mean; no spatial smoothing. Positive C−B CRPS means C is worse.',fontsize=13)
  fig.savefig(a.output/f'crps-{key}-{scope}.png',dpi=150);plt.close(fig)
 np.savez_compressed(a.output/f'crps-terms-{scope}.npz',**means,count=counts,lat=grid['lat'],lon=grid['lon'])
(a.output/'display-limits.json').write_text(json.dumps(meta,indent=2)+'\n')
