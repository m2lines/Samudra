# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Plot fixed-case, held-out OM4 initializer reconstruction scores."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
root=Path('docs/experiments/stochastic-transitions/results/initialization/om4')
df=pd.read_csv(root/'variable-metrics.csv')
labels={'A':'A · deterministic','B':'B · stochastic initializer','C':'C · stochastic initializer + processor'}
colors={'A':'#777777','B':'#d55e00','C':'#0072b2'}
markers={'A':'o','B':'s','C':'^'}
for metric,title in [('mean_rmse','Ensemble-mean RMSE'),('member_rmse','RMS error across members'),('fair_crps','Fair CRPS')]:
 fig,axes=plt.subplots(2,2,figsize=(10,7),sharex=True)
 for ax,(variable,label,unit,scale) in zip(axes.flat,[('thetao','Temperature','°C',1),('so','Salinity','psu',1),('uo','Zonal velocity','cm/s',100),('vo','Meridional velocity','cm/s',100)]):
  for arm in 'ABC':
   v=df[(df.arm==arm)&(df.variable==variable)].sort_values('step')
   ax.plot(v.step,v[metric]*scale,color=colors[arm],marker=markers[arm],markersize=4,linewidth=2 if arm=='C' else 1.4,label=labels[arm])
  ax.axvspan(4000,5000,color='#dddddd',alpha=.5,zorder=-5)
  ax.axvline(4000,color='#555555',linewidth=.8)
  ax.set_title(label,fontsize=11);ax.set_ylabel(unit);ax.grid(alpha=.18);ax.set_xlim(400,5100)
 for ax in axes[1]:ax.set_xlabel('Total optimizer updates')
 handles,ls=axes[0,0].get_legend_handles_labels()
 fig.legend(handles,ls,loc='lower center',ncol=3,fontsize=9,bbox_to_anchor=(.5,.045))
 fig.suptitle(f'OM4 interior initialization · {title}',fontsize=15)
 fig.text(.5,.925,'One held-out January 2014 case · EMA weights · eight members · lower is better',ha='center',fontsize=10)
 fig.text(.5,.012,'Cosine-latitude-weighted wet cells; 19 depths weighted equally. Shaded: observation-only cooldown.',ha='center',fontsize=9)
 fig.tight_layout(rect=(0,.09,1,.91))
 for ext in ['png','pdf']:fig.savefig(root/f'initialization-om4-{metric}.{ext}',dpi=180)
 plt.close(fig)
