# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Plot CPU-exported physical surface members beside contemporaneous OM4.

Input: {A,B,C}-members-2014-01.npz and OM4-comparison-2014-01.npz.
OM4 is a model comparison, not observational ground truth.
"""

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

DATES = {"initial": "Dec 27–31, 2013", "day30": "Jan 26–30, 2014"}
FIELDS = {
    "uo_0": ("Surface zonal velocity", "m/s", "RdBu_r"),
    "vo_0": ("Surface meridional velocity", "m/s", "RdBu_r"),
    "so_0": ("Surface salinity", "PSU", "viridis"),
}


def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}


def file_record(path):
    return {
        "path": str(path.resolve()),
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def edges(centers):
    centers = np.asarray(centers, dtype=float)
    if centers.ndim != 1 or len(centers) < 2 or not np.all(np.diff(centers) > 0):
        raise ValueError("Coordinates must be increasing one-dimensional cell centers")
    middle = (centers[:-1] + centers[1:]) / 2
    return np.r_[2 * centers[0] - middle[0], middle, 2 * centers[-1] - middle[-1]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, help="Optional export provenance JSON")
    parser.add_argument("--no-summary", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    paths = {arm: args.root / f"{arm}-members-2014-01.npz" for arm in "ABC"}
    paths["OM4"] = args.root / "OM4-comparison-2014-01.npz"
    data = {key: load(path) for key, path in paths.items()}
    reference = data["OM4"]
    names = reference["channel_names"].astype(str).tolist()
    lat, lon = reference["lat"], reference["lon"]
    lat_edges, lon_edges = edges(lat), edges(lon)
    shape = (len(names), len(lat), len(lon))
    for key, record in data.items():
        np.testing.assert_array_equal(record["lat"], lat)
        np.testing.assert_array_equal(record["lon"], lon)
        np.testing.assert_array_equal(record["channel_names"].astype(str), names)
        if record["mask"].shape != shape:
            raise ValueError(f"{key}: mask shape must be {shape}")
        for time in DATES:
            expected = shape if key == "OM4" else (8, *shape)
            if record[time].shape != expected:
                raise ValueError(
                    f"{key} {time}: expected {expected}, got {record[time].shape}"
                )
            values = record[time].astype(np.float64)
            if key != "OM4":
                if record["mean"].shape != (len(names),) or record["std"].shape != (
                    len(names),
                ):
                    raise ValueError(f"{key}: invalid normalization shape")
                if not np.all(np.isfinite(record["std"]) & (record["std"] > 0)):
                    raise ValueError(
                        f"{key}: normalization std must be positive and finite"
                    )
                values = (
                    values * record["std"][None, :, None, None]
                    + record["mean"][None, :, None, None]
                )
            record[time] = np.where(record["mask"].astype(bool), values, np.nan)
    # Arm A is replicated for a shared export API, not an eight-member ensemble.
    for time in DATES:
        np.testing.assert_allclose(
            data["A"][time],
            np.broadcast_to(data["A"][time][0], (8, *shape)),
            equal_nan=True,
        )

    provenance = {
        "inputs": {key: file_record(path) for key, path in paths.items()},
        "reference": "Contemporaneous published-v3 OM4 comparison, NOT observational ground truth; no pixelwise truth claim.",
        "bin_dates": DATES,
        "om4_midpoints": reference["midpoints"].astype(str).tolist(),
        "rendering": "Native cells, no smoothing; shared pooled 1st/99th percentile limits, tails clipped for display.",
        "panels": "OM4 / A deterministic; B mean / C mean; then B / C members 1–8",
        "figures": {},
    }
    if args.receipt:
        provenance["export_receipt"] = json.loads(args.receipt.read_text())
        provenance["export_receipt_file"] = file_record(args.receipt)

    for time, date in DATES.items():
        for field, (label, unit, cmap) in FIELDS.items():
            channel = names.index(field)
            om4 = reference[time][channel]
            control = data["A"][time][0, channel]
            members = {arm: data[arm][time][:, channel] for arm in "BC"}
            means = {arm: values.mean(axis=0) for arm, values in members.items()}
            arrays = [om4, control, *means.values(), *members["B"], *members["C"]]
            pool = np.concatenate([array[np.isfinite(array)] for array in arrays])
            if pool.size == 0:
                raise ValueError(f"No finite cells for {field}/{time}")
            low, high = np.percentile(pool, [1, 99])
            if field.startswith(("uo", "vo")):
                high = max(abs(low), abs(high), 1e-8)
                low = -high
            elif high <= low:
                low, high = low - 1e-8, high + 1e-8

            def panel(ax, values, title):
                image = ax.pcolormesh(
                    lon_edges,
                    lat_edges,
                    values,
                    shading="flat",
                    cmap=cmap,
                    vmin=low,
                    vmax=high,
                    rasterized=True,
                )
                ax.set_title(title, fontsize=9)
                ax.set_xticks([0, 120, 240, 360])
                ax.set_yticks([-60, 0, 60])
                ax.tick_params(labelsize=7)
                ax.set_facecolor("#dddddd")
                # Equal native-cell aspect for the regular one-degree grid.
                ax.set_box_aspect(len(lat) / len(lon))
                return image

            title = f"{label} · {'Initialization' if time == 'initial' else 'Day 30'} · {date}\nFinal EMA · shared limits · native cells · OM4 is a model comparison, not ground truth"
            fig, axes = plt.subplots(10, 2, figsize=(14, 35), layout="constrained")
            panel(axes[0, 0], om4, "Contemporaneous OM4 (not ground truth)")
            panel(axes[0, 1], control, "A: deterministic control")
            for column, arm in enumerate("BC"):
                panel(axes[1, column], means[arm], f"{arm}: mean of 8 members")
                for member in range(8):
                    image = panel(
                        axes[member + 2, column],
                        members[arm][member],
                        f"{arm}: member {member + 1}",
                    )
            fig.colorbar(image, ax=axes, label=unit, shrink=0.35, extend="both")
            fig.suptitle(title, fontsize=13)
            stem = f"{field}-{time}"
            fig.savefig(args.output / f"{stem}.png", dpi=120)
            plt.close(fig)
            files = [f"{stem}.png"]
            if not args.no_summary:
                fig, axes = plt.subplots(2, 2, figsize=(14, 8), layout="constrained")
                for ax, values, subtitle in zip(
                    axes.flat,
                    [om4, control, means["B"], means["C"]],
                    [
                        "OM4 (not ground truth)",
                        "A: deterministic control",
                        "B: mean of 8 members",
                        "C: mean of 8 members",
                    ],
                    strict=True,
                ):
                    image = panel(ax, values, subtitle)
                fig.colorbar(image, ax=axes, label=unit, shrink=0.75, extend="both")
                fig.suptitle(title, fontsize=12)
                fig.savefig(args.output / f"{stem}-summary.png", dpi=150)
                plt.close(fig)
                files.append(f"{stem}-summary.png")
            provenance["figures"][stem] = {
                "vmin": float(low),
                "vmax": float(high),
                "units": unit,
                "cmap": cmap,
                "finite_pooled_cells": int(pool.size),
                "files": files,
            }
    (args.output / "display-limits-provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
