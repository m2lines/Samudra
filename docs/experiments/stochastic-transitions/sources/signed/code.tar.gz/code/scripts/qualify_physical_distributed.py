# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Isolated real-data scaling qualification; never modifies the source pilot.

Run ``prepare`` once before torchrun, ``train`` on each worker, then ``report``
once after all workers exit. The same checkpoint and global batch are used for
each world size. This is an engineering benchmark, not a new scientific arm.
"""

import argparse
import hashlib
import json
import math
import os
import shutil
import statistics
import sys
import time
from pathlib import Path


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "train", "report"))
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--world-size", required=True, type=int, choices=(1, 4, 8))
    parser.add_argument("--updates", type=int, default=6)
    parser.add_argument("--microbatch", type=int, default=1, choices=(1, 4))
    parser.add_argument("--legacy-trainer", action="store_true")
    parser.add_argument("--hours", type=float, default=1.75)
    args = parser.parse_args()
    if args.updates < 4 or args.updates % 2:
        parser.error("Use an even number of at least four mixed updates")
    return args


def output_for(args):
    return args.root / f"world-{args.world_size}-micro-{args.microbatch}"


def prepare(args):
    started = time.time()
    output = output_for(args)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite benchmark output: {output}")
    if args.checkpoint.name != "step-00112.pt":
        raise ValueError("Scaling qualification is pinned to immutable step 112")
    output.mkdir(parents=True)
    destination = output / "last.pt"
    shutil.copyfile(args.checkpoint, destination)
    source_digest = digest(args.checkpoint)
    if digest(destination) != source_digest:
        raise ValueError("Isolated checkpoint copy did not verify")
    receipt = dict(
        started_unix=started,
        source_checkpoint=str(args.checkpoint.resolve()),
        source_checkpoint_sha256=source_digest,
        source_step=112,
        source_producer="0b044672c",
        benchmark_producer=os.environ["SAMUDRA_CODE_COMMIT"],
        reference=str(args.reference.resolve()),
        reference_sha256=digest(args.reference),
        world_size=args.world_size,
        microbatch=args.microbatch,
        effective_batch=8,
        updates=args.updates,
        cudnn_v8_disabled=True,
        scope="real-data scaling qualification; optimizer, EMA, replay and RNG restored",
    )
    (output / "BENCHMARK_INPUT.json").write_text(json.dumps(receipt, indent=2))


def train(args):
    if int(os.environ.get("WORLD_SIZE", "1")) != args.world_size:
        raise ValueError("torchrun world size differs from benchmark declaration")
    if os.environ.get("TORCH_CUDNN_V8_API_DISABLED") != "1":
        raise ValueError("The verified cuDNN workaround must reach every worker")
    if os.environ.get("CUDA_LAUNCH_BLOCKING", "0") != "0":
        raise ValueError("Diagnostic synchronization would invalidate timing")
    config = json.loads(args.reference.read_text())
    legacy = json.loads(Path(config["legacy_qualification"]).read_text())
    command = [
        sys.executable,
        "-m",
        "samudra.experiments.physical_state_train",
        "--root",
        str(args.root),
        "--output",
        str(output_for(args)),
        "--reference",
        str(args.reference),
        "--data",
        config["samples"],
        "--om4",
        config["om4"],
        "--packed-om4",
        legacy["packed_om4"],
        "--shared-era5",
        config["forcing_cache"],
        "--shared-era5-proof-sha256",
        config["forcing_proof_sha256"],
        "--replay-cache",
        config["replay_cache"],
        "--om4-warmup-updates",
        "100",
        "--updates-per-task",
        "500",
        "--obs-cooldown-updates",
        "100",
        "--effective-batch",
        "8",
        "--microbatch",
        str(args.microbatch),
        "--members",
        "2",
        "--sampling-steps",
        "8",
        "--checkpoint-every",
        str(args.updates),
        "--max-new-updates",
        str(args.updates),
        "--hours",
        str(args.hours),
        "--fused-adam",
        "--resume",
        "--smoke",
    ]
    if not args.legacy_trainer:
        command += ["--allow-execution-migration", "--check-rank-sync"]
    elif args.world_size != 1 or args.microbatch != 4:
        raise ValueError(
            "Legacy benchmark must match source single-GPU microbatch four"
        )
    os.execv(sys.executable, command)


def report(args):
    output = output_for(args)
    receipt = json.loads((output / "BENCHMARK_INPUT.json").read_text())
    events = [
        json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()
    ]
    state = json.loads((output / "state.json").read_text())
    expected = list(range(113, 113 + args.updates))
    if [event["step"] for event in events] != expected or state["step"] != expected[-1]:
        raise ValueError("Incomplete benchmark or duplicate/missing global updates")
    for index, event in enumerate(events):
        if event["task"] != ("om4" if index % 2 == 0 else "observation"):
            raise ValueError("Unexpected task sequence")
        if not all(
            math.isfinite(event[key]) for key in ("loss", "gradient_norm", "seconds")
        ):
            raise ValueError("Nonfinite benchmark result")
    if not args.legacy_trainer:
        sync = json.loads((output / "rank-sync.json").read_text())
        if sync["step"] != expected[-1] or sync["world_size"] != args.world_size:
            raise ValueError("Checkpoint replay synchronization was not verified")
        for event in events:
            if (
                event["world_size"] != args.world_size
                or event["rank_sync_max_abs"] != 0
            ):
                raise ValueError("Model parameters diverged across ranks")
            work = event["rank_work"]
            slots = [
                slot
                for rank in work
                for key in ("fresh_slots", "replay_slots")
                for slot in rank[key]
            ]
            if len(work) != args.world_size or sorted(slots) != list(range(8)):
                raise ValueError("Global batch slots omitted or duplicated")
    timings = {}
    for source in ("om4", "observation"):
        source_events = [event for event in events if event["task"] == source]
        # The first update of each task includes task-specific cold startup.
        seconds = [event["seconds"] for event in source_events[1:]]
        timings[source] = dict(
            measured_updates=len(seconds),
            median_seconds=statistics.median(seconds),
            mean_seconds=statistics.mean(seconds),
            min_seconds=min(seconds),
            max_seconds=max(seconds),
            cold_seconds=source_events[0]["seconds"],
        )
    result = dict(
        input=receipt,
        events=events,
        state=state,
        timings=timings,
        end_to_end_seconds=time.time() - receipt["started_unix"],
        timing_note="Step seconds exclude checkpoint IO and rank equality checks; end-to-end includes startup, copy verification, training, checks and checkpoint IO",
        scope="engineering throughput and correctness only; not rollout skill",
        cross_world_bitwise_equivalence_claimed=False,
    )
    (output / "BENCHMARK_RESULT.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(dict(world_size=args.world_size, timings=timings), indent=2))


if __name__ == "__main__":
    options = arguments()
    {"prepare": prepare, "train": train, "report": report}[options.stage](options)
