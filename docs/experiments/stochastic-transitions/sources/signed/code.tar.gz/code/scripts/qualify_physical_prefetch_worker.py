# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Exact input audit or deterministic training wrapper for I/O qualification."""

import argparse
import hashlib
import json
import os
import runpy
import sys
from pathlib import Path


def audit():
    import torch

    from samudra.experiments.monthly_model_data import ModelMonths
    from samudra.experiments.observation_training import Samples
    from samudra.experiments.shared_era5 import SharedEra5
    from samudra.experiments.task_schedule import sample_indices

    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--optimized", action="store_true")
    args = parser.parse_args(sys.argv[2:])
    rank = int(os.environ["LOCAL_RANK"])
    device = torch.device("cuda", rank)
    torch.cuda.set_device(device)
    config = json.loads(args.reference.read_text())
    legacy = json.loads(Path(config["legacy_qualification"]).read_text())
    data = Samples(
        Path(config["samples"]), device, surface_fill="zero", global_observations=True
    )
    om4 = Path(config["om4"])
    reader = ModelMonths(
        om4 / "OM4.zarr", "om4", data.grid, om4, packed=Path(legacy["packed_om4"])
    )
    forcing = SharedEra5(
        config["forcing_cache"], reader, data, config["forcing_proof_sha256"]
    )
    outputs = []
    for step in range(2):
        indices = sample_indices(len(reader.windows), 101729, step, 8)
        for slot in range(rank, 8, 4):
            index = indices[slot]
            if args.optimized:
                from samudra.experiments.physical_state_prefetch import (
                    load_native_cpu,
                    native_to_device,
                )

                batch = native_to_device(
                    load_native_cpu(reader, forcing, data, index), device
                )
            else:
                batch = reader.sample(index, device)
                batch["atmosphere"] = forcing.load(reader, index, data)
            record = dict(step=step, slot=slot, index=index, values={})
            for name in (
                "fields",
                "contexts",
                "mask",
                "weights",
                "atmosphere",
                "duration",
                "first",
            ):
                value = batch[name]
                if isinstance(value, torch.Tensor):
                    raw = value.detach().cpu().contiguous().numpy()
                    record["values"][name] = dict(
                        shape=list(raw.shape),
                        dtype=str(raw.dtype),
                        sha256=hashlib.sha256(raw.tobytes()).hexdigest(),
                    )
                else:
                    record["values"][name] = value
            outputs.append(record)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / f"rank-{rank}.json").write_text(json.dumps(outputs, indent=2))


def main():
    if sys.argv[1] == "audit":
        audit()
    elif sys.argv[1] == "train":
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
        import torch

        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        sys.argv = sys.argv[1:]
        runpy.run_module(
            "samudra.experiments.physical_state_train", run_name="__main__"
        )
    else:
        raise ValueError("Expected audit or train")


if __name__ == "__main__":
    main()
