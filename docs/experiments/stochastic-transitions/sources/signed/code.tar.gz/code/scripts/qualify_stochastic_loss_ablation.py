# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Exercise all phases and enforce measured >70% warm GPU utilization per arm."""

import argparse
import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from stochastic_loss_campaign import VARIANTS, command


def gpu_identity():
    """Resolve CUDA ordinal zero to its UUID, independent of container renumbering."""
    result = subprocess.check_output(
        [
            sys.executable,
            "-c",
            "import torch; print(torch.cuda.get_device_properties(0).uuid)",
        ],
        text=True,
        timeout=60,
    ).strip()
    return result.removeprefix("GPU-").lower()


def gpu_sample(identity):
    raw = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,uuid,utilization.gpu,memory.used",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        timeout=15,
    )
    selected = [
        row
        for row in csv.reader(raw.splitlines())
        if len(row) == 4 and row[1].strip().removeprefix("GPU-").lower() == identity
    ]
    if len(selected) != 1:
        raise RuntimeError(
            f"Expected exactly one telemetry row for allocated GPU {identity}; got {len(selected)}"
        )
    row = selected[0]
    return dict(
        time=time.time(),
        gpu=int(row[0]),
        uuid=row[1].strip(),
        utilization=float(row[2]),
        memory_mib=float(row[3]),
    )


def monitor(path, stop, identity):
    with path.open("w") as stream:
        while not stop.is_set():
            stream.write(json.dumps(gpu_sample(identity)) + "\n")
            stream.flush()
            stop.wait(1)


def checkpoint_check(before_path, after_path):
    """Resume must preserve optimizer history and produce finite raw/EMA."""
    import torch

    before = torch.load(before_path, map_location="cpu", weights_only=False)
    after = torch.load(after_path, map_location="cpu", weights_only=False)
    if (
        before["step"] != 24
        or after["step"] != 28
        or before["contract"] != after["contract"]
    ):
        raise ValueError("Resume changed checkpoint contract")
    if before["contract"]["cooldown_updates"] != 0:
        raise ValueError("Unexpected cooldown")
    for state in (before, after):
        for section in ("model", "ema"):
            if not all(torch.isfinite(t).all() for t in state[section].values()):
                raise ValueError("Nonfinite saved raw/EMA")
    for key, entry in before["optimizer"]["state"].items():
        if "step" in entry and not torch.equal(
            after["optimizer"]["state"][key]["step"], entry["step"] + 4
        ):
            raise ValueError("Adam history not continued across resume")
    if after["optimizer"]["param_groups"][0]["lr"] != 1e-4:
        # Floating-point linear interpolation can differ by its last bits.
        if not math.isclose(
            after["optimizer"]["param_groups"][0]["lr"], 1e-4, rel_tol=1e-10
        ):
            raise ValueError("Main-phase LR changed")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--paths", type=Path, required=True)
    a = p.parse_args()
    paths = json.loads(a.paths.read_text())
    a.root.mkdir(parents=True, exist_ok=True)
    identity = gpu_identity()
    print(json.dumps({"allocated_gpu": gpu_sample(identity)}), flush=True)
    gate = {}
    for arm, config in VARIANTS.items():
        microbatch = config["microbatch"]
        out = a.root / arm
        if out.exists():
            raise ValueError(f"Refuse overwrite qualification {out}")
        out.mkdir()
        stop = threading.Event()
        monitor_errors = []

        def monitor_guard():
            try:
                monitor(out / "gpu.jsonl", stop, identity)
            except Exception as error:
                monitor_errors.append(repr(error))

        thread = threading.Thread(target=monitor_guard, daemon=True)
        thread.start()
        base = command(paths, out, arm, microbatch) + [
            "--main-updates",
            "28",
            "--cooldown-updates",
            "0",
            "--checkpoint-every",
            "12",
            "--smoke",
            "--check-rank-sync",
        ]
        try:
            with (out / "train.log").open("w") as log:
                subprocess.run(
                    base + ["--max-new-updates", "24"],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    check=True,
                )
                subprocess.run(
                    base + ["--resume"],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    check=True,
                )
        finally:
            stop.set()
            thread.join(timeout=20)
        if thread.is_alive() or monitor_errors:
            raise RuntimeError(f"GPU monitor failed: {monitor_errors}")
        events = [
            json.loads(x) for x in (out / "events.jsonl").read_text().splitlines()
        ]
        if [e["step"] for e in events] != list(range(1, 29)):
            raise ValueError("Incomplete resume qualification")
        completion = json.loads((out / "COMPLETE.json").read_text())
        if completion["counts"] != {"om4": 14, "observation": 14}:
            raise ValueError("Incorrect source exposure")
        if not all(
            math.isfinite(e["loss"])
            and math.isfinite(e["grad_norm"])
            and all(math.isfinite(v) for v in e["components"])
            for e in events
        ):
            raise ValueError("Nonfinite qualification metrics")
        checkpoint_check(out / "step-00024.pt", out / "step-00028.pt")
        telemetry = [
            json.loads(x) for x in (out / "gpu.jsonl").read_text().splitlines()
        ]
        warm = [e for e in events if 5 <= e["step"] <= 24]
        points = [
            p
            for p in telemetry
            if any(
                e["update_started_unix"] <= p["time"] <= e["update_finished_unix"]
                for e in warm
            )
        ]
        if len(points) < 20:
            raise ValueError("Insufficient warm utilization measurements")
        gpu_ids = sorted(set(p["uuid"] for p in points))
        if len(gpu_ids) != 1:
            raise ValueError("Qualification expects one visible GPU")
        utilization = sum(p["utilization"] for p in points) / len(points)
        report = dict(
            variant=arm,
            architecture_arm=config["arm"],
            objective=config["objective"],
            ensemble_mean_mse_weight=config["auxiliary"],
            mean_gpu_utilization_percent=utilization,
            samples=len(points),
            peak_memory_mib=max(p["memory_mib"] for p in points),
            microbatch=microbatch,
            update_seconds={
                s: sum(e["seconds"] for e in warm if e["source"] == s)
                / sum(e["source"] == s for e in warm)
                for s in ("om4", "observation")
            },
            mean_data_wait_seconds=sum(e["data_wait_seconds"] for e in warm)
            / len(warm),
            passed=utilization > 70,
            counts=completion["counts"],
        )
        (out / "QUALIFIED.json").write_text(json.dumps(report, indent=2) + "\n")
        gate[arm] = report
        if not report["passed"]:
            print(
                f"{arm}: measured GPU utilization {utilization:.2f}% <=70%; "
                "production remains blocked; collect remaining arm diagnostics",
                flush=True,
            )
        subprocess.run(
            [
                sys.executable,
                "-m",
                "samudra.experiments.stochastic_transition_evaluate",
                "--data",
                paths["samples"],
                "--checkpoint",
                str(out / "step-00028.pt"),
                "--output",
                str(out / "evaluation"),
                "--limit-origins",
                "2",
                "--members",
                "4",
            ],
            check=True,
        )
    (a.root / "QUALIFIED.json").write_text(
        json.dumps(
            dict(
                variants=gate,
                passed=all(report["passed"] for report in gate.values()),
                producer=os.environ["SAMUDRA_CODE_COMMIT"],
                paths_sha256=hashlib.sha256(a.paths.read_bytes()).hexdigest(),
            ),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(gate), flush=True)
    if not all(report["passed"] for report in gate.values()):
        raise ValueError(
            "Not all arms exceeded 70% GPU utilization; do not submit production"
        )


if __name__ == "__main__":
    main()
