#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Compare two checkpoints on one cached observation forecast period."""

import argparse
import json
from pathlib import Path

import numpy as np

from samudra.experiments.diffusion_latent_maps import grid
from samudra.experiments.observation_pilot import digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--early", type=Path, required=True)
    parser.add_argument("--final", type=Path, required=True)
    parser.add_argument("--origin", default="2013-11")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    filename = f"members-{args.origin}.npz"
    receipts, arrays, provenance = [], [], []
    for root in (args.early, args.final):
        receipt = json.loads((root / "COMPLETE.json").read_text())
        source = root / filename
        sha = digest(source)
        if sha != receipt["files"][filename]:
            raise ValueError(f"Export checksum mismatch: {source}")
        with np.load(source) as saved:
            arrays.append(
                {
                    key: saved[key]
                    for key in (
                        "day30",
                        "day30_surface_reference",
                        "mask",
                        "lat",
                        "lon",
                        "channel_names",
                        "target_midpoint",
                    )
                }
            )
        receipts.append(receipt)
        provenance.append(
            dict(
                source=str(source),
                export_sha256=sha,
                checkpoint_sha256=receipt["checkpoint_sha256"],
                step=receipt["step"],
                counts=receipt["counts"],
            )
        )
    for key in ("sampling_steps", "split"):
        if receipts[0][key] != receipts[1][key]:
            raise ValueError(f"Mismatched evaluation {key}")
    for key in ("seed", "observation_manifest", "grid", "stats", "reference"):
        if (
            receipts[0]["training_contract"][key]
            != receipts[1]["training_contract"][key]
        ):
            raise ValueError(f"Mismatched data/seed contract: {key}")
    for key in arrays[0]:
        if key != "day30":
            np.testing.assert_array_equal(arrays[0][key], arrays[1][key])
    if arrays[0]["day30"].shape != arrays[1]["day30"].shape:
        raise ValueError("Mismatched member arrays")
    args.output.mkdir(parents=True, exist_ok=True)
    labels = [
        f"{r['counts']['observation']:,} obs + {r['counts']['om4']:,} OM4 updates"
        for r in receipts
    ]
    for name, unit in (("thetao_0", "SST (°C)"), ("zos", "SSH (m)")):
        channel = arrays[0]["channel_names"].tolist().index(name)
        if channel not in (0, 1):
            raise ValueError("Expected surface channels first in cached export")
        fields, titles = [], []
        for kind in ("reference", "mean", "draw"):
            for a, label in zip(arrays, labels, strict=True):
                members = a["day30"][:, channel]
                if kind == "reference":
                    field = a["day30_surface_reference"][channel]
                    title = "Observed reference (identical)"
                elif kind == "mean":
                    field, title = members.mean(0), f"Mean of {len(members)} draws"
                else:
                    field, title = members[0], "Individual draw 1 at day 30"
                fields.append(field)
                titles.append(f"{label}\n{title}")
        grid(
            fields,
            titles,
            arrays[0]["mask"][channel].astype(bool),
            arrays[0]["lat"],
            args.output / f"paired-{args.origin}-day30-{name}.png",
            f"{args.origin} validation forecast: day-30 five-day bin, not a monthly average.\n"
            f"{receipts[0]['sampling_steps']} sampling steps; same period, target and grid; "
            "shared color limits across checkpoints.",
            unit,
            show_loss_boundary=False,
            distinguish_missing=True,
        )
    (args.output / "pairing.json").write_text(
        json.dumps(
            dict(
                origin=args.origin,
                target_midpoint=str(arrays[0]["target_midpoint"]),
                split=receipts[0]["split"],
                sampling_steps=receipts[0]["sampling_steps"],
                members=int(arrays[0]["day30"].shape[0]),
                verification=(
                    "Exact reference, mask, coordinates and target time equality; "
                    "export checksums verified"
                ),
                panels=(
                    "Reference, ensemble mean and draw 1; "
                    "day-30 five-day surface bin without monthly averaging"
                ),
                sources=provenance,
            ),
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
