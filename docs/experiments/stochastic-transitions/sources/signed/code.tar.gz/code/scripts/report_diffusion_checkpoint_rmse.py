#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Match diffusion checkpoint RMSE to the presentation's 30/365-day metric."""

import argparse
import csv
import gzip
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from samudra.experiments.diffusion_ab_figures import save_png
from samudra.experiments.observation_pilot import digest

ORIGINS = ["2015-01-01", "2018-01-01", "2021-01-01"]
COMPONENTS = (
    "sst_rmse", "velocity_rmse", "ohc_0_700_rmse", "ohc_700_2000_rmse",
)
SPECS = (
    ("Diffusion: 2k obs + 4,949 OM4", "checkpoint-annual-obs2000-steps32", 2000, 4949),
    ("Diffusion: 4k obs + 6,667 OM4", "checkpoint-annual-obs4000-steps32", 4000, 6667),
    ("Diffusion: 6k obs + 7,555 OM4", "checkpoint-annual-obs6000-steps32", 6000, 7555),
    ("Diffusion: 8k obs + 8k OM4 (cooled)", "final-annual-steps32", 8000, 8000),
    ("Deterministic: 8k obs + 8k OM4", "global-endpoint-annual", 8000, 8000),
)


def endpoint(record, origin, day):
    month = origin[:4] + ("-01" if day == 30 else "-12")
    return {
        **record["leads"][str(day)],
        **{
            f"ohc_{layer}_rmse": record["monthly_ohc"][month][layer]
            for layer in ("0_700", "700_2000")
        },
    }


def pooled(records):
    if not records or any(set(r) != set(records[0]) for r in records):
        raise ValueError("Incomplete metric components")
    if any(not np.isfinite(v) or v < 0 for r in records for v in r.values()):
        raise ValueError("Nonfinite or negative RMSE")
    return {
        key: float(np.sqrt(np.mean([r[key] ** 2 for r in records])))
        for key in records[0]
    }


def normalized_manifests(signature):
    manifests = signature.get("annual_manifests", signature.get("data_manifests"))
    if manifests is None:
        raise ValueError("Missing annual data provenance")
    return {key.split("/")[-2] if "/" in key else key: sha for key, sha in manifests.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--presentation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--available-only", action="store_true")
    args = parser.parse_args()
    with gzip.open(args.presentation, "rt") as stream:
        presentation = json.load(stream)
    assert presentation["configuration"]["origins"] == ORIGINS
    climatology = presentation["metrics"]["Training seasonal climatology"]
    expected_manifests = normalized_manifests(
        presentation["models"]["U-global"]["inputs"]
    )
    records, provenance, pending = {}, {}, []
    for label, folder, obs, om4 in SPECS:
        root = args.root / folder
        completion = root / "COMPLETE.json"
        if not completion.exists():
            if not args.available_only:
                raise FileNotFoundError(completion)
            pending.append(label)
            continue
        inputs = json.loads((root / "input.json").read_text())
        complete = json.loads(completion.read_text())
        assert normalized_manifests(inputs) == expected_manifests
        if "Diffusion" in label:
            assert inputs["counts"] == {"observation": obs, "om4": om4}
            assert inputs["step"] == obs + om4
            assert inputs["members"] == 8 and inputs["sampling_steps"] == 32
            assert complete["inputs"] == inputs
        records[label] = {
            origin: json.loads((root / f"{origin}.json").read_text())
            for origin in ORIGINS
        }
        provenance[label] = dict(
            directory=str(root), inputs=inputs,
            metric_hashes={origin: digest(root / f"{origin}.json") for origin in ORIGINS},
        )
    records["Training seasonal climatology"] = climatology
    rows, controls = [], {}
    for day in (30, 365):
        control = pooled([endpoint(climatology[o], o, day) for o in ORIGINS])
        assert all(control[k] > 0 for k in COMPONENTS)
        controls[str(day)] = control
        for label, origins in records.items():
            for origin in [*ORIGINS, "pooled"]:
                selected = ORIGINS if origin == "pooled" else [origin]
                values = pooled([endpoint(origins[o], o, day) for o in selected])
                ratios = {k: values[k] / control[k] for k in COMPONENTS}
                rows.append(dict(
                    model=label, origin=origin, lead_days=day,
                    rmse_score=float(np.mean(list(ratios.values()))), **values,
                    **{k + "_ratio": v for k, v in ratios.items()},
                ))
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "rmse-scores.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    labels = [s[0] for s in SPECS]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.5), sharey=True)
    for ax, day in zip(axes, (30, 365), strict=True):
        selected = {r["model"]: r for r in rows if r["origin"] == "pooled" and r["lead_days"] == day}
        values = [selected[name]["rmse_score"] for name in labels if name in selected]
        logarithmic = max(values) / min(values) > 10
        if logarithmic:
            ax.set_xscale("log")
            ax.set_xlim(min(0.7, min(values) * 0.8), max(values) * 2)
        else:
            ax.set_xlim(0, max(1.0, max(values)) * 1.2)
        for i, label in enumerate(labels):
            if label in selected:
                score = selected[label]["rmse_score"]
                ax.scatter(score, i, marker="s" if "Deterministic" in label else "o",
                           color="#0072B2" if "Deterministic" in label else "#D55E00", s=60)
                ax.annotate(f"{score:.3f}", (score, i), xytext=(7, 0),
                            textcoords="offset points", va="center", fontsize=9)
            else:
                ax.text(0.02, i, "Awaiting evaluation", transform=ax.get_yaxis_transform(), color="0.5")
        ax.axvline(1, color="black", linestyle=":", label="Training climatology = 1")
        ax.set_title(f"Day {day}" + (" · logarithmic axis" if logarithmic else ""))
        ax.set_xlabel("Four-component RMSE / climatology (lower is better)")
        ax.set_yticks(range(len(labels)), labels)
        ax.grid(axis="x", alpha=0.2)
    axes[0].invert_yaxis()
    fig.suptitle("Diffusion checkpoint comparison — same three January starts", fontsize=15)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", bbox_to_anchor=(0.6, 0.92), fontsize=9)
    fig.text(0.5, 0.025,
             "SST + geostrophic velocity + OHC 0–700 m + OHC 700–2000 m; equal component weights.\n"
             "Eight-draw diffusion mean. RMSE pooled across origins before normalization; January/December OHC means.",
             ha="center", fontsize=9)
    fig.tight_layout(rect=(0, 0.12, 1, 0.94))
    save_png(fig, args.output / "rmse-comparison.png", dpi=150)
    fig.savefig(args.output / "rmse-comparison.pdf")
    plt.close(fig)
    result = dict(
        complete=not pending, pending=pending, origins=ORIGINS,
        components=COMPONENTS, controls=controls, rows=rows, provenance=provenance,
        presentation_source=str(args.presentation), presentation_sha256=digest(args.presentation),
        definition="Mean of four RMSE ratios to same-lead seasonal climatology; each RMSE is square root of equally pooled origin MSEs",
        limitation="Three January starts and one training seed; fixed-budget checkpoints, not annual-selected weights. Only final 8k-observation checkpoint has cooldown.",
    )
    (args.output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"pending": pending, "pooled": [r for r in rows if r["origin"] == "pooled"]}, indent=2))


if __name__ == "__main__":
    main()
