#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Regional physical maps of the fields underlying the day-30 EKE scores."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import xarray as xr

from samudra.experiments.diffusion_ab_figures import save_png
from samudra.experiments.observation_metrics import spatial_error
from samudra.experiments.observation_pilot import digest
from samudra.metrics import kernels, spectra


LABELS = ("Reference", "Matched deterministic", "Diffusion: mean of 8", "Diffusion: draw 1")


def plot_rows(rows, output, title, caption, labels=LABELS):
    """Four columns; exact 12x12 image pixels per native model grid cell."""
    fig = plt.figure(figsize=(18, 12), dpi=100)
    fig.text(0.5, 0.976, title, ha="center", fontsize=17)
    for column, label in enumerate(labels):
        fig.text((240 + 410 * column) / 1800, 0.937, label, ha="center", fontsize=12)
    for row, record in enumerate(rows):
        fields, lat, lon = record["fields"], record["lat"], record["lon"]
        h, w = fields[0].shape
        bottom = 820 - row * 350
        fig.text(0.5, (bottom + 283) / 1200, record["label"], ha="center", fontsize=13)
        values = np.concatenate([field[np.isfinite(field)] for field in fields])
        if record["kind"] == "eke":
            low, high, cmap = 0, float(values.max()), "magma"
        elif record["kind"] == "anomaly":
            high = float(np.abs(values).max())
            low, cmap = -high, "RdBu_r"
        else:
            low, high, cmap = float(values.min()), float(values.max()), "viridis"
        for column, field in enumerate(fields):
            left = 60 + column * 410 + (360 - w * 12) / 2
            ax = fig.add_axes((left / 1800, bottom / 1200, w * 12 / 1800, h * 12 / 1200))
            dx, dy = np.median(np.diff(lon)), np.median(np.diff(lat))
            im = ax.imshow(
                field, origin="lower", interpolation="nearest", aspect="auto",
                extent=[lon[0] - dx / 2, lon[-1] + dx / 2, lat[0] - dy / 2, lat[-1] + dy / 2],
                vmin=low, vmax=high, cmap=cmap,
            )
            ax.set_xlabel("Longitude (°E)", fontsize=9)
            if column == 0:
                ax.set_ylabel("Latitude (°N)", fontsize=9)
            ax.tick_params(labelsize=9)
            bounds = ax.get_window_extent()
            np.testing.assert_allclose([bounds.width, bounds.height], [w * 12, h * 12])
        cax = fig.add_axes((1690 / 1800, bottom / 1200, 17 / 1800, h * 12 / 1200))
        fig.colorbar(im, cax=cax, label=record["unit"])
    fig.text(0.5, 0.017, caption, ha="center", fontsize=10)
    save_png(fig, output, dpi=100)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--comparison", type=Path, required=True)
    parser.add_argument("--draw-spectra", type=Path, required=True)
    parser.add_argument("--origin", default="2018-01")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    receipt = json.loads((args.root / "COMPLETE.json").read_text())
    comparison = json.loads(args.comparison.read_text())
    draw_spectra = json.loads(args.draw_spectra.read_text())
    with np.load(args.baseline) as saved:
        baseline = {key: saved[key] for key in saved.files}
    baseline_input = json.loads(str(baseline["evaluation_input"]))
    assert baseline_input["fixed_budget_lineage"] == comparison["deterministic"]["lineage"]
    assert baseline_input["data_manifest_sha256"] == receipt["training_contract"]["observation_manifest"]
    origins = receipt["metrics"]["origins"]
    np.testing.assert_array_equal(baseline["origins"], origins)
    selected = origins.index(args.origin)
    regions = {name.lower().replace(" ", "-"): (name, x, y) for name, x, y in spectra.SPATIAL_REGIONS}
    member_regions = {slug: [] for slug in regions}
    for i, origin in enumerate(origins):
        path = args.root / f"members-{origin}.npz"
        assert digest(path) == receipt["files"][path.name]
        with np.load(path) as saved:
            members = saved["day30"][:, :2]
            for slug in regions:
                yi, xi = baseline[slug + "_y_indices"], baseline[slug + "_x_indices"]
                subset = members[..., yi[:, None], xi]
                np.testing.assert_array_equal(saved["lat"][yi], baseline[slug + "_lat"])
                np.testing.assert_array_equal(saved["lon"][xi], baseline[slug + "_lon"])
                np.testing.assert_array_equal(
                    saved["day30_surface_reference"][..., yi[:, None], xi],
                    baseline[slug + "_reference"][i, :2],
                )
                member_regions[slug].append(np.stack((subset.mean(0), subset[0])))
        if (i + 1) % 24 == 0:
            print(f"Verified {i + 1}/96 matching regional references", flush=True)
    mean_rows, example_rows, operator_rows, diagnostics, exported = [], [], [], {}, {}
    for slug, region in regions.items():
        name, x, y = region
        lat, lon = baseline[slug + "_lat"], baseline[slug + "_lon"]
        mask = baseline[slug + "_mask"].astype(bool)
        reference = np.where(mask[None, None], baseline[slug + "_reference"], np.nan)
        member = np.stack(member_regions[slug])
        surfaces = [reference[:, :2], baseline[slug + "_prediction"], member[:, 0], member[:, 1]]

        def field(array):
            return xr.DataArray(array, dims=("time", "lat", "lon"), coords={"time": np.arange(96), "lat": lat, "lon": lon})

        ru, rv = kernels.geostrophic_velocity_from_zos(field(reference[:, 1]), "lat", "lon")
        support = np.isfinite(ru) & np.isfinite(rv) & np.isfinite(field(reference[:, 2])) & np.isfinite(field(reference[:, 3]))
        all_eke, all_ssh, all_anomaly = [], [], []
        for model, surface in enumerate(surfaces):
            surface = np.where(mask[None, None], surface, np.nan)
            if model == 0:
                u, v = field(reference[:, 2]), field(reference[:, 3])
            else:
                u, v = kernels.geostrophic_velocity_from_zos(field(surface[:, 1]), "lat", "lon")
            u, v = u.where(support), v.where(support)
            eke = kernels.instantaneous_surface_eke(u, v).transpose("time", "lat", "lon").values
            ssh = np.where(np.isfinite(reference[:, 1]), surface[:, 1], np.nan)
            # Remove one-cell halos after differentiating, preserving the exact regional stencil.
            all_eke.append(eke[:, 1:-1, 1:-1])
            all_ssh.append(ssh[:, 1:-1, 1:-1])
            all_anomaly.append((ssh - np.nanmean(ssh, axis=0))[:, 1:-1, 1:-1])
        lat, lon = lat[1:-1], lon[1:-1]
        observed_ssh_eke = kernels.instantaneous_surface_eke(
            ru.where(support), rv.where(support)
        ).transpose("time", "lat", "lon").values[:, 1:-1, 1:-1]
        stats = {}
        diagnostic_labels = (*LABELS, "Reference from observed SSH")
        diagnostic_eke = [*all_eke, observed_ssh_eke]
        for model, (label, eke) in enumerate(zip(diagnostic_labels, diagnostic_eke, strict=True)):
            curve = spatial_error(eke, all_eke[0], lat, lon, region)
            assert curve is not None
            key = f"eke/{name}/day30"
            np.testing.assert_allclose(curve["reference_power"], receipt["metrics"]["spectra"][key]["reference_power"], rtol=2e-5)
            if model in (2, 3):
                target = (receipt["metrics"] if model == 2 else draw_spectra)["spectra"][key]
                np.testing.assert_allclose(curve["prediction_power"], target["prediction_power"], rtol=2e-5)
            area = np.broadcast_to(np.cos(np.deg2rad(lat))[None, :, None], eke.shape)
            valid = np.isfinite(eke)
            mean_eke = float(np.sum(np.where(valid, eke, 0) * area) / np.sum(valid * area))
            stats[label] = dict(mean_eke_m2_s2=mean_eke, anomaly_velocity_rms_m_s=float(np.sqrt(2 * mean_eke)), spectral_error_dex=curve["error_dex"])
        for label in diagnostic_labels:
            stats[label]["eke_fraction_of_reference"] = stats[label]["mean_eke_m2_s2"] / stats["Reference"]["mean_eke_m2_s2"]
        diagnostics[name] = stats
        for kind, arrays in (("eke", all_eke), ("ssh", all_ssh), ("ssh_anomaly", all_anomaly)):
            exported[slug + "_" + kind] = np.stack(arrays)
        exported[slug + "_lat"], exported[slug + "_lon"] = lat, lon
        exported[slug + "_reference_ssh_eke"] = observed_ssh_eke
        base = dict(lat=lat, lon=lon, kind="eke", unit="EKE (m²/s²)", label=f"{name}: {x.start}–{x.stop}°E, {y.start}–{y.stop}°N")
        mean_rows.append(dict(base, fields=[np.nanmean(a, axis=0) for a in all_eke]))
        example_rows.append(dict(base, fields=[a[selected] for a in all_eke]))
        operator_rows.append(dict(base, fields=[np.nanmean(a, axis=0) for a in (all_eke[0], observed_ssh_eke, all_eke[1], all_eke[3])]))
        rows = [
            dict(base, fields=[a[selected] for a in all_ssh], kind="ssh", unit="SSH (m)", label="Absolute SSH at day 30"),
            dict(base, fields=[a[selected] for a in all_anomaly], kind="anomaly", unit="SSH departure (m)", label="SSH minus each method's own 96-origin mean"),
            dict(base, fields=[a[selected] for a in all_eke], label="EKE from velocity departures about each method's own 96-origin mean"),
        ]
        plot_rows(rows, args.output / f"{slug}-{args.origin}-ssh-to-eke.png", f"{name} — {args.origin}, day 30", "Same reference support; shared linear scale within each row; no clipping or image smoothing.\nBoth models: 8k observation + 8k OM4. Native grid cells displayed as 12×12 pixels.")
    caption = "EKE = ½(u′² + v′²); departures use each method's own mean across the 96 day-30 forecasts (2015–2022).\nShared linear scale within each region; no clipping; native cells 12×12 pixels. Both models: 8k observation + 8k OM4."
    plot_rows(mean_rows, args.output / "day30-mean-eke-regions.png", "Mean day-30 EKE across 96 held-out forecasts", caption)
    plot_rows(example_rows, args.output / f"day30-{args.origin}-eke-regions.png", f"Day-30 EKE — {args.origin} forecast", caption)
    plot_rows(
        operator_rows, args.output / "day30-eke-reference-operator-check.png",
        "Reference/operator check — mean day-30 EKE across 96 forecasts", caption,
        labels=("Provided reference velocities", "Derived from observed SSH", "Matched deterministic", "Diffusion: draw 1"),
    )
    np.savez_compressed(args.output / "regional-fields.npz", origins=origins, labels=np.array(LABELS), **exported)
    result = dict(origin=args.origin, region_statistics=diagnostics, deterministic_source_sha256=str(baseline["source_sha256"]), deterministic_lineage=baseline_input["fixed_budget_lineage"], diffusion_checkpoint_sha256=receipt["checkpoint_sha256"], verification="96 regional surface references identical; EKE reference, mean and draw spectra reproduced at scored bins")
    (args.output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
