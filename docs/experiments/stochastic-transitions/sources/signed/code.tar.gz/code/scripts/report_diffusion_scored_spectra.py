#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Plot the stored day-30 spectral curves used in the final blended score."""

import argparse
import csv
import gzip
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
import numpy as np

from samudra.experiments.diffusion_ab_figures import save_png
from samudra.experiments.observation_metrics import selection_score
from samudra.metrics.spectra import log10_rmse_between_curves


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison", type=Path, required=True)
    parser.add_argument("--deterministic-results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draw-spectra", type=Path, help="Verified single-draw curves from cached exports")
    args = parser.parse_args()
    comparison = json.loads(args.comparison.read_text())
    with gzip.open(args.deterministic_results, "rt") as stream:
        source = json.load(stream)
    baseline = source["checkpoints"]["obs08000"]["fixed_budget_evaluation"]
    assert baseline["fixed_budget_lineage"] == comparison["deterministic"]["lineage"]
    assert baseline["split"] == "test"
    deterministic = baseline["metrics"]
    diffusion = comparison["diffusion_metrics"]
    keys = comparison["spectral_keys"]
    assert deterministic["metrics"] == comparison["deterministic"]["forecast"]["metrics"]
    for name, result in (("deterministic", deterministic), ("diffusion", diffusion)):
        np.testing.assert_allclose(
            selection_score(result, comparison["reporting_climatology"], keys),
            comparison["heldout_reporting_score"][name],
            rtol=1e-12,
        )
    for key in keys:
        a, b = deterministic["spectra"][key], diffusion["spectra"][key]
        for field in ("k_rad_km", "reference_power"):
            np.testing.assert_allclose(a[field], b[field], rtol=1e-12, atol=0)
        for curve in (a, b):
            np.testing.assert_allclose(
                log10_rmse_between_curves(
                    curve["k_rad_km"], curve["reference_power"],
                    curve["k_rad_km"], curve["prediction_power"],
                ),
                curve["error_dex"], rtol=1e-12, atol=1e-14,
            )
    draw_record = None
    if args.draw_spectra:
        draw_record = json.loads(args.draw_spectra.read_text())
        assert draw_record["counts"] == {"om4": 8000, "observation": 8000}
        assert draw_record["split"] == "test"
        assert draw_record["origins"] == diffusion["origins"]
        for key, curve in draw_record["spectra"].items():
            assert key in keys and key.endswith("/day30")
            for field in ("k_rad_km", "reference_power"):
                np.testing.assert_array_equal(curve[field], diffusion["spectra"][key][field])
        diffusion = {"spectra": draw_record["spectra"]}
    diffusion_label = (
        f"Diffusion: draw {draw_record['draw']}" if draw_record else "Diffusion: mean of 8"
    )
    fields = (("sst", "SST"), ("adt", "SSH / ADT"), ("eke", "EKE from geostrophic velocity"))
    regions = ("North Pacific", "Gulf Stream", "Agulhas")
    args.output.mkdir(parents=True, exist_ok=True)
    rows, errors = [], []
    for ratio in (False, True):
        fig, axes = plt.subplots(3, 3, figsize=(14, 11))
        for row, region in enumerate(regions):
            for col, (field, label) in enumerate(fields):
                key = f"{field}/{region}/day30"
                assert key in keys
                a, b = deterministic["spectra"][key], diffusion["spectra"][key]
                wavelength = 2 * np.pi / np.array(a["k_rad_km"])
                ref = np.array(a["reference_power"])
                curves = (ref, np.array(a["prediction_power"]), np.array(b["prediction_power"]))
                ax = axes[row, col]
                for values, color, marker, name in zip(
                    curves, ("#222222", "#0072B2", "#D55E00"), ("o", "s", "^"),
                    ("Reference", "Matched deterministic", diffusion_label), strict=True,
                ):
                    ax.loglog(
                        wavelength, values / ref if ratio else values,
                        color=color, marker=marker, markersize=7, linewidth=1.7,
                        markerfacecolor="white", markeredgewidth=1.5, label=name,
                    )
                ax.set_title(
                    f"{label} — {region}\n"
                    f"Error (dex): deterministic {a['error_dex']:.3f}\n"
                    f"diffusion {b['error_dex']:.3f}",
                    fontsize=10,
                )
                ax.set_xlim(3500, 450)
                ax.set_xticks([3000, 2000, 1000, 500], labels=["3000", "2000", "1000", "500"])
                ax.xaxis.set_minor_formatter(NullFormatter())
                ax.set_xlabel("Wavelength (km): large → small scales")
                ax.set_ylabel("Power / reference power" if ratio else "Spectral power (scorer units)")
                ax.grid(alpha=0.2, which="both")
                if not ratio:
                    errors.append(dict(key=key, deterministic=a["error_dex"], diffusion=b["error_dex"]))
                    for i, k in enumerate(a["k_rad_km"]):
                        rows.append(dict(
                            key=key, k_rad_km=k, wavelength_km=float(wavelength[i]),
                            reference_power=float(ref[i]), deterministic_power=float(curves[1][i]),
                            diffusion_power=float(curves[2][i]),
                        ))
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.948), ncol=3)
        title = (
            f"Day-30 spectra: diffusion draw {draw_record['draw']}, using the same scoring bins"
            if draw_record else "Day-30 spectra used in the blended dex score"
        )
        fig.suptitle(title, y=0.987, fontsize=17)
        averaging_note = (
            f"Draw {draw_record['draw']} at day 30 from each origin; power spectra averaged across origins, not draws.\n"
            if draw_record else
            "Power spectra averaged across origins; diffusion fields averaged across 8 draws before the FFT.\n"
        )
        fig.text(
            0.5, 0.025,
            "Both models: 8,000 observation + 8,000 OM4 updates. Same 96 held-out origins (2015–2022).\n"
            + averaging_note
            + "Only scored bins shown (wavelength ≥ 4 grid cells); lines connect bins, not additional measurements.",
            ha="center", fontsize=10,
        )
        fig.subplots_adjust(top=0.86, bottom=0.13, hspace=0.65, wspace=0.30)
        suffix = "ratios" if ratio else "power"
        save_png(fig, args.output / f"day30-scored-spectra-{suffix}.png", dpi=150)
        fig.savefig(args.output / f"day30-scored-spectra-{suffix}.pdf")
        plt.close(fig)
    with (args.output / "day30-scored-spectra.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = dict(
        comparison_source=str(args.comparison),
        deterministic_source=str(args.deterministic_results),
        verification=(
            "Original ensemble-mean comparison: all 27 dex values and both composites reproduced. "
            "Plotted curves use identical reference spectra and wavenumbers."
        ),
        diffusion_representation=diffusion_label,
        draw_provenance=draw_record,
        day30_mean_dex={name: float(np.mean([r[name] for r in errors])) for name in ("deterministic", "diffusion")},
        original_ensemble_mean_all_leads_dex={
            name: float(np.mean([result["spectra"][key]["error_dex"] for key in keys]))
            for name, result in (("deterministic", deterministic), ("diffusion", comparison["diffusion_metrics"]))
        },
        day30_panel_errors=errors,
    )
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
