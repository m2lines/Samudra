import json,csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path('docs/experiments/stochastic-transitions/results')
all_data={a:json.loads((r/f'{a}-evaluations.json').read_text()) for a in 'ABC'}
rows=[]
fig,ax=plt.subplots(figsize=(8,4.6))
for a,d in all_data.items():
 vals=sorted((v['step'],v['score']) for v in d['evaluations'].values() if v['weights']=='ema')
 ax.plot(*zip(*vals),marker={'A':'o','B':'s','C':'^'}[a],label={'A':'A: deterministic','B':'B: stochastic initializer','C':'C: stochastic initializer + processor'}[a])
 for k,v in d['evaluations'].items():rows.append({'arm':a,'checkpoint':k,'updates':v['step'],'weights':v['weights'],'blend':v['score'],**v['ratios']})
ax.axvspan(4000,5000,color='gray',alpha=.12,label='OBS-only cooldown')
ax.set(xlabel='Total optimizer updates',ylabel='Climatology-normalized RMSE blend (lower is better)',title='Nine-origin validation: one seed per arm')
ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout()
fig.savefig(r/'validation-curves.png',dpi=180);fig.savefig(r/'validation-curves.pdf')
with (r/'validation-comparison.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print({a:min((v['score'],v['step']) for v in d['evaluations'].values() if v['weights']=='ema') for a,d in all_data.items()})
