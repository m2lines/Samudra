# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Launch the fixed 10k OM4 / 1k mixed physical-diffusion campaign."""

import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(os.environ["PHYSICAL_ROOT"])
reference = Path(os.environ["PHYSICAL_REFERENCE"])
config = json.loads(reference.read_text())
legacy = json.loads(Path(config["legacy_qualification"]).read_text())
if os.environ.get("TORCH_CUDNN_V8_API_DISABLED") != "1":
    raise RuntimeError("Required cuDNN workaround missing")
if not os.environ.get("WANDB_API_KEY"):
    raise RuntimeError("Online W&B credential missing")
command = [
    sys.executable,
    "-m",
    "torch.distributed.run",
    "--standalone",
    "--nproc-per-node=4",
    "-m",
    "samudra.experiments.physical_state_train",
    "--root",
    str(root),
    "--output",
    str(root / "production"),
    "--reference",
    str(reference),
    "--data",
    config["samples"],
    "--om4",
    config["om4"],
    "--packed-om4",
    legacy["packed_om4"],
    "--shared-era5",
    config["forcing_cache"],
    "--shared-era5-proof-sha256",
    config["forcing_proof_sha256"],
    "--replay-cache",
    config["replay_cache"],
    "--om4-warmup-updates",
    "10000",
    "--updates-per-task",
    "500",
    "--obs-cooldown-updates",
    "100",
    "--effective-batch",
    "8",
    "--microbatch",
    "1",
    "--members",
    "2",
    "--sampling-steps",
    "8",
    "--checkpoint-every",
    "1000",
    "--hours",
    "46",
    "--fused-adam",
    "--replay-after-warmup",
    "--replay-curriculum",
    "1",
    "3",
    "6",
    "11",
    "--om4-surface-masking",
    "--prefetch-om4",
]
# Fixed-validation arguments are added once the validated module contract is staged.
validation_args = json.loads((root / "validation-args.json").read_text())
command += validation_args


# Exercise every phase on an isolated tiny run before committing the long budget.
def replace_argument(arguments, name, value):
    arguments[arguments.index(name) + 1] = str(value)


smoke_marker = root / "SMOKE_QUALIFIED.json"
if not smoke_marker.exists():
    smoke = command.copy()
    for name, value in {
        "--output": root / "qualification",
        "--om4-warmup-updates": 2,
        "--updates-per-task": 4,
        "--obs-cooldown-updates": 2,
        "--validation-every": 2,
    }.items():
        replace_argument(smoke, name, value)
    subprocess.run(smoke + ["--smoke", "--check-rank-sync"], check=True)
    state = json.loads((root / "qualification/state.json").read_text())
    if state["step"] != 12 or not state["complete"]:
        raise RuntimeError("All-phase GPU qualification incomplete")
    smoke_marker.write_text(json.dumps(state))

last = root / "production/last.pt"
qualified = root / "QUALIFIED.json"
if not qualified.exists():
    if last.exists():
        raise RuntimeError(
            "Partial qualification requires an explicit audited recovery"
        )
    subprocess.run(
        command + ["--max-new-updates", "100", "--check-rank-sync"], check=True
    )
    events = [
        json.loads(s)
        for s in (root / "production/events.jsonl").read_text().splitlines()
    ]
    import math

    if len(events) != 100 or any(
        not math.isfinite(e["loss"]) or e.get("rank_sync_max_abs") != 0 for e in events
    ):
        raise RuntimeError("Initial training/rank qualification failed")
    if any(
        sum(e["replay_examples"].values()) != 0 or e["replay_lead_days"] for e in events
    ):
        raise RuntimeError("Replay unexpectedly active during pretraining")
    validation = json.loads(
        (root / "production/validation/step-00100.json").read_text()
    )
    if validation["step"] != 100 or not all(
        math.isfinite(validation[k]) for k in ("initializer", "processor", "total")
    ):
        raise RuntimeError("Fixed validation qualification failed")
    qualified.write_text(
        json.dumps(
            {
                "updates": 100,
                "first_loss": events[0]["loss"],
                "last_loss": events[-1]["loss"],
                "mean_seconds": sum(e["seconds"] for e in events[10:]) / 90,
            },
            indent=2,
        )
    )
subprocess.run(command + ["--resume"], check=True)
