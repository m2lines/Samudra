# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Joint noise and paired conditional GAN, qualified before the 2k-update screen."""

import argparse
import json
import math
import os
import subprocess
import sys
import threading
from pathlib import Path

from qualify_stochastic_transitions import command, gpu_identity, monitor
from stochastic_campaign_cache import stage_caches

VARIANTS = {
    "B-learned-control": ("legacy", 3, False),
    "B-joint-coarse": ("joint_coarse", 0, False),
    "B-joint-multires": ("joint_multires", 0, False),
    "B-conditional-gan": ("gan_fullgrid", 0, True),
}


def run(args):
    paths = json.loads((args.root / "paths.json").read_text())
    stage_caches(args.root, paths)
    out = args.root / "production" / args.variant
    out.mkdir(parents=True, exist_ok=True)
    architecture, blocks, gan = VARIANTS[args.variant]
    base = command(paths, out, "B", 1) + [
        "--objective",
        "fair-crps",
        "--main-updates",
        "2000",
        "--cooldown-updates",
        "0",
        "--checkpoint-every",
        "500",
        "--seed",
        "1729",
        "--noise-mode",
        "iid",
        "--noise-architecture",
        architecture,
        "--noise-processing-blocks",
        str(blocks),
        "--hours",
        "14",
    ]
    if gan:
        base += ["--conditional-gan", "--gan-critic-updates", "5"]
    if (out / "last.pt").exists():
        raise ValueError("Use a reviewed resume command for an existing run")
    identity = gpu_identity()
    stop = threading.Event()
    errors = []

    def telemetry():
        try:
            monitor(out / "gpu.jsonl", stop, identity)
        except Exception as error:
            errors.append(repr(error))

    worker = threading.Thread(target=telemetry, daemon=True)
    worker.start()
    try:
        subprocess.run(base + ["--max-new-updates", "24"], check=True)
        import torch

        saved = torch.load(out / "last.pt", map_location="cpu", weights_only=False)
        if saved["step"] != 24 or saved["counts"] != {"om4": 12, "observation": 12}:
            raise ValueError("Qualification exposure differs")
        for section in ("model", "ema"):
            if not all(
                torch.isfinite(value).all() for value in saved[section].values()
            ):
                raise ValueError("Nonfinite checkpoint")
        architecture_parameters = sum(v.numel() for v in saved["model"].values())
        if gan:
            if saved["gan"]["updates"] != 60 or saved["gan"]["examples"] != 480:
                raise ValueError("Critic qualification exposure differs")
            if not saved["gan"]["optimizer"]["state"]:
                raise ValueError("Missing critic Adam state")
            initial_saved = torch.load(
                out / "step-00000.pt", map_location="cpu", weights_only=False
            )
            if all(
                torch.equal(value, initial_saved["gan"]["critic"][key])
                for key, value in saved["gan"]["critic"].items()
            ):
                raise ValueError("Critic weights did not change")
            noise_key = "initializer.input_noise.weight"
            if torch.equal(
                saved["model"][noise_key], initial_saved["model"][noise_key]
            ):
                raise ValueError("Full-grid noise projection did not learn")
            del initial_saved
            critic_state = saved["gan"]["critic"]
            if not all(torch.isfinite(value).all() for value in critic_state.values()):
                raise ValueError("Nonfinite critic checkpoint")
        del saved
        rows = [
            json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()
        ]
        if [r["step"] for r in rows] != list(range(1, 25)):
            raise ValueError("Incomplete qualification log")
        if not all(
            math.isfinite(r["loss"]) and math.isfinite(r["grad_norm"]) for r in rows
        ):
            raise ValueError("Nonfinite optimization")
        warm = rows[4:]
        samples = [
            json.loads(line) for line in (out / "gpu.jsonl").read_text().splitlines()
        ]
        active = [
            s
            for s in samples
            if any(
                r["update_started_unix"] <= s["time"] <= r["update_finished_unix"]
                for r in warm
            )
        ]
        if errors or len(active) < 20:
            raise RuntimeError(f"Insufficient telemetry: {errors}")
        utilization = sum(r["utilization"] for r in active) / len(active)
        projected_hours = sum(r["seconds"] for r in warm) / len(warm) * 2000 / 3600
        if gan:
            for row in rows:
                for record in row["gan_critic_records"]:
                    if not all(math.isfinite(value) for value in record.values()):
                        raise ValueError("Nonfinite critic qualification telemetry")
        gate = dict(
            passed=utilization > 50 and projected_hours <= 14,
            variant=args.variant,
            updates=24,
            mean_gpu_utilization_percent=utilization,
            mean_update_seconds=sum(r["seconds"] for r in warm) / len(warm),
            mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm)
            / len(warm),
            peak_memory_mib=max(r["memory_mib"] for r in active),
            source=os.environ["SAMUDRA_CODE_COMMIT"],
            model_state_elements=architecture_parameters,
            architecture=architecture,
            conditional_gan=gan,
            projected_2000_update_hours=projected_hours,
            generator_exposure=dict(om4=8000, observation=8000),
            additional_critic_examples=40000 if gan else 0,
            final_critic_records=rows[-1].get("gan_critic_records", []),
        )
        (out / "QUALIFIED.json").write_text(json.dumps(gate, indent=2) + "\n")
        print(json.dumps({"qualification": gate}), flush=True)
        if gate["projected_2000_update_hours"] > 14:
            raise RuntimeError(
                "Qualification projects more than 14 training GPU-hours; review before continuing"
            )
        if not gate["passed"]:
            raise RuntimeError("GPU utilization did not exceed approved 50% threshold")
        subprocess.run(base + ["--resume"], check=True)
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or errors:
        raise RuntimeError(f"Telemetry failed: {errors}")
    completion = json.loads((out / "COMPLETE.json").read_text())
    if completion["counts"] != {"om4": 1000, "observation": 1000}:
        raise ValueError("Production source exposure differs")
    if gan and (
        completion["gan_critic_updates"],
        completion["gan_critic_examples"],
    ) != (5000, 40000):
        raise ValueError("Production critic exposure differs")
    entries = [
        dict(variant=args.variant, step=step, path=str(out / f"step-{step:05d}.pt"))
        for step in (500, 1000, 2000)
    ]
    manifest = out / "initializer-manifest.json"
    manifest.write_text(json.dumps(entries, indent=2) + "\n")
    for raw in (False, True):
        weights = "raw" if raw else "ema"
        subprocess.run(
            [
                sys.executable,
                "/pilot-code/scripts/diagnose_stochastic_velocity_wave2.py",
                "--manifest",
                str(manifest),
                "--output",
                str(out / f"initializer-{weights}"),
                "--data",
                paths["samples"],
            ]
            + (["--raw"] if raw else []),
            check=True,
        )
        subprocess.run(
            [
                sys.executable,
                "-m",
                "samudra.experiments.stochastic_transition_evaluate",
                "--data",
                paths["samples"],
                "--checkpoint",
                str(out / "step-02000.pt"),
                "--output",
                str(out / "evaluation" / f"step-02000-{weights}"),
            ]
            + (["--raw"] if raw else []),
            check=True,
        )
    (out / "EVALUATED.json").write_text(
        json.dumps(dict(complete=True, variant=args.variant)) + "\n"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    run(parser.parse_args())
