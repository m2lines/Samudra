# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Qualified single-GPU Torch launch; production is never auto-enabled by a failed gate."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from stochastic_loss_extensions import VARIANTS, command

p = argparse.ArgumentParser()
p.add_argument("--root", type=Path, required=True)
p.add_argument("--mode", choices=["qualification", "production"], required=True)
p.add_argument("--variant", choices=list(VARIANTS), default="B-multiscale-fair-crps")
a = p.parse_args()
paths = json.loads((a.root / "paths.json").read_text())
# Stage only caches: original source metadata/contract paths remain unchanged.
# Both qualification and production execute this exact path; retain read-back proof.
local = Path(os.environ["ONEPASS_NODE_TMP"])
fstype = subprocess.check_output(
    ["stat", "-f", "-c", "%T", str(local)], text=True
).strip()
if fstype in ("nfs", "nfs4", "lustre", "beegfs", "tmpfs"):
    raise RuntimeError(
        f"Node-local cache requires disk-backed local storage, got {fstype}"
    )
needed = sum(
    p.stat().st_size
    for key in ("packed_om4", "forcing_cache")
    for p in Path(paths[key]).iterdir()
    if p.is_file()
)
if shutil.disk_usage(local).free < needed + 20 * 1024**3:
    raise RuntimeError("Insufficient node-local disk for verified training caches")
started = time.time()
cache_receipts = {}
for key in ("packed_om4", "forcing_cache"):
    destination = local / key
    destination.mkdir()
    for source in Path(paths[key]).iterdir():
        if source.is_file():
            subprocess.run(
                ["cp", "--", str(source), str(destination / source.name)],
                check=True,
                timeout=600,
            )
    proof_bytes = (destination / "COMPLETE.json").read_bytes()
    source_proof_bytes = (Path(paths[key]) / "COMPLETE.json").read_bytes()
    if proof_bytes != source_proof_bytes:
        raise ValueError(f"Node-local proof changed: {key}")
    proof_sha = hashlib.sha256(proof_bytes).hexdigest()
    if key == "forcing_cache" and proof_sha != paths["forcing_proof_sha256"]:
        raise ValueError("Forcing proof differs from pinned data configuration")
    proof = json.loads(proof_bytes)
    cache_receipts[key] = dict(
        source=paths[key], destination=str(destination), proof_sha256=proof_sha
    )
    if key == "forcing_cache":
        for name, expected in proof["files"].items():
            with (destination / name).open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            if actual != expected:
                raise ValueError(f"Node-local forcing mismatch: {name}")
    else:
        import numpy as np

        frames = np.load(destination / "frames.npy", mmap_mode="r")
        if (
            list(frames.shape) != proof["shape"]
            or frames.dtype != np.float32
            or len(proof["frame_sha256"]) != len(frames)
        ):
            raise ValueError("Node-local packed shape changed")
        for index, expected in enumerate(proof["frame_sha256"]):
            if hashlib.sha256(frames[index].tobytes()).hexdigest() != expected:
                raise ValueError(f"Node-local OM4 mismatch at frame {index}")
        del frames
receipt = dict(
    local=str(local),
    bytes=needed,
    filesystem=fstype,
    seconds=time.time() - started,
    verified=True,
    caches=cache_receipts,
)
(a.root / f"node-local-{os.environ['SLURM_JOB_ID']}.json").write_text(
    json.dumps(receipt, indent=2) + "\n"
)
print(json.dumps({"node_local_staging": receipt}), flush=True)
os.environ["ONEPASS_LOCAL_DATA"] = str(local)
if a.mode == "qualification":
    subprocess.run(
        [
            sys.executable,
            "/pilot-code/scripts/qualify_stochastic_loss_extensions.py",
            "--root",
            str(a.root / "qualification"),
            "--paths",
            str(a.root / "paths.json"),
        ],
        check=True,
    )
else:
    gate = json.loads((a.root / "qualification/QUALIFIED.json").read_text())
    if (
        gate.get("producer") != os.environ["SAMUDRA_CODE_COMMIT"]
        or gate.get("paths_sha256")
        != hashlib.sha256((a.root / "paths.json").read_bytes()).hexdigest()
    ):
        raise ValueError(
            "Qualification belongs to another source or data configuration"
        )
    if (
        set(gate["variants"]) != set(VARIANTS)
        or not gate["passed"]
        or not all(
            x["mean_gpu_utilization_percent"] > 50 for x in gate["variants"].values()
        )
    ):
        raise ValueError("No passing utilization qualification")
    out = a.root / "production" / a.variant
    base = command(paths, out, a.variant, gate["variants"][a.variant]["microbatch"])
    if (out / "last.pt").exists():
        base += ["--resume"]
    subprocess.run(base, check=True)
    if not (out / "COMPLETE.json").exists():
        raise RuntimeError("Training paused before completion; resume required")
    for checkpoint in sorted(out.glob("step-*.pt")):
        if checkpoint.stem == "step-00000":
            continue
        for raw in [False, True]:
            dest = out / "evaluation" / (checkpoint.stem + ("-raw" if raw else "-ema"))
            if (dest / "COMPLETE.json").exists():
                continue
            subprocess.run(
                [
                    sys.executable,
                    *(
                        [
                            "/pilot-code/scripts/evaluate_stochastic_extension_initializers.py"
                        ]
                        if VARIANTS[a.variant]["training_mode"] == "initializer-only"
                        else [
                            "-m",
                            "samudra.experiments.stochastic_transition_evaluate",
                        ]
                    ),
                    "--data",
                    paths["samples"],
                    "--checkpoint",
                    str(checkpoint),
                    "--output",
                    str(dest),
                ]
                + (["--raw"] if raw else []),
                check=True,
            )

    subprocess.run(
        [
            sys.executable,
            "/pilot-code/scripts/evaluate_stochastic_extension_om4.py",
            "--root",
            str(a.root),
            "--data",
            paths["samples"],
            "--output",
            str(out / "initializer-om4"),
            "--om4",
            "/scratch/jr7309/data/om4_onedeg_v3/OM4.zarr",
            "--training-om4",
            paths["om4"],
            "--variant",
            a.variant,
        ],
        check=True,
    )
