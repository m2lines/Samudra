# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Bounded fresh signed-increment versus weak-variogram screen, with an inline gate."""

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from qualify_stochastic_transitions import gpu_identity
from run_stochastic_shared_noise import training_command as shared_command
from run_stochastic_variogram import monitor
from stochastic_campaign_cache import stage_caches

VARIANTS = {
    "B-shared-deep-wide-signed": (1.0, 0.0),
    "B-shared-deep-wide-weak-variogram": (0.0, 0.25),
}
PRIOR_ALLOCATED_GPU_HOURS = 32.26166666666667
CONTROL = Path(
    "/scratch/jr7309/stochastic-shared-noise-20261103/production/B-shared-deep-wide/step-00000.pt"
)
SHORT_UPDATES = 1000
MAP_CHANNELS = [
    "uo_0",
    "uo_9",
    "uo_18",
    "vo_0",
    "vo_9",
    "vo_18",
    "vo_3",
    "vo_8",
    "vo_10",
]


def training_command(paths, out, variant):
    signed, variogram = VARIANTS[variant]
    return shared_command(paths, out, "B-shared-deep-wide") + [
        "--main-updates",
        "8000",
        "--checkpoint-every",
        "100",
        "--velocity-init-variogram-weight",
        str(variogram),
        "--velocity-init-variogram-lags",
        "1",
        "2",
        "4",
        "8",
        "--velocity-init-signed-crps-weight",
        str(signed),
        "--velocity-init-signed-crps-lags",
        "1",
        "2",
        "4",
        "8",
    ]


def validate_release(release, variant, source, wall_minutes):
    """Reserve both allocations including qualification/evaluation against the old cap."""
    if release["source"] != source or release["stage_updates"] != SHORT_UPDATES:
        raise ValueError("Source or authorized update count differs")
    walls = release["wall_minutes"]
    if set(walls) != set(VARIANTS) or any(
        type(v) is not int or v <= 0 for v in walls.values()
    ):
        raise ValueError("Require positive wall minutes for exactly the two arms")
    if release["prior_allocated_gpu_hours"] != PRIOR_ALLOCATED_GPU_HOURS:
        raise ValueError("Prior allocation ledger differs")
    extra = release.get("additional_allocated_gpu_hours", 0)
    if not math.isfinite(extra) or extra < 0:
        raise ValueError("Invalid additional allocation ledger")
    total = PRIOR_ALLOCATED_GPU_HOURS + extra + sum(walls.values()) / 60
    if total > 40 or not math.isclose(
        total, release["maximum_total_gpu_hours"], abs_tol=1e-9
    ):
        raise ValueError(
            "Allocation exceeds or differs from reviewed 40 GPU-hour budget"
        )
    if walls[variant] != wall_minutes:
        raise ValueError("Slurm allocation differs from release")


def control_contract_differences(actual, control):
    ignored = {"producer", "loss", "main_updates"}
    return sorted(
        key
        for key in actual.keys() | control.keys()
        if key not in ignored
        and not key.startswith(("velocity_init_variogram", "velocity_init_signed_crps"))
        and actual.get(key) != control.get(key)
    )


def validate_events(rows, variant):
    if [r["step"] for r in rows] != list(range(1, 25)):
        raise ValueError("Qualification must contain exactly updates 1 through 24")
    prefix = (
        "velocity_init_signed_crps"
        if VARIANTS[variant][0]
        else "velocity_init_variogram"
    )
    suffixes = (
        ("fair", "accuracy", "spread")
        if VARIANTS[variant][0]
        else ("fair", "plugin", "finite_ensemble_correction")
    )
    keys = [
        f"{prefix}/{s}"
        for s in (*suffixes, "weighted_auxiliary", "weighted_base_initializer_crps")
    ]
    if not all(math.isfinite(r[k]) for r in rows for k in ["loss", "grad_norm", *keys]):
        raise ValueError("Nonfinite optimization or auxiliary diagnostics")
    if any(r[k] != 0 for r in rows if r["source"] == "observation" for k in keys):
        raise ValueError("Observation auxiliary is unexpectedly active")
    if not any(
        abs(r[f"{prefix}/weighted_auxiliary"]) > 0 for r in rows if r["source"] == "om4"
    ):
        raise ValueError("Requested auxiliary was not exercised")


def runtime_projection(
    mean_update_seconds, elapsed_seconds, wall_minutes, evaluation_reserve=1200
):
    """Stop at qualification if the short stage will not fit its allocation."""
    if not all(
        math.isfinite(x) and x >= 0
        for x in (mean_update_seconds, elapsed_seconds, evaluation_reserve)
    ):
        raise ValueError("Invalid runtime estimate")
    total = elapsed_seconds + mean_update_seconds * 976 + evaluation_reserve
    return dict(
        passed=total <= wall_minutes * 60,
        elapsed_seconds=elapsed_seconds,
        projected_total_seconds=total,
        evaluation_reserve_seconds=evaluation_reserve,
        wall_minutes=wall_minutes,
    )


def qualification(paths, out, variant):
    import torch

    from samudra.experiments.stochastic_transition_train import configuration, parser

    saved = torch.load(out / "last.pt", map_location="cpu", weights_only=False)
    if saved["step"] != 24 or saved["counts"] != {"om4": 12, "observation": 12}:
        raise ValueError("Qualification exposure differs")
    expected = configuration(
        parser().parse_args(training_command(paths, out, variant)[3:])
    )
    if (
        any(saved["contract"].get(k) != v for k, v in expected.items())
        or saved["contract"].get("producer") != os.environ["SAMUDRA_CODE_COMMIT"]
    ):
        raise ValueError("Qualification checkpoint contract differs")
    for section in ("model", "ema"):
        if not all(torch.isfinite(v).all() for v in saved[section].values()):
            raise ValueError("Nonfinite checkpoint")
    initial = torch.load(out / "step-00000.pt", map_location="cpu", weights_only=False)
    control = torch.load(CONTROL, map_location="cpu", weights_only=False)
    for section in ("model", "ema"):
        if initial[section].keys() != control[section].keys() or any(
            not torch.equal(v, control[section][k]) for k, v in initial[section].items()
        ):
            raise ValueError("Fresh raw/EMA weights differ from reused control")
    differences = control_contract_differences(initial["contract"], control["contract"])
    if differences:
        raise ValueError(f"Control contract mismatch: {differences}")
    with CONTROL.open("rb") as stream:
        control_sha = hashlib.file_digest(stream, "sha256").hexdigest()
    del saved, initial, control
    rows = [
        json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()
    ]
    validate_events(rows, variant)
    warm = rows[4:]
    samples = [
        json.loads(line)
        for line in (out / "gpu-qualify.jsonl").read_text().splitlines()
    ]
    active = [
        s
        for s in samples
        if "utilization" in s
        and any(
            r["update_started_unix"] <= s["time"] <= r["update_finished_unix"]
            for r in warm
        )
    ]
    if len(active) < 20:
        raise RuntimeError("Insufficient active GPU telemetry")
    util = sum(s["utilization"] for s in active) / len(active)
    seconds = sum(r["seconds"] for r in warm) / len(warm)
    runtime = runtime_projection(
        seconds,
        time.time() - float(os.environ["CAMPAIGN_ALLOCATION_STARTED_UNIX"]),
        int(os.environ["CAMPAIGN_WALL_MINUTES"]),
    )
    result = dict(
        passed=util > 50 and runtime["passed"],
        runtime_budget=runtime,
        variant=variant,
        source=os.environ["SAMUDRA_CODE_COMMIT"],
        updates=24,
        mean_gpu_utilization_percent=util,
        mean_update_seconds=seconds,
        mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm) / len(warm),
        peak_memory_mib=max(s["memory_mib"] for s in active),
        projected_remaining_training_hours=seconds * 976 / 3600,
        control_initial_sha256=control_sha,
        control_initial_weights_identical=True,
        control_contract_matches_except_added_loss_and_planned_duration=True,
        telemetry_errors=[s for s in samples if "telemetry_error" in s],
    )
    (out / "QUALIFIED.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"qualification": result}), flush=True)
    if not result["passed"]:
        raise RuntimeError(
            "Qualification requires >50% GPU utilization and projected training/evaluation within allocation"
        )


def monitored_train(base, out, phase, arguments):
    identity, stop, errors = gpu_identity(), threading.Event(), []

    def telemetry():
        try:
            monitor(out / f"gpu-{phase}.jsonl", stop, identity)
        except Exception as error:
            errors.append(repr(error))

    worker = threading.Thread(target=telemetry, daemon=True)
    worker.start()
    try:
        subprocess.run(base + arguments, check=True)
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or errors:
        raise RuntimeError(f"Telemetry failed: {errors}")


def evaluate(paths, out, variant):
    import torch

    saved = torch.load(out / "step-01000.pt", map_location="cpu", weights_only=False)
    if saved["step"] != SHORT_UPDATES or saved["counts"] != {
        "om4": 500,
        "observation": 500,
    }:
        raise ValueError("Short screen source exposure differs")
    del saved
    manifest = out / "initializer-manifest.json"
    manifest.write_text(
        json.dumps(
            [
                dict(variant=variant, step=s, path=str(out / f"step-{s:05d}.pt"))
                for s in (500, 1000)
            ],
            indent=2,
        )
        + "\n"
    )
    for weights in ("ema", "raw"):
        raw = ["--raw"] if weights == "raw" else []
        subprocess.run(
            [
                sys.executable,
                "/pilot-code/scripts/diagnose_stochastic_velocity_wave2.py",
                "--manifest",
                str(manifest),
                "--output",
                str(out / f"initializer-{weights}"),
                "--data",
                paths["samples"],
                "--map-steps",
                "500",
                "1000",
                "--map-channels",
                *MAP_CHANNELS,
                *raw,
            ],
            check=True,
        )
        subprocess.run(
            [
                sys.executable,
                "-m",
                "samudra.experiments.stochastic_transition_evaluate",
                "--data",
                paths["samples"],
                "--checkpoint",
                str(out / "step-01000.pt"),
                "--output",
                str(out / "evaluation" / f"step-01000-{weights}"),
                *raw,
            ],
            check=True,
        )
    (out / "EVALUATED.json").write_text(
        json.dumps(
            dict(
                complete=True,
                variant=variant,
                step=SHORT_UPDATES,
                counts=dict(om4=500, observation=500),
                source=os.environ["SAMUDRA_CODE_COMMIT"],
            ),
            indent=2,
        )
        + "\n"
    )


def run(args):
    release = json.loads((args.root / "RELEASE.json").read_text())
    validate_release(
        release,
        args.variant,
        os.environ["SAMUDRA_CODE_COMMIT"],
        int(os.environ["CAMPAIGN_WALL_MINUTES"]),
    )
    out = args.root / "production" / args.variant
    out.mkdir(parents=True, exist_ok=True)
    if (out / "last.pt").exists():
        raise ValueError(
            "Existing run needs explicit recovery review; refusing duplicate allocation"
        )
    paths = json.loads((args.root / "paths.json").read_text())
    stage_caches(args.root, paths)
    base = training_command(paths, out, args.variant)
    monitored_train(base, out, "qualify", ["--max-new-updates", "24"])
    qualification(paths, out, args.variant)
    monitored_train(base, out, "production", ["--resume", "--max-new-updates", "976"])
    evaluate(paths, out, args.variant)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    run(parser.parse_args())
