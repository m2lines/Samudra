# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Qualify fresh variogram runs against identical initial control weights."""

import argparse
import hashlib
import json
import math
import os
import subprocess
import threading
import time
from pathlib import Path

from qualify_stochastic_transitions import command, gpu_identity, gpu_sample
from run_stochastic_shared_noise import evaluate
from stochastic_campaign_cache import stage_caches

VARIANTS = {
    "B-learned-variogram": ((64, 128, 256), 1),
    "B-shared-deep-wide-variogram": ((96, 192, 384), 3),
}
CONTROLS = {
    "B-learned-variogram": "/scratch/jr7309/stochastic-joint-noise-20261101/production/B-learned-control",
    "B-shared-deep-wide-variogram": "/scratch/jr7309/stochastic-shared-noise-20261103/production/B-shared-deep-wide",
}
PRIOR_ALLOCATED_GPU_HOURS = (75347 + 1127) / 3600


def monitor(path, stop, identity):
    """Record telemetry outages explicitly and keep sampling after transient errors."""
    with path.open("w") as stream:
        while not stop.is_set():
            try:
                sample = gpu_sample(identity)
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as error:
                sample = dict(time=time.time(), telemetry_error=repr(error))
                print(json.dumps({"telemetry_warning": sample}), flush=True)
            stream.write(json.dumps(sample) + "\n")
            stream.flush()
            stop.wait(1)


def training_command(paths, out, variant):
    widths, blocks = VARIANTS[variant]
    learned = variant == "B-learned-variogram"
    return command(paths, out, "B", 1) + [
        "--objective",
        "fair-crps",
        "--main-updates",
        "2000",
        "--cooldown-updates",
        "0",
        "--checkpoint-every",
        "500",
        "--seed",
        "1729",
        "--noise-mode",
        "iid",
        "--noise-architecture",
        "legacy" if learned else "shared_input",
        "--noise-processing-blocks",
        "3" if learned else "0",
        "--widths",
        "64",
        "128",
        "256",
        "--initializer-widths",
        *map(str, widths),
        "--initializer-blocks",
        str(blocks),
        "--velocity-init-variogram-weight",
        "1.0",
        "--velocity-init-variogram-lags",
        "1",
        "2",
        "4",
        "8",
        "--hours",
        "20",
    ]


def validate_release(release, qualified, variant, source, wall_minutes):
    """Check the complete allocation ledger before spending production GPU time."""
    if release["source"] != source or qualified["source"] != source:
        raise ValueError("Qualification or release source differs")
    widths, blocks = VARIANTS[variant]
    if (
        qualified["passed"] is not True
        or qualified["variant"] != variant
        or list(qualified["initializer_widths"]) != list(widths)
        or qualified["initializer_blocks"] != blocks
    ):
        raise ValueError("Qualification model differs from requested variant")
    walls = release["wall_minutes"]
    if set(walls) != set(VARIANTS) or any(
        type(value) is not int or value <= 0 for value in walls.values()
    ):
        raise ValueError("Require positive allocation minutes for every variant")
    spent = release["qualification_allocated_gpu_hours"]
    maximum = release["maximum_total_gpu_hours"]
    if (
        not math.isfinite(spent)
        or spent < 0
        or not math.isfinite(maximum)
        or maximum <= 0
    ):
        raise ValueError("Invalid campaign GPU-hour ledger")
    prior = release["prior_allocated_gpu_hours"]
    if prior != PRIOR_ALLOCATED_GPU_HOURS:
        raise ValueError("Prior campaign cost changed")
    total = prior + spent + sum(walls.values()) / 60
    if total > 40 or maximum > 40 or not math.isclose(total, maximum, abs_tol=1e-9):
        raise ValueError(
            "Campaign allocation ledger exceeds or differs from reviewed budget"
        )
    if wall_minutes != walls[variant]:
        raise ValueError("Allocation differs from reviewed release")


def qualification(out, variant, errors):
    import torch

    saved = torch.load(out / "last.pt", map_location="cpu", weights_only=False)
    if saved["step"] != 24 or saved["counts"] != {"om4": 12, "observation": 12}:
        raise ValueError("Qualification exposure differs")
    from samudra.experiments.stochastic_transition_train import configuration, parser

    paths = json.loads((out.parent.parent / "paths.json").read_text())
    expected_contract = configuration(
        parser().parse_args(training_command(paths, out, variant)[3:])
    )
    if (
        any(
            saved["contract"].get(key) != value
            for key, value in expected_contract.items()
        )
        or saved["contract"].get("producer") != os.environ["SAMUDRA_CODE_COMMIT"]
    ):
        raise ValueError("Qualification checkpoint contract differs")
    for section in ("model", "ema"):
        if not all(torch.isfinite(value).all() for value in saved[section].values()):
            raise ValueError("Nonfinite checkpoint")
    counts = {
        prefix: sum(
            v.numel() for k, v in saved["model"].items() if k.startswith(prefix + ".")
        )
        for prefix in ("initializer", "processor", "forcing_adapter")
    }
    initial = torch.load(out / "step-00000.pt", map_location="cpu", weights_only=False)
    control_path = Path(CONTROLS[variant]) / "step-00000.pt"
    control = torch.load(control_path, map_location="cpu", weights_only=False)
    for section in ("model", "ema"):
        if initial[section].keys() != control[section].keys() or any(
            not torch.equal(value, control[section][key])
            for key, value in initial[section].items()
        ):
            raise ValueError("Fresh model initialization differs from reused control")
    ignored = {"producer", "loss"}
    different = {
        key
        for key in initial["contract"].keys() | control["contract"].keys()
        if key not in ignored
        and not key.startswith("velocity_init_variogram")
        and initial["contract"].get(key) != control["contract"].get(key)
    }
    if different:
        raise ValueError(f"Reused control contract mismatch: {sorted(different)}")
    with control_path.open("rb") as stream:
        control_sha = hashlib.file_digest(stream, "sha256").hexdigest()
    del initial, control, saved
    rows = [
        json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()
    ]
    if [r["step"] for r in rows] != list(range(1, 25)):
        raise ValueError("Incomplete qualification log")
    if not all(
        math.isfinite(r["loss"]) and math.isfinite(r["grad_norm"]) for r in rows
    ):
        raise ValueError("Nonfinite optimization")
    diagnostic_keys = [
        f"velocity_init_variogram/{name}"
        for name in (
            "fair",
            "plugin",
            "finite_ensemble_correction",
            "weighted_auxiliary",
            "weighted_base_initializer_crps",
        )
    ]
    if not all(math.isfinite(row[key]) for row in rows for key in diagnostic_keys):
        raise ValueError("Nonfinite variogram diagnostics")
    if any(
        row[key] != 0
        for row in rows
        if row["source"] == "observation"
        for key in diagnostic_keys
    ):
        raise ValueError("Observation updates unexpectedly include variogram terms")
    if not any(
        row["velocity_init_variogram/plugin"] > 0
        for row in rows
        if row["source"] == "om4"
    ):
        raise ValueError("Variogram auxiliary was not exercised")
    warm = rows[4:]
    samples = [
        json.loads(line)
        for line in (out / "gpu-qualify.jsonl").read_text().splitlines()
    ]
    active = [
        s
        for s in samples
        if "utilization" in s
        and any(
            r["update_started_unix"] <= s["time"] <= r["update_finished_unix"]
            for r in warm
        )
    ]
    if errors or len(active) < 20:
        raise RuntimeError(f"Insufficient telemetry: {errors}")
    utilization = sum(r["utilization"] for r in active) / len(active)
    seconds = sum(r["seconds"] for r in warm) / len(warm)
    gate = dict(
        passed=utilization > 50,
        variant=variant,
        updates=24,
        mean_gpu_utilization_percent=utilization,
        mean_update_seconds=seconds,
        mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm) / len(warm),
        peak_memory_mib=max(r["memory_mib"] for r in active),
        source=os.environ["SAMUDRA_CODE_COMMIT"],
        model_state_elements=counts,
        initializer_widths=VARIANTS[variant][0],
        initializer_blocks=VARIANTS[variant][1],
        projected_remaining_training_hours=seconds * (2000 - 24) / 3600,
        generator_exposure=dict(om4=8000, observation=8000),
        control_initial_checkpoint=str(control_path),
        control_initial_sha256=control_sha,
        control_initial_weights_identical=True,
        control_contract_matches_except_added_loss=True,
        telemetry_errors=[s for s in samples if "telemetry_error" in s],
        variogram_weight=1.0,
        final_om4_diagnostics=next(r for r in reversed(rows) if r["source"] == "om4"),
    )
    (out / "QUALIFIED.json").write_text(json.dumps(gate, indent=2) + "\n")
    print(json.dumps({"qualification": gate}), flush=True)
    if not gate["passed"]:
        raise RuntimeError("GPU utilization did not exceed approved 50% threshold")


def run(args):
    paths = json.loads((args.root / "paths.json").read_text())
    out = args.root / "production" / args.variant
    out.mkdir(parents=True, exist_ok=True)
    if args.stage == "qualify":
        if (out / "last.pt").exists():
            raise ValueError("Refuse to overwrite an existing qualification")
    else:
        release = json.loads((args.root / "RELEASE.json").read_text())
        qualified = json.loads((out / "QUALIFIED.json").read_text())
        if (out / "COMPLETE.json").exists() or (out / "EVALUATED.json").exists():
            raise ValueError(
                "Production already complete; review evaluation recovery separately"
            )
        validate_release(
            release,
            qualified,
            args.variant,
            source=os.environ["SAMUDRA_CODE_COMMIT"],
            wall_minutes=int(os.environ["CAMPAIGN_WALL_MINUTES"]),
        )
    stage_caches(args.root, paths)
    base = training_command(paths, out, args.variant)
    identity = gpu_identity()
    stop = threading.Event()
    errors = []

    def telemetry():
        try:
            monitor(out / f"gpu-{args.stage}.jsonl", stop, identity)
        except Exception as error:
            errors.append(repr(error))

    worker = threading.Thread(target=telemetry, daemon=True)
    worker.start()
    try:
        if args.stage == "qualify":
            subprocess.run(base + ["--max-new-updates", "24"], check=True)
        else:
            subprocess.run(base + ["--resume"], check=True)
    finally:
        stop.set()
        worker.join(timeout=20)
    if worker.is_alive() or errors:
        raise RuntimeError(f"Telemetry failed: {errors}")
    if args.stage == "qualify":
        qualification(out, args.variant, errors)
    else:
        evaluate(paths, out, args.variant)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    parser.add_argument("--stage", choices=("qualify", "production"), required=True)
    run(parser.parse_args())
