# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Qualified single-GPU Torch launch; production is never auto-enabled by a failed gate."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from qualify_stochastic_transitions import command, gpu_identity, monitor

VARIANTS = {
    "control": (0.0, 1.0),
    "velocity-mean-mse": (1.0, 1.0),
    "velocity-crps-2p2": (0.0, 2.2),
}

p = argparse.ArgumentParser()
p.add_argument("--root", type=Path, required=True)
p.add_argument("--variant", choices=list(VARIANTS), default="control")
a = p.parse_args()
paths = json.loads((a.root / "paths.json").read_text())
# Stage only caches: original source metadata/contract paths remain unchanged.
# Both qualification and production execute this exact path; retain read-back proof.
local = Path(os.environ["ONEPASS_NODE_TMP"])
fstype = subprocess.check_output(
    ["stat", "-f", "-c", "%T", str(local)], text=True
).strip()
if fstype in ("nfs", "nfs4", "lustre", "beegfs", "tmpfs"):
    raise RuntimeError(
        f"Node-local cache requires disk-backed local storage, got {fstype}"
    )
needed = sum(
    p.stat().st_size
    for key in ("packed_om4", "forcing_cache")
    for p in Path(paths[key]).iterdir()
    if p.is_file()
)
if shutil.disk_usage(local).free < needed + 20 * 1024**3:
    raise RuntimeError("Insufficient node-local disk for verified training caches")
started = time.time()
cache_receipts = {}
for key in ("packed_om4", "forcing_cache"):
    destination = local / key
    destination.mkdir()
    for source in Path(paths[key]).iterdir():
        if source.is_file():
            subprocess.run(
                ["cp", "--", str(source), str(destination / source.name)],
                check=True,
                timeout=600,
            )
    proof_bytes = (destination / "COMPLETE.json").read_bytes()
    source_proof_bytes = (Path(paths[key]) / "COMPLETE.json").read_bytes()
    if proof_bytes != source_proof_bytes:
        raise ValueError(f"Node-local proof changed: {key}")
    proof_sha = hashlib.sha256(proof_bytes).hexdigest()
    if key == "forcing_cache" and proof_sha != paths["forcing_proof_sha256"]:
        raise ValueError("Forcing proof differs from pinned data configuration")
    proof = json.loads(proof_bytes)
    cache_receipts[key] = dict(
        source=paths[key], destination=str(destination), proof_sha256=proof_sha
    )
    if key == "forcing_cache":
        for name, expected in proof["files"].items():
            with (destination / name).open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            if actual != expected:
                raise ValueError(f"Node-local forcing mismatch: {name}")
    else:
        import numpy as np

        frames = np.load(destination / "frames.npy", mmap_mode="r")
        if (
            list(frames.shape) != proof["shape"]
            or frames.dtype != np.float32
            or len(proof["frame_sha256"]) != len(frames)
        ):
            raise ValueError("Node-local packed shape changed")
        for index, expected in enumerate(proof["frame_sha256"]):
            if hashlib.sha256(frames[index].tobytes()).hexdigest() != expected:
                raise ValueError(f"Node-local OM4 mismatch at frame {index}")
        del frames
receipt = dict(
    local=str(local),
    bytes=needed,
    filesystem=fstype,
    seconds=time.time() - started,
    verified=True,
    caches=cache_receipts,
)
(a.root / f"node-local-{os.environ['SLURM_JOB_ID']}.json").write_text(
    json.dumps(receipt, indent=2) + "\n"
)
print(json.dumps({"node_local_staging": receipt}), flush=True)
os.environ["ONEPASS_LOCAL_DATA"] = str(local)

out = a.root / "production" / a.variant
out.mkdir(parents=True, exist_ok=True)
aux, multiplier = VARIANTS[a.variant]
parent = "/scratch/jr7309/stochastic-transitions-20261027/production/B/step-02000.pt"
base = command(paths, out, "B", 1) + [
    "--main-updates",
    "2512",
    "--cooldown-updates",
    "0",
    "--checkpoint-every",
    "128",
    "--fork-checkpoint",
    parent,
    "--velocity-init-mean-mse-weight",
    str(aux),
    "--velocity-init-crps-multiplier",
    str(multiplier),
    "--hours",
    "2",
]
identity = gpu_identity()
stop = threading.Event()
telemetry = threading.Thread(
    target=monitor, args=(out / "gpu.jsonl", stop, identity), daemon=True
)
telemetry.start()
try:
    subprocess.run(base + ["--max-new-updates", "16"], check=True)
    import torch

    saved = torch.load(out / "last.pt", map_location="cpu", weights_only=False)
    initial = torch.load(out / "step-02000.pt", map_location="cpu", weights_only=False)
    ancestor = torch.load(parent, map_location="cpu", weights_only=False)
    assert saved["step"] == 2016 and saved["counts"] == {
        "om4": 1008,
        "observation": 1008,
    }
    assert all(
        torch.equal(initial["model"][k], v) and torch.equal(initial["ema"][k], v)
        for k, v in ancestor["model"].items()
    )
    for k, v in ancestor["optimizer"]["state"].items():
        for field, value in v.items():
            torch.testing.assert_close(
                initial["optimizer"]["state"][k][field], value, rtol=0, atol=0
            )
    assert all(torch.isfinite(v).all() for v in saved["model"].values())
    del saved, initial, ancestor
    rows = [
        json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()
    ]
    gpu = [json.loads(line) for line in (out / "gpu.jsonl").read_text().splitlines()]
    warm = rows[4:]
    active = [
        r["utilization"]
        for r in gpu
        if warm[0]["update_started_unix"]
        <= r["time"]
        <= warm[-1]["update_finished_unix"]
    ]
    utilization = sum(active) / len(active)
    gate = dict(
        passed=utilization > 50,
        mean_gpu_utilization=utilization,
        mean_seconds=sum(r["seconds"] for r in warm) / len(warm),
        mean_data_wait_seconds=sum(r["data_wait_seconds"] for r in warm) / len(warm),
        parent_raw_and_adam_exact=True,
        ema_reset_exact=True,
        updates=16,
        source=os.environ["SAMUDRA_CODE_COMMIT"],
    )
    (out / "QUALIFIED.json").write_text(json.dumps(gate, indent=2) + "\n")
    print(json.dumps({"qualification": gate}), flush=True)
    if not gate["passed"]:
        raise RuntimeError("Warm GPU utilization below permitted50%")
    subprocess.run(base + ["--resume"], check=True)
finally:
    stop.set()
    telemetry.join(timeout=10)
if not (out / "COMPLETE.json").is_file():
    raise RuntimeError("Continuation incomplete; resume required")
for raw in [False, True]:
    subprocess.run(
        [
            sys.executable,
            "-m",
            "samudra.experiments.stochastic_transition_evaluate",
            "--data",
            paths["samples"],
            "--checkpoint",
            str(out / "step-02512.pt"),
            "--output",
            str(out / "evaluation" / ("step-02512-raw" if raw else "step-02512-ema")),
        ]
        + (["--raw"] if raw else []),
        check=True,
    )
