#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Score cached initializer surface draws; no model inference or interior truth."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def measure(draws, target, mask, lat):
    valid = mask.astype(bool) & np.isfinite(target)
    if not np.isfinite(draws[:, valid]).all():
        raise ValueError("Nonfinite initializer prediction on observed wet support")
    area = np.broadcast_to(np.cos(np.deg2rad(lat))[:, None], target.shape)
    weight = np.where(valid, area, 0)
    total = weight.sum()
    if total <= 0:
        raise ValueError("Empty observed wet support")
    values = np.where(valid, draws, 0).astype(np.float64)
    truth = np.where(valid, target, 0).astype(np.float64)
    mse = ((values - truth) ** 2 * weight).sum(axis=(-2, -1)) / total
    ensemble_mse = ((values.mean(0) - truth) ** 2 * weight).sum() / total
    count = len(values)
    crps = np.abs(values - truth).mean(0)
    for first in range(count):
        for second in range(first):
            crps -= np.abs(values[first] - values[second]) / (count * (count - 1))
    return dict(
        ensemble_mse=float(ensemble_mse),
        member_mse=mse.tolist(),
        fair_crps=float((crps * weight).sum() / total),
        support_points=int(valid.sum()),
        support_area=float(total),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("root", "data", "output"):
        parser.add_argument("--" + key, type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with np.load(args.data / "grid.npz", allow_pickle=False) as grid:
        names = grid["names"].tolist()
        lat = grid["lat"]
        gridmask = grid["mask"]
        gridmean = grid["mean"]
        gridstd = grid["std"]
    expected = [f"2013-{m:02d}" for m in (11, 12)] + [
        f"2014-{m:02d}" for m in range(1, 8)
    ]
    if sorted(p.stem for p in (args.data / "validation").glob("*.npz")) != expected:
        raise ValueError("Nine-origin validation cohort differs")
    targets = {}
    references = {}
    for origin in expected:
        path = args.data / "validation" / f"{origin}.npz"
        with np.load(path, allow_pickle=False) as sample:
            mid = np.asarray(sample["midpoints"], dtype="datetime64[s]")
            first = np.datetime64(origin + "-01", "s")
            half = np.timedelta64(216000, "s")
            if mid[18] != first - half or mid[19] != first + half or len(mid) < 25:
                raise ValueError(
                    "Initializer latest history / future alignment differs"
                )
            targets[origin] = sample["surface"][18]
        references[origin] = dict(
            path=str(path),
            sha256=sha(path),
            initial_midpoint=str(mid[18]),
            history_index=18,
            initial_interval_start=str(first - np.timedelta64(5, "D")),
            initial_interval_end=str(first),
        )
    rows = []
    per_origin = []
    provenance = []
    for arm in "ABC":
        for step in range(500, 5001, 500):
            counts = dict(
                om4_updates=min(step, 4000) // 2,
                obs_updates=min(step, 4000) // 2 + max(0, step - 4000),
            )
            for weights in ("raw", "ema"):
                directory = (
                    args.root
                    / "production"
                    / arm
                    / "evaluation"
                    / f"step-{step:05d}-{weights}"
                )
                complete = json.loads((directory / "COMPLETE.json").read_text())
                if (
                    complete["step"] != step
                    or complete["weights"] != weights
                    or complete["metrics"]["origins"] != expected
                    or complete["metrics"]["members"] != 8
                ):
                    raise ValueError("Cached evaluation protocol differs")
                collected = {field: [] for field in ("SST", "SSH")}
                for origin in expected:
                    path = directory / f"members-{origin}.npz"
                    with np.load(path, allow_pickle=False) as saved:
                        channels = saved["channel_names"].tolist()
                        initial = saved["initial"]
                        if initial.shape != (8, 4, len(lat), gridmask.shape[-1]):
                            raise ValueError(
                                "Expected eight members and four original map channels"
                            )
                        provenance.append(
                            dict(
                                arm=arm,
                                updates=step,
                                weights=weights,
                                origin=origin,
                                path=str(path),
                                bytes=path.stat().st_size,
                                initial_payload_sha256=hashlib.sha256(
                                    initial.tobytes()
                                ).hexdigest(),
                            )
                        )
                        means, stds, masks = saved["mean"], saved["std"], saved["mask"]
                    for target_channel, (channel, field, unit) in enumerate(
                        (("thetao_0", "SST", "degC"), ("zos", "SSH", "m"))
                    ):
                        c = channels.index(channel)
                        g = names.index(channel)
                        np.testing.assert_array_equal(masks[c], gridmask[g])
                        np.testing.assert_array_equal(means[c], gridmean[g])
                        np.testing.assert_array_equal(stds[c], gridstd[g])
                        draws = initial[:, c].astype(np.float64) * stds[c] + means[c]
                        scores = measure(
                            draws, targets[origin][target_channel], masks[c], lat
                        )
                        collected[field].append(scores)
                        per_origin.append(
                            dict(
                                arm=arm,
                                updates=step,
                                **counts,
                                weights=weights,
                                field=field,
                                units=unit,
                                origin=origin,
                                initial_midpoint=references[origin]["initial_midpoint"],
                                ensemble_mean_rmse=float(
                                    np.sqrt(scores["ensemble_mse"])
                                ),
                                mean_member_rmse=float(
                                    np.sqrt(scores["member_mse"]).mean()
                                ),
                                fair_crps=scores["fair_crps"],
                                support_points=scores["support_points"],
                                support_area=scores["support_area"],
                            )
                        )
                for field, unit in (("SST", "degC"), ("SSH", "m")):
                    scores = collected[field]
                    rows.append(
                        dict(
                            arm=arm,
                            updates=step,
                            **counts,
                            weights=weights,
                            field=field,
                            units=unit,
                            origins=9,
                            members=8,
                            ensemble_mean_rmse=float(
                                np.sqrt(np.mean([s["ensemble_mse"] for s in scores]))
                            ),
                            mean_member_rmse=float(
                                np.sqrt(
                                    np.mean([s["member_mse"] for s in scores], axis=0)
                                ).mean()
                            ),
                            fair_crps=float(np.mean([s["fair_crps"] for s in scores])),
                            checkpoint_sha256=complete["checkpoint_sha256"],
                        )
                    )
                print(
                    json.dumps(
                        dict(arm=arm, updates=step, weights=weights, scored_origins=9)
                    ),
                    flush=True,
                )
    for filename, records in (("curves.csv", rows), ("per-origin.csv", per_origin)):
        with (args.output / filename).open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)
    result = dict(
        complete=True,
        rows=rows,
        references=references,
        cache_provenance=provenance,
        grid_sha256=sha(args.data / "grid.npz"),
        script_sha256=sha(__file__),
        support="Global channel-specific native wet mask intersect finite latest-history observed SST/SSH; cosine latitude weights, no polar exclusion.",
        aggregation="Each origin area-normalized equally. Ensemble RMSE=sqrt(mean origin ensemble MSE); mean member RMSE=mean over 8 of sqrt(mean origin member MSE); fair CRPS=mean origin area-normalized fair estimator.",
        scope="Initializer latest history output only, before any processor step. No interior validation labels inferred. A repeated deterministic members make CRPS equal MAE.",
    )
    (args.output / "COMPLETE.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
