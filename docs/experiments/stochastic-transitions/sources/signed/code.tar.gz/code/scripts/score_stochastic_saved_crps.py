# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""CPU-only day-30 surface CRPS from saved final EMA ensemble maps."""
import argparse
import json
from pathlib import Path
import numpy as np


def point_scores(x, y):
    m = len(x)
    absolute = np.abs(x - y).mean(0)
    pairs = sum(np.abs(x[i] - x[j]) for i in range(m) for j in range(i))
    return absolute - pairs / m**2, absolute - pairs / (m * (m-1)), absolute


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    grid = np.load(a.root / 'grid.npz')
    area = np.cos(np.deg2rad(grid['lat']))[:, None]
    names = sorted(p.name for p in (a.root / 'A/evaluation/step-05000-ema').glob('members-*.npz'))
    assert len(names) == 9
    results = {}
    references, masks = {}, {}
    for arm in 'ABC':
        totals = {v: dict(weight=0., empirical=0., fair=0., member_mae=0., mean_mae=0.) for v in ['SST', 'SSH']}
        for name in names:
            with np.load(a.root / arm / 'evaluation/step-05000-ema' / name) as z:
                x = z['day30'][:, :2].astype(np.float64) * z['std'][:2, None, None] + z['mean'][:2, None, None]
                y = z['day30_reference'].astype(np.float64)
                mask = z['mask'][:2].astype(bool) & grid['mask'][0].astype(bool)
                if arm == 'A':
                    references[name], masks[name] = y, mask
                    assert np.array_equal(x, np.broadcast_to(x[:1], x.shape))
                else:
                    np.testing.assert_array_equal(y, references[name])
                    np.testing.assert_array_equal(mask, masks[name])
                assert np.isfinite(x[:, mask]).all()
                empirical, fair, absolute = point_scores(x, y)
                for c,v in enumerate(['SST','SSH']):
                    valid = mask[c] & np.isfinite(y[c])
                    w = np.broadcast_to(area, valid.shape)[valid]
                    totals[v]['weight'] += w.sum()
                    for k,value in [('empirical',empirical),('fair',fair),('member_mae',absolute),('mean_mae',np.abs(x.mean(0)-y))]:
                        totals[v][k] += np.sum(value[c][valid] * w)
        results[arm] = {v:{k: val/t['weight'] for k,val in t.items() if k != 'weight'} for v,t in totals.items()}
    a.output.write_text(json.dumps(dict(protocol='pointwise CRPS; cosine-latitude weighted over common wet/finite support and nine origins; day30 five-day surface means; final EMA; 8 members',units={'SST':'degC','SSH':'m'},origins=names,results=results),indent=2)+'\n')
    print(json.dumps(results,indent=2))


if __name__ == '__main__':
    # Known two-member case: y=0, members[-1,+1].
    empirical,fair,_ = point_scores(np.array([[-1.],[1.]]),np.array([0.]))
    np.testing.assert_allclose(empirical,.5)
    np.testing.assert_allclose(fair,0.)
    main()
