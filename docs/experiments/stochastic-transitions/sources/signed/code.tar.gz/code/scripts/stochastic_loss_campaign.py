# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Fixed matched loss-ablation variants and launch arguments."""

from qualify_stochastic_transitions import command as original_command

VARIANTS = {
    "A-mae": dict(arm="A", objective="mae", auxiliary=0.0, microbatch=4),
    "B-member-mse": dict(arm="B", objective="member-mse", auxiliary=0.0, microbatch=1),
    "B-crps-mean-mse": dict(
        arm="B", objective="fair-crps", auxiliary=1.0, microbatch=1
    ),
}


def command(paths, output, variant, microbatch=None):
    config = VARIANTS[variant]
    if microbatch is not None and microbatch != config["microbatch"]:
        raise ValueError("Microbatch must match the qualified original arm")
    return original_command(paths, output, config["arm"], config["microbatch"]) + [
        "--objective",
        config["objective"],
        "--ensemble-mean-mse-weight",
        str(config["auxiliary"]),
        "--main-updates",
        "2000",
        "--cooldown-updates",
        "0",
        "--checkpoint-every",
        "500",
        "--seed",
        "1729",
    ]
