# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Separately frozen multiscale and initializer-only comparisons."""

from qualify_stochastic_transitions import command as original_command

VARIANTS = {
    "B-multiscale-fair-crps": dict(
        arm="B",
        objective="multiscale-fair-crps",
        auxiliary=0.0,
        microbatch=1,
        training_mode="joint",
    ),
    "B-initializer-only": dict(
        arm="B",
        objective="fair-crps",
        auxiliary=0.0,
        microbatch=1,
        training_mode="initializer-only",
    ),
}


def command(paths, output, variant, microbatch=None):
    config = VARIANTS[variant]
    if microbatch is not None and microbatch != config["microbatch"]:
        raise ValueError("Microbatch differs from qualification")
    return original_command(paths, output, "B", config["microbatch"]) + [
        "--objective",
        config["objective"],
        "--training-mode",
        config["training_mode"],
        "--main-updates",
        "2000",
        "--cooldown-updates",
        "0",
        "--checkpoint-every",
        "500",
        "--seed",
        "1729",
    ]
