# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Paired conditional WGAN-GP for OM4-supervised stochastic initialization.

The loss follows Perezhogin, Zanna and Fernandez-Granda (2023), Appendix C.1,
https://arxiv.org/html/2302.07984#A3.SS1 . A mixed pair contains one generated
field and its reference target; a fake pair contains two independent draws for
the same conditioning. The critic receives the conditioning in either case.

Adaptations: a small fully convolutional critic with global pooling handles
arbitrary ocean grids; channel masks are explicit inputs, longitude is periodic
and latitude is zero padded. There is no batch normalization or sigmoid. The
trainer owns the five-critic-updates-per-generator schedule and optimizers.
Inputs are normalized physical fields, normally the latest 77-channel state.
Two-frame states can be flattened to 154 channels with a repeated field mask.
"""

import math
from contextlib import contextmanager

import torch
import torch.nn.functional as F
from torch import nn


def _mask_like(mask, field):
    if field.ndim != 4 or mask.ndim not in (3, 4):
        raise ValueError("Fields must be BCHW and masks CHW or BCHW")
    return torch.broadcast_to(mask.bool(), field.shape)


class ConditionalPairCritic(nn.Module):
    """Scalar conditional critic for an ordered pair of ocean fields.

    Strided convolutions avoid retaining full-grid width-128 activations in
    the gradient-penalty graph. Global pooling provides grid-size independence;
    the final unrestricted linear map produces one scalar per example.
    """

    def __init__(self, conditioning_channels, field_channels=77, widths=(32, 64, 128)):
        super().__init__()
        if conditioning_channels < 1 or field_channels < 1 or not widths:
            raise ValueError("Positive conditioning, field and hidden widths required")
        if any(width < 1 for width in widths):
            raise ValueError("Positive hidden widths required")
        self.conditioning_channels = conditioning_channels
        self.field_channels = field_channels
        channels = conditioning_channels + 3 * field_channels
        self.layers = nn.ModuleList()
        for width in widths:
            layer = nn.Conv2d(channels, width, 3, stride=2)
            nn.init.normal_(layer.weight, 0, 0.02)
            nn.init.zeros_(layer.bias)
            self.layers.append(layer)
            channels = width
        self.output = nn.Linear(channels, 1)
        nn.init.normal_(self.output.weight, 0, 0.02)
        nn.init.zeros_(self.output.bias)

    def forward(self, conditioning, first, second, mask):
        if first.shape != second.shape or first.shape[1] != self.field_channels:
            raise ValueError("Critic pair must have identical configured field shapes")
        if conditioning.shape != (
            first.shape[0],
            self.conditioning_channels,
            *first.shape[-2:],
        ):
            raise ValueError("Critic conditioning shape does not match field grid")
        valid = _mask_like(mask, first)
        # where also removes nonfinite placeholders on masked land.
        conditioning = torch.where(valid.any(1, keepdim=True), conditioning, 0)
        x = torch.cat(
            (
                conditioning,
                torch.where(valid, first, 0),
                torch.where(valid, second, 0),
                valid.to(first.dtype),
            ),
            dim=1,
        )
        for layer in self.layers:
            x = F.pad(x, (1, 1, 0, 0), mode="circular")
            x = F.pad(x, (0, 0, 1, 1))
            x = F.leaky_relu(layer(x), negative_slope=0.2)
        return self.output(x.mean((-2, -1))).squeeze(-1)


def _check_pair(real, fake_pair):
    if fake_pair.ndim != 5 or fake_pair.shape[0] != 2:
        raise ValueError("Exactly two generated fields required: 2,B,C,H,W")
    if real is not None and fake_pair.shape[1:] != real.shape:
        raise ValueError("Generated fields must match the real target")


def paired_critic_loss(
    critic,
    conditioning,
    real,
    fake_pair,
    mask,
    *,
    generator=None,
    gp_weight=10.0,
    drift_weight=1e-3,
):
    """Return detached-input discriminator loss and detached scalar diagnostics.

    GP uses the unnormalized L2 norm over the two masked physical fields, as in
    the paper. Conditioning and mask coordinates are held fixed, not penalized.
    The random choice of mixed-pair ordering is shared across the batch, matching
    Appendix C.1; interpolation coefficients are independently drawn per example.
    """
    _check_pair(real, fake_pair)
    if not all(math.isfinite(w) and w >= 0 for w in (gp_weight, drift_weight)):
        raise ValueError("GAN penalty weights must be finite and nonnegative")
    with torch.autocast(device_type=real.device.type, enabled=False):
        conditioning = conditioning.detach().float()
        valid = _mask_like(mask, real)
        real = torch.where(valid, real.detach().float(), 0)
        fake_pair = torch.where(valid[None], fake_pair.detach().float(), 0)
        first, second = fake_pair.unbind(0)
        mixed_first = critic(conditioning, first, real, mask)
        mixed_second = critic(conditioning, real, second, mask)
        fake_score = critic(conditioning, first, second, mask)
        wasserstein = fake_score.mean() - 0.5 * (
            mixed_first.mean() + mixed_second.mean()
        )

        choose_first = torch.rand((), device=real.device, generator=generator) < 0.5
        mixed_pair = torch.where(
            choose_first,
            torch.stack((first, real)),
            torch.stack((real, second)),
        )
        epsilon = torch.rand(
            (1, real.shape[0], 1, 1, 1), device=real.device, generator=generator
        )
        interpolation = (
            epsilon * mixed_pair + (1 - epsilon) * fake_pair
        ).requires_grad_()
        score = critic(conditioning, interpolation[0], interpolation[1], mask)
        gradient = torch.autograd.grad(score.sum(), interpolation, create_graph=True)[0]
        gradient = torch.where(valid[None], gradient, 0)
        norm = gradient.movedim(0, 1).flatten(1).norm(2, dim=1)
        penalty = (norm - 1).square().mean()
        drift = mixed_first.square().mean()
        loss = wasserstein + gp_weight * penalty + drift_weight * drift
        metrics = {
            "critic_loss": loss.detach(),
            "wasserstein": wasserstein.detach(),
            "gradient_penalty": penalty.detach(),
            "gradient_norm": norm.mean().detach(),
            "drift": drift.detach(),
            "fake_score": fake_score.mean().detach(),
            "mixed_score": (0.5 * (mixed_first + mixed_second)).mean().detach(),
        }
    return loss, metrics


@contextmanager
def frozen_parameters(module):
    """Temporarily freeze parameters without detaching gradients through inputs."""
    flags = [(parameter, parameter.requires_grad) for parameter in module.parameters()]
    try:
        for parameter, _ in flags:
            parameter.requires_grad_(False)
        yield
    finally:
        for parameter, enabled in flags:
            parameter.requires_grad_(enabled)


def paired_generator_loss(critic, conditioning, fake_pair, mask):
    """Generator loss -D(fake1,fake2 | conditioning), preserving input gradients."""
    _check_pair(None, fake_pair)
    with (
        frozen_parameters(critic),
        torch.autocast(device_type=fake_pair.device.type, enabled=False),
    ):
        return -critic(
            conditioning.float(), fake_pair[0].float(), fake_pair[1].float(), mask
        ).mean()
