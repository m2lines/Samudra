# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""OM4-only conditional critic updates with independent sampling and saved RNG."""

import time

import torch

from .physical_state_batching import compatible_groups
from .stochastic_conditional_gan import ConditionalPairCritic, paired_critic_loss


def native_initial_condition(model, samples):
    """Use precisely the surface history and target scored by OM4 reconstruction."""
    compact = "initial_target" in samples[0]
    surface = torch.cat(
        [
            s["surface"][:, : model.history]
            if compact
            else s["fields"][:, : model.history, model.surface]
            for s in samples
        ]
    )
    target = torch.cat(
        [
            s["initial_target"] if compact else s["fields"][:, model.history - 1]
            for s in samples
        ]
    )
    mask = samples[0]["mask"]
    condition, _, _ = model.encode_native(
        surface,
        torch.cat([s["atmosphere"][:, : model.history] for s in samples]),
        torch.cat([s["contexts"][:, model.history - 1] for s in samples]),
        mask,
        mask[model.surface].bool().expand_as(surface),
        return_anchors=False,
    )
    return condition, target, mask


def sample_initial_pair(model, condition, mask, generator):
    """Two independently initialized latest states, without forecasting."""
    repeated = condition.unsqueeze(0).expand(2, *condition.shape).flatten(0, 1)
    state = model.initialize(repeated, None, None, mask, generator)
    return state.reshape(2, condition.shape[0], *state.shape[1:])[:, :, -1]


class ConditionalGanTraining:
    """Critic is separate from generator/EMA and is never needed for evaluation."""

    def __init__(self, model, *, seed, learning_rate=1e-4, widths=(32, 64, 128)):
        self.device = next(model.parameters()).device
        # Critic creation must not alter generator initialization or its RNG.
        devices = [self.device.index or 0] if self.device.type == "cuda" else []
        with torch.random.fork_rng(devices=devices):
            torch.manual_seed(seed + 700001)
            channels = (
                model.history * (2 * len(model.surface) + model.forcing_channels) + 5
            )
            self.critic = ConditionalPairCritic(
                channels, model.channels, widths=widths
            ).to(self.device)
        self.optimizer = torch.optim.Adam(
            self.critic.parameters(), lr=learning_rate, betas=(0.5, 0.9)
        )
        self.generator = torch.Generator(device=self.device).manual_seed(seed + 700003)
        self.updates = self.examples = 0

    def state_dict(self):
        return dict(
            critic=self.critic.state_dict(),
            optimizer=self.optimizer.state_dict(),
            noise_rng=self.generator.get_state(),
            updates=self.updates,
            examples=self.examples,
        )

    def load_state_dict(self, state):
        self.critic.load_state_dict(state["critic"], strict=True)
        self.optimizer.load_state_dict(state["optimizer"])
        self.generator.set_state(state["noise_rng"].cpu())
        self.updates, self.examples = state["updates"], state["examples"]

    def update(self, model, samples, *, microbatch):
        """One full effective-batch critic update; generator weights stay fixed."""
        started = time.monotonic()
        self.critic.train()
        self.optimizer.zero_grad(set_to_none=True)
        total = torch.zeros((), device=self.device)
        metrics = {}
        for group in compatible_groups(samples, microbatch):
            selected = [samples[i] for i in group]
            with (
                torch.no_grad(),
                torch.autocast(
                    self.device.type,
                    dtype=torch.bfloat16,
                    enabled=self.device.type == "cuda",
                ),
            ):
                condition, target, mask = native_initial_condition(model, selected)
                pair = sample_initial_pair(model, condition, mask, self.generator)
            loss, values = paired_critic_loss(
                self.critic,
                condition.detach(),
                target,
                pair,
                mask,
                generator=self.generator,
            )
            scale = len(group) / len(samples)
            (loss * scale).backward()
            total += loss.detach() * scale
            for key, value in values.items():
                metrics[key] = metrics.get(key, 0) + value.detach() * scale
        if not torch.isfinite(total):
            raise FloatingPointError("Nonfinite conditional critic loss")
        # Do not clip: the paper controls critic gradients through WGAN-GP.
        finite_gradients = torch.stack(
            [
                torch.isfinite(parameter.grad).all()
                for parameter in self.critic.parameters()
                if parameter.grad is not None
            ]
        ).all()
        if not finite_gradients:
            raise FloatingPointError("Nonfinite conditional critic gradient")
        self.optimizer.step()
        self.optimizer.zero_grad(set_to_none=True)
        self.updates += 1
        self.examples += len(samples)
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
        return dict(
            loss=float(total),
            **{key: float(value) for key, value in metrics.items()},
            seconds=time.monotonic() - started,
        )
