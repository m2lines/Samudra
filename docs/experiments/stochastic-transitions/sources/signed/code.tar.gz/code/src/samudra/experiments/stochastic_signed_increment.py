# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
"""Fair CRPS for signed spatial differences on complete wet paths.

Unlike absolute-increment variograms, this score distinguishes a field from its
sign reversal. It remains insensitive to a spatially constant offset, so it is
an auxiliary to field supervision rather than a replacement for it. Lags are
computational grid cells, not equal physical distances across latitude.
"""

import torch

from .stochastic_variogram import DIRECTIONS, _offset, validate_lags


def signed_increment_crps(members, target, mask, area, lags=(1, 2, 4, 8)):
    """Return scalar fair/accuracy/spread terms and corresponding per-lag vectors.

    Members: M,B,C,H,W; target: B,C,H,W; mask: C,H,W; area: H,W or H,1.
    Inputs use the existing fixed per-channel normalization. For each supported
    pair a,b, score d_m=x_m(a)-x_m(b) against d_y=y(a)-y(b), retaining its sign.
    Fair CRPS is mean_m|d_m-d_y| minus sum_{i<j}|d_i-d_j|/[M(M-1)]. A single
    member gives absolute increment error and zero spread term.

    Every traversed grid cell must be wet and target-finite. Longitude wraps;
    latitude does not. Endpoint-mean area weights reduce space, followed by
    equal supported example/channel, direction and lag averages. No support
    yields NaN for the trainer's finite-loss gate without GPU synchronization.
    """
    lags = validate_lags(lags)
    if members.ndim != 5 or members.shape[1:] != target.shape:
        raise ValueError("Expected members M,B,C,H,W and matching target B,C,H,W")
    if members.shape[0] < 1 or mask.shape != target.shape[1:]:
        raise ValueError("Require at least one member and a C,H,W mask")
    height, width = target.shape[-2:]
    if area.shape not in ((height, width), (height, 1)):
        raise ValueError("Area must have shape H,W or H,1")
    if max(lags) >= min(height, width):
        raise ValueError("Spatial lags must be smaller than both grid dimensions")
    count = members.shape[0]
    with torch.autocast(device_type=members.device.type, enabled=False):
        valid = mask.bool()[None] & torch.isfinite(target)
        values = torch.where(valid[None], members.float(), 0)
        truth = torch.where(valid, target.float(), 0)
        area = area.float().expand(height, width)
        totals, lag_support = [], []
        for lag in lags:
            directions, direction_support = [], []
            for dy, dx in DIRECTIONS:
                rows = height - dy * lag
                support = valid[..., :rows, :].clone()
                for distance in range(1, lag + 1):
                    support = support & _offset(valid, dy, dx, distance, rows)
                weight = torch.where(
                    support,
                    0.5 * (area[:rows] + _offset(area, dy, dx, lag, rows)),
                    0,
                )
                denominator = weight.sum((-2, -1))
                supported = denominator > 0
                # Mask before arithmetic so excluded NaNs cannot enter gradients.
                increments = torch.where(support[None], values[..., :rows, :], 0) - (
                    torch.where(support[None], _offset(values, dy, dx, lag, rows), 0)
                )
                reference = torch.where(support, truth[..., :rows, :], 0) - (
                    torch.where(support, _offset(truth, dy, dx, lag, rows), 0)
                )
                accuracy = (increments - reference).abs().mean(0)
                spread = torch.zeros_like(accuracy)
                for first in range(count):
                    for second in range(first):
                        spread = spread + (
                            increments[first] - increments[second]
                        ).abs() / (count * (count - 1))
                terms = torch.stack((accuracy, spread))
                spatial = (terms * weight).sum((-2, -1)) / denominator.clamp_min(1e-30)
                average = torch.where(supported[None], spatial, 0).sum((-2, -1))
                directions.append(average / supported.sum().clamp_min(1))
                direction_support.append(supported.any())
            direction_flags = torch.stack(direction_support)
            totals.append(
                torch.stack(directions).sum(0) / direction_flags.sum().clamp_min(1)
            )
            lag_support.append(direction_flags.any())
        by_lag = torch.stack(totals)
        overall = by_lag.sum(0) / torch.stack(lag_support).sum()
        accuracy_by_lag, spread_by_lag = by_lag.unbind(-1)
        accuracy, spread = overall.unbind(-1)
        return dict(
            fair=accuracy - spread,
            accuracy=accuracy,
            spread=spread,
            fair_by_lag=accuracy_by_lag - spread_by_lag,
            accuracy_by_lag=accuracy_by_lag,
            spread_by_lag=spread_by_lag,
        )
