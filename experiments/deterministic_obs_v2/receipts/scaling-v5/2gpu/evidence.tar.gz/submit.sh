#!/bin/bash
# SPDX-FileCopyrightText: 2026 Samudra Authors
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
export NCCL_P2P_DISABLE=1 TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export APPTAINERENV_NCCL_P2P_DISABLE=1 APPTAINERENV_TORCH_NCCL_ASYNC_ERROR_HANDLING=1
export NCCL_DEBUG=INFO APPTAINERENV_NCCL_DEBUG=INFO
TASK_ROOT=/scratch/jr7309/deterministic-obs-v2
export SIF_PATH=/scratch/jr7309/.apptainer-images/ghcr.io-m2lines-ocean-emulator-physicsnemo-26.05-4f86be45a09cb9eba1b51b6273e0189941b02495.sif
export CODE_LAYER=/scratch/jr7309/.apptainer-code-layers/samudra-code-7bef723cb1f60d4e202aeece6fd4c1b11eb2e539.img
export REPO_DIR=/scratch/jr7309 SIF_DIR=/scratch/jr7309/.apptainer-images
export APPTAINER_CACHEDIR=/scratch/jr7309/apptainer-cache SINGULARITY_CACHEDIR=/scratch/jr7309/singularity-cache
export DATA_CACHE_DIR="$TASK_ROOT/scaling-v5/data-cache"
export DATA_ROOT=/scratch/jr7309 OUTPUT_BASE="$TASK_ROOT/scaling-v5"
export WANDB_MODE=online REQUEUE_ON_USR1=1 SAMUDRA_MANAGE_RUN_DIR=0
export SAMUDRA_MODULE=samudra.observations.qualify_scaling
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export GPUS_PER_NODE=2 NAME=B-mixed-small-2gpu
export CONFIG="$TASK_ROOT/configs/scaling-v5/B-mixed-small-2gpu.yaml"
export SAMUDRA_MODULE_ARGS="$CONFIG"
request=(--chdir=/scratch/jr7309 --account=torch_pr_347_lzanna --nodes=1 --ntasks=1 --cpus-per-task=16 --mem=96G --gres=gpu:2 --constraint=rtx6000 --time=00:45:00 --requeue --signal=B:USR1@300 '--comment=preemption=yes;requeue=true' --job-name=obs-scale-v5-2gpu --output="$TASK_ROOT/scaling-v5-2gpu-%j.out" --error="$TASK_ROOT/scaling-v5-2gpu-%j.out")
if [[ "${1:-}" == submit ]]; then
  sbatch --parsable "${request[@]}" "$TASK_ROOT/frozen-data/train-scaling-nccl-25af85a34ff8.sbatch"
else
  sbatch --test-only "${request[@]}" "$TASK_ROOT/frozen-data/train-scaling-nccl-25af85a34ff8.sbatch"
fi
