import json,hashlib,torch,gc
from pathlib import Path
p=Path('/scratch/jr7309/deterministic-obs-v2/screens-v1-2gpu/A-obs-small')
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r={}
for name,expected,cooled in [('ckpt.pt',5000,True),('main-4000.pt',4000,False),('best_validation_ckpt.pt',4000,False)]:
 path=p/'saved_nets'/name;s=torch.load(path,map_location='cpu',weights_only=False)
 assert s['updates']==expected and s['cooled']==cooled and len(s['rank_rng'])==2
 r[name]={k:s[k] for k in ['updates','cooled','best_score','exposure']};r[name].update(sha256=digest(path),world_size=len(s['rank_rng']),manifest_sha256=hashlib.sha256(json.dumps(s['manifest'],sort_keys=True).encode()).hexdigest());del s;gc.collect()
original=Path('/scratch/jr7309/deterministic-obs-v2/screens-v1/A-obs-small/saved_nets/ckpt.pt');r['original_sha256']=digest(original);assert r['original_sha256']=='34f15666cc49da777f8f2837381ae6d9c6bafdaddc1a4fe60d790abbf65eb831'
(p/'completion-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
