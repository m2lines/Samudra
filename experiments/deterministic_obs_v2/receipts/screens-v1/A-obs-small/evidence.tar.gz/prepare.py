import hashlib,json,shutil
from pathlib import Path
root=Path('/scratch/jr7309/deterministic-obs-v2')
old=root/'screens-v1/A-obs-small'
audit=root/'world-size-migration-v1'
new=root/'screens-v1-2gpu/A-obs-small'
def digest(p):
 with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
proof=json.loads((audit/'MIGRATION_QUALIFIED.json').read_text())
migration=json.loads((audit/'derived-2gpu.pt.migration.json').read_text())
assert proof['exact_same_layout_complete_checkpoint_payload'] and proof['original_checkpoint_unchanged']
assert proof['start_update']==2825 and proof['new_world_size']==2 and proof['global_examples']==8
original_hash=digest(old/'saved_nets/ckpt.pt')
assert original_hash==proof['original_sha256']==migration['source_sha256']
assert digest(audit/'derived-2gpu.pt')==migration['output_sha256']
new.mkdir(parents=True,exist_ok=False);(new/'saved_nets').mkdir()
for src,dst in [(audit/'derived-2gpu.pt',new/'saved_nets/ckpt.pt'),(old/'saved_nets/best_validation_ckpt.pt',new/'saved_nets/best_validation_ckpt.pt'),(old/'wandb-id.txt',new/'wandb-id.txt'),(old/'manifest.json',new/'manifest.json'),(audit/'derived-2gpu.pt.migration.json',new/'migration.json')]:
 shutil.copy2(src,dst)
 assert digest(src)==digest(dst)
rows=[json.loads(line) for line in (old/'metrics.jsonl').read_text().splitlines()]
kept=[r for r in rows if r['updates']<=2825]
(new/'metrics.jsonl').write_text(''.join(json.dumps(r,allow_nan=False)+'\n' for r in kept))
assert digest(old/'saved_nets/ckpt.pt')==original_hash
receipt={'original_output':str(old),'resumed_output':str(new),'original_checkpoint_sha256':original_hash,'initial_2gpu_checkpoint_sha256':digest(new/'saved_nets/ckpt.pt'),'best_checkpoint_sha256':digest(new/'saved_nets/best_validation_ckpt.pt'),'best_checkpoint_scope':'Copied original four-rank best for selection only; never used as resume source','wandb_id':(new/'wandb-id.txt').read_text().strip(),'start_update':2825,'total_updates':5000,'remaining_updates':2175,'rank_map':[0,1],'global_examples':8,'history_rows_retained':len(kept),'history_rows_removed':len(rows)-len(kept),'resume_ckpt_path':None,'cross_layout_bitwise_trajectory_claim':False}
(new/'resume-provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
