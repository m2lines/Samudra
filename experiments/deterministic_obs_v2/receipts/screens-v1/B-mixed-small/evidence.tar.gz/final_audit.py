import argparse, gc, hashlib, json, math
from pathlib import Path
import torch
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--world-size',type=int,required=True);args=p.parse_args();root=args.output
key='rollout_val/365d/normalized_rmse/channel_mean'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
rows=[json.loads(x) for x in (root/'metrics.jsonl').read_text().splitlines()]
assert all(math.isfinite(v) for r in rows for v in r.values() if isinstance(v,(int,float)))
training=[r for r in rows if 'global_examples' in r]
assert {r['updates'] for r in training}==set(range(1,5001))
assert all(r['global_examples']==8 for r in training)
vals=[r for r in rows if key in r];best=min(vals,key=lambda r:r[key]);final=[r for r in vals if r['updates']==5000][-1]
assert all(r['rollout_val/365d/scored_channels']==29 and r['rollout_val/365d/forecast_steps']==73 and r['rollout_val/365d/complete_months']==12 for r in vals)
assert json.loads((root/'saved_nets/COMPLETE.json').read_text())['updates']==5000
result={'output':str(root),'unique_training_updates':5000,'training_record_count':len(training),'duplicate_training_updates':len(training)-5000,'global_examples':8,'validation_records':len(vals),'best_update':best['updates'],'best_score':best[key],'final_score':final[key],'wandb_id':(root/'wandb-id.txt').read_text().strip(),'checkpoints':{}}
for name,expected in [('ckpt.pt',5000),('endpoint.pt',5000),('main-4000.pt',4000),('best_validation_ckpt.pt',best['updates'])]:
 path=root/'saved_nets'/name;s=torch.load(path,map_location='cpu',weights_only=False,mmap=True)
 assert s['updates']==expected and s['cooled']==(expected>4000)
 assert len(s['rank_rng'])==args.world_size
 assert s['best_score']==best[key] or name=='main-4000.pt'
 assert all(torch.isfinite(v).all() for v in s['model'].values() if v.is_floating_point())
 if expected==5000:assert s['pending_plan'] is None
 result['checkpoints'][name]={k:s[k] for k in ['updates','cooled','best_score','exposure']};result['checkpoints'][name].update(sha256=digest(path),world_size=len(s['rank_rng']),manifest_sha256=hashlib.sha256(json.dumps(s['manifest'],sort_keys=True).encode()).hexdigest());del s;gc.collect()
provenance=root/'resume-provenance.json'
if provenance.exists():
 proof=json.loads(provenance.read_text());original=Path(proof['original_output'])/'saved_nets/ckpt.pt';assert digest(original)==proof['original_checkpoint_sha256'];result['original_checkpoint_unchanged']=True
(root/'completion-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
