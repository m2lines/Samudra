import json, shutil
from pathlib import Path
from migrate_observation_checkpoint import digest, migrate
from samudra.observations.config import ObservationTrainConfig
root = Path('/scratch/jr7309/deterministic-obs-v2')
old = root / 'screens-v1/B-mixed-small'
new = root / 'screens-v1-2gpu/B-mixed-small'
proof = new / 'resume-provenance.json'
old_cfg = ObservationTrainConfig.from_yaml(root / 'configs/screens-v1/B-mixed-small.yaml')
new_cfg = ObservationTrainConfig.from_yaml(root / 'configs/screens-v1-2gpu/B-mixed-small.yaml')
assert old_cfg.scientific_config() == new_cfg.scientific_config()
assert new_cfg.resume_ckpt_path is None
source = old / 'saved_nets/ckpt.pt'
source_sha = digest(source)
if proof.exists():
    prior = json.loads(proof.read_text())
    assert source_sha == prior['original_checkpoint_sha256']
    assert (new / 'saved_nets/ckpt.pt').exists()
    print('Existing production resume directory; preserving latest checkpoint')
else:
    new.mkdir(parents=True, exist_ok=False)
    (new / 'saved_nets').mkdir()
    parent = new / 'parent-4gpu.pt'
    shutil.copy2(source, parent)
    assert digest(parent) == source_sha
    receipt = migrate(parent, new / 'saved_nets/ckpt.pt', [0, 1])
    assert receipt['updates'] == 3075 and receipt['old_world_size'] == 4
    for rel in ['saved_nets/best_validation_ckpt.pt', 'wandb-id.txt', 'manifest.json']:
        shutil.copy2(old / rel, new / rel)
        assert digest(old / rel) == digest(new / rel)
    rows = [json.loads(x) for x in (old / 'metrics.jsonl').read_text().splitlines()]
    kept = [x for x in rows if x['updates'] <= 3075]
    (new / 'metrics.jsonl').write_text(''.join(json.dumps(x, allow_nan=False) + '\n' for x in kept))
    assert digest(source) == source_sha
    result = {'original_output': str(old), 'resumed_output': str(new), 'original_checkpoint_sha256': source_sha, 'initial_2gpu_checkpoint_sha256': receipt['output_sha256'], 'best_checkpoint_sha256': digest(new / 'saved_nets/best_validation_ckpt.pt'), 'best_checkpoint_scope': 'Copied original four-rank best for selection only; never used as resume source', 'wandb_id': (new / 'wandb-id.txt').read_text().strip(), 'start_update': 3075, 'total_updates': 5000, 'remaining_updates': 1925, 'rank_map': [0, 1], 'global_examples': 8, 'history_rows_retained': len(kept), 'history_rows_removed': len(rows)-len(kept), 'resume_ckpt_path': None, 'scientific_config_unchanged': True, 'cross_layout_bitwise_trajectory_claim': False}
    proof.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))
