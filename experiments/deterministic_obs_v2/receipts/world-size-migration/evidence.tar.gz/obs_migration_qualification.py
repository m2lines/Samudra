"""External audit wrapper around unchanged frozen production observation training."""
import argparse
import json
import math
import shutil
from pathlib import Path

import torch
import torch.distributed as dist

from migrate_observation_checkpoint import digest, equal_tree, migrate


def prepare(root, source):
    root.mkdir(parents=True, exist_ok=True)
    parent = root / 'parent-4gpu.pt'
    migrated = root / 'derived-2gpu.pt'
    original_sha = digest(source)
    if not parent.exists():
        with parent.open('xb') as stream, source.open('rb') as input_stream:
            shutil.copyfileobj(input_stream, stream)
    if digest(parent) != original_sha:
        raise ValueError('Isolated parent copy differs from original')
    if not migrated.exists():
        receipt = migrate(parent, migrated, [0, 1])
    else:
        receipt = json.loads(Path(str(migrated) + '.migration.json').read_text())
        if digest(migrated) != receipt['output_sha256'] or original_sha != receipt['source_sha256']:
            raise ValueError('Existing migration differs')
    if receipt['updates'] != 2825 or digest(source) != original_sha:
        raise ValueError('Unexpected source checkpoint or source changed')
    (root / 'request.json').write_text(json.dumps({'original_source':str(source),'original_sha256':original_sha,'start_update':2825,'stop_update':2829},indent=2)+'\n')


def run(config):
    from samudra.observations.config import ObservationTrainConfig
    from samudra.observations import train as entry
    from samudra.observations.qualify_scaling import model_digest
    cfg = ObservationTrainConfig.from_yaml(config)
    original_train = entry.train
    def audited_train(*args, **kwargs):
        result = original_train(*args, **kwargs)
        model = args[1].model
        hashes = [None] * dist.get_world_size()
        dist.all_gather_object(hashes, model_digest(model))
        if len(hashes) != 2 or len(set(hashes)) != 1:
            raise ValueError('Final rank models disagree')
        if dist.get_rank() == 0:
            (cfg.experiment.output_dir / 'rank-hashes.json').write_text(json.dumps(hashes)+'\n')
        return result
    entry.train = audited_train
    entry.run_training(cfg)


def audit(root):
    migrated = torch.load(root/'derived-2gpu.pt',map_location='cpu',weights_only=False,mmap=True)
    controls=[]
    for name in ('control-a','control-b'):
        out=root/name
        value=torch.load(out/'saved_nets/ckpt.pt',map_location='cpu',weights_only=False,mmap=True)
        if value['updates'] != 2829 or len(value['rank_rng']) != 2:
            raise ValueError('Wrong continuation endpoint')
        equal_tree(value['manifest'],migrated['manifest'])
        if value['exposure']['obs']['updates'] != migrated['exposure']['obs']['updates']+4:
            raise ValueError('Wrong source exposure')
        for key in ('fresh','replay'):
            if value['exposure']['obs'][key] != migrated['exposure']['obs'][key]+16:
                raise ValueError('Wrong fresh/replay exposure')
        rows=[json.loads(line) for line in (out/'metrics.jsonl').read_text().splitlines()]
        train=[r for r in rows if 'train/gradient_norm' in r]
        if [r['updates'] for r in train] != [2826,2827,2828,2829]:
            raise ValueError('Unexpected continuation records')
        if any(r['world_size'] != 2 or r['global_examples'] != 8 for r in train):
            raise ValueError('Wrong rank count/global batch')
        if any(not math.isfinite(v) for r in train for v in r.values() if isinstance(v,(int,float))):
            raise ValueError('Nonfinite training record')
        hashes=json.loads((out/'rank-hashes.json').read_text())
        if len(hashes)!=2 or len(set(hashes))!=1:
            raise ValueError('Rank model mismatch')
        controls.append(value)
    equal_tree(*controls)
    request=json.loads((root/'request.json').read_text())
    if digest(request['original_source'])!=request['original_sha256']:
        raise ValueError('Original checkpoint changed')
    report={'purpose':'Explicit world-size migration qualification on isolated copies','old_world_size':4,'new_world_size':2,'global_examples':8,'start_update':2825,'end_update':2829,'exact_same_layout_complete_checkpoint_payload':True,'original_checkpoint_unchanged':True,'manifest_unchanged':True,'rank_models_agree':True,'all_training_records_finite':True,'cross_layout_bitwise_trajectory_claim':False,'original_sha256':request['original_sha256']}
    (root/'MIGRATION_QUALIFIED.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','run','audit'])
    parser.add_argument('path',type=Path)
    parser.add_argument('--source',type=Path)
    args=parser.parse_args()
    if args.action=='prepare': prepare(args.path,args.source)
    elif args.action=='run': run(args.path)
    else: audit(args.path)
